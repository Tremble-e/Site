## v4.15.6 — bootstrap stable restauré + placement unique 2×2

Cette version repart volontairement du moteur stable de la v4.15.2 pour le cycle de vie des workers.

- La page ADE coordinatrice est activée une seule fois avant la lecture de l'arbre, afin que le rendu ExtJS/GWT se comporte comme lors d'un retour manuel sur la page.
- Les 4 workers sont de nouveau créés séquentiellement, avec les délais, retries et grand viewport utilisés par la v4.15.2.
- Le quadrillage 2×2 n'est appliqué qu'après la validation des workers. Il n'intervient donc plus dans leur bootstrap ADE.
- Le placement utilise l'écran contenant réellement la fenêtre du coordinateur.
- Après ce placement initial, aucune sécurité ne touche plus aux fenêtres : pas de pulse de focus, pas de restauration, pas de maximisation, pas de repositionnement pendant la collecte ou la réparation.
- L'ancienne alarme de focus persistante est supprimée au chargement de l'extension.

Le moteur de collecte, les retries ciblés et la réparation finale restent ceux de la branche stable v4.15.2/v4.13.
