if (typeof importScripts === "function" && !globalThis.PlanilimGwtResponse) {
  try { importScripts("gwt-response.js"); } catch {}
}

const ADE_URL = "https://planning.unilim.fr/direct/myplanning.jsp";
const COLLECTOR_DEFAULT_SCOPE_PATH = "Groupes Etudiants > Faculté des Sciences et Techniques";
const ALARM_NAME = "planilim-auto-sync";
const AUTO_SYNC_MINUTES = 360;
const HISTORY_LIMIT = 16;

const V3_SEQUENCE_MAX_AGE_MS = 45000;
const V3_SETUP_TIMEOUT_MS = 18000;

const V3_EXPECTED_SEQUENCE = [
  "DirectPlanningPlanningServiceProxy::method6getLegends",
  "CorePlanningServiceProxy::method6getAvailabilities",
  "DirectPlanningPlanningServiceProxy::method10getTimetable",
  "CorePlanningServiceProxy::method3getDisplayConfiguration",
  "CorePlanningServiceProxy::method43getUnavailabilities",
  "CorePlanningServiceProxy::method3getDisplayConfiguration"
];

const V3_WEEK_PAYLOAD_INDEX = new Map([
  ["DirectPlanningPlanningServiceProxy::method6getLegends", 39],
  ["CorePlanningServiceProxy::method6getAvailabilities", 40],
  ["DirectPlanningPlanningServiceProxy::method10getTimetable", 42],
  ["CorePlanningServiceProxy::method43getUnavailabilities", 39]
]);

const COLLECTOR_DIAGNOSTICS_KEY = "collectorDiagnosticLogV457";
const COLLECTOR_DIAGNOSTICS_SCHEMA = 1;
const COLLECTOR_DIAGNOSTICS_MAX_ENTRIES = 8;
const COLLECTOR_DIAGNOSTICS_MAX_BYTES = 1_500_000;
const COLLECTOR_DIAGNOSTICS_EMERGENCY_BYTES = 850_000;


let v3PassiveWriteChain = Promise.resolve();
let v3FinalizeTimer = null;
let v3FinalizeBusy = false;


const RPC_FILTER = {
  urls: [
    "https://planning.unilim.fr/*DirectPlanningPlanningServiceProxy*"
  ]
};

const TRACE_FILTER = {
  urls: [
    "https://planning.unilim.fr/direct/gwtdirectplanning/*"
  ]
};

const pendingRequests = new Map();
const collectorRecentTimetableCaptures = new Map();
let traceWriteChain = Promise.resolve();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function nowIso() {
  return new Date().toISOString();
}

async function storeGet(keys) {
  return await chrome.storage.local.get(keys);
}

function isStorageQuotaError(error) {
  const text = String(error?.message || error || "");
  return /quota|kQuotaBytes|QUOTA_BYTES|MAX_WRITE_OPERATIONS/i.test(text);
}

function compactStoredDiagnosticEntry(entry) {
  if (!entry || typeof entry !== "object") return entry;
  const compact = { ...entry };

  // Les audits d'événements sont les seuls diagnostics qui peuvent devenir
  // très volumineux. On conserve le résumé, les différences avec le payload
  // stocké et quelques semaines réellement divergentes, sans dupliquer des
  // centaines de kilo-octets de réponses GWT déjà décodées.
  if (compact.type === "collector-event-audit") {
    if (Array.isArray(compact.weeks) && compact.weeks.length > 44) {
      compact.weeks = compact.weeks.slice(0, 44);
    }
    if (Array.isArray(compact.mismatches)) {
      compact.mismatches = compact.mismatches.slice(0, 6).map((item) => ({
        ...item,
        request: item?.request ? {
          targetValue: item.request.targetValue ?? null,
          bodyLength: item.request.bodyLength ?? null,
          body: diagnosticText(item.request.body || "", 24000)
        } : null,
        responseText: diagnosticText(item?.responseText || "", 42000),
        visibleEvents: Array.isArray(item?.visibleEvents) ? item.visibleEvents.slice(0, 24) : [],
        decodedEvents: Array.isArray(item?.decodedEvents) ? item.decodedEvents.slice(0, 24) : []
      }));
    }
    if (compact.overallStoredComparison) {
      compact.overallStoredComparison = {
        ...compact.overallStoredComparison,
        decodedNotStored: Array.isArray(compact.overallStoredComparison.decodedNotStored)
          ? compact.overallStoredComparison.decodedNotStored.slice(0, 30) : [],
        storedNotDecoded: Array.isArray(compact.overallStoredComparison.storedNotDecoded)
          ? compact.overallStoredComparison.storedNotDecoded.slice(0, 30) : []
      };
    }
  }

  return compact;
}

async function compactCollectorDiagnosticsStorage(maxBytes = COLLECTOR_DIAGNOSTICS_MAX_BYTES) {
  try {
    const data = await chrome.storage.local.get([COLLECTOR_DIAGNOSTICS_KEY]);
    const current = data[COLLECTOR_DIAGNOSTICS_KEY];
    if (!current) return { ok: true, changed: false };

    let entries = (Array.isArray(current.entries) ? current.entries : [])
      .map(compactStoredDiagnosticEntry)
      .slice(-COLLECTOR_DIAGNOSTICS_MAX_ENTRIES);
    let payload = {
      ...current,
      extensionVersion: chrome.runtime.getManifest().version,
      updatedAt: nowIso(),
      entries
    };

    while (entries.length > 1 && JSON.stringify(payload).length > maxBytes) {
      entries.shift();
      payload = { ...payload, entries };
    }

    // En pression extrême on retire le cas réussi de référence, qui reste
    // purement diagnostique et ne doit jamais bloquer une synchronisation.
    if (JSON.stringify(payload).length > maxBytes && payload.successReference) {
      payload = { ...payload, successReference: null };
    }

    await chrome.storage.local.set({ [COLLECTOR_DIAGNOSTICS_KEY]: payload });
    return { ok: true, changed: true };
  } catch (error) {
    return { ok: false, error: String(error) };
  }
}

async function storeSet(values) {
  try {
    await chrome.storage.local.set(values);
  } catch (error) {
    if (!isStorageQuotaError(error)) throw error;

    // 4.6.2 : avant d'abandonner un EDT à cause du quota, on libère le seul
    // bloc non essentiel potentiellement volumineux puis on retente une fois.
    // Avec la permission unlimitedStorage ce chemin ne devrait normalement
    // plus être nécessaire sur Chromium/Brave, mais il protège aussi les
    // profils déjà proches de la limite au moment de la mise à jour.
    await compactCollectorDiagnosticsStorage(COLLECTOR_DIAGNOSTICS_EMERGENCY_BYTES);
    await chrome.storage.local.set(values);
  }
}

function diagnosticText(value, limit = 650000) {
  const text = String(value ?? "");
  if (text.length <= limit) return text;
  const head = Math.max(0, Math.floor(limit * 0.72));
  const tail = Math.max(0, limit - head);
  return `${text.slice(0, head)}\n/* … ${text.length - limit} caractères omis … */\n${text.slice(-tail)}`;
}

function diagnosticRequestEntry(entry) {
  if (!entry) return null;
  const key = operationKey(entry);
  const parsed = parseGwtRequestBody(entry.body || "");
  const timetable =
    key === "DirectPlanningPlanningServiceProxy::method10getTimetable"
      ? parseCollectorTimetableRequestBody(entry.body || "")
      : null;
  const payloadIndex = timetable?.ok
    ? (timetable.weekValueIndex ?? timetable.weekEncodingIndex)
    : V3_WEEK_PAYLOAD_INDEX.get(key);
  let payloadWindow = null;

  if (parsed?.ok && Number.isInteger(payloadIndex)) {
    const from = Math.max(0, payloadIndex - 8);
    const to = Math.min(parsed.annotatedPayload.length, payloadIndex + 9);
    payloadWindow = parsed.annotatedPayload.slice(from, to).map((item) => ({
      ...item,
      selectedWeekCandidate:
        timetable?.ok
          ? item.index >= timetable.weekEncodingIndex &&
            item.index < timetable.weekEncodingIndex + timetable.weekEncodingLength
          : item.index === payloadIndex
    }));
  }

  return {
    at: entry.at ?? null,
    requestId: entry.requestId || null,
    tabId: entry.tabId ?? null,
    frameId: entry.frameId ?? null,
    httpMethod: entry.httpMethod || entry.method || "POST",
    url: entry.url || null,
    service: entry.service || null,
    operation: key || null,
    rpcMethods: Array.isArray(entry.rpcMethods) ? [...entry.rpcMethods] : [],
    resourceId:
      entry.resourceId ??
      (timetable?.ok ? timetable.resourceId : null) ??
      extractResourceId(entry.body || ""),
    bodyLength: String(entry.body || "").length,
    tokenCount: String(entry.body || "").split("|").length,
    body: diagnosticText(entry.body || "", 180000),
    parse: parsed?.ok
      ? {
          ok: true,
          version: parsed.version,
          flags: parsed.flags,
          stringTableCount: parsed.stringTableCount,
          payloadTokenCount: parsed.payloadTokenCount,
          weekPayloadIndex: Number.isInteger(payloadIndex) ? payloadIndex : null,
          weekToken: timetable?.ok
            ? timetable.weekValue
            : (Number.isInteger(payloadIndex) ? parsed.payload?.[payloadIndex] ?? null : null),
          weekEncoding: timetable?.ok ? timetable.weekEncoding : null,
          weekBackReference: timetable?.weekBackReference ?? null,
          payloadWindow
        }
      : parsed || { ok: false, code: "NO_PARSE" }
  };
}

function diagnosticSignature(record) {
  return [
    record?.type || "unknown",
    record?.code || "",
    record?.resourceId ?? record?.target?.resourceId ?? "",
    record?.week?.firstDate || "",
    record?.capture?.bodyLength || "",
    record?.validation?.code || ""
  ].join("|");
}

async function appendCollectorDiagnostic(record) {
  try {
    const data = await storeGet([COLLECTOR_DIAGNOSTICS_KEY]);
    const current = data[COLLECTOR_DIAGNOSTICS_KEY] || {};
    let entries = Array.isArray(current.entries) ? [...current.entries] : [];
    const enriched = {
      schemaVersion: COLLECTOR_DIAGNOSTICS_SCHEMA,
      extensionVersion: chrome.runtime.getManifest().version,
      capturedAt: nowIso(),
      ...record
    };
    enriched.signature = diagnosticSignature(enriched);

    // Une même ressource peut être retentée plusieurs fois. On garde seulement
    // le diagnostic le plus récent pour une signature identique.
    entries = entries.filter((item) => item?.signature !== enriched.signature);
    entries.push(compactStoredDiagnosticEntry(enriched));
    while (entries.length > COLLECTOR_DIAGNOSTICS_MAX_ENTRIES) entries.shift();

    let payload = {
      schemaVersion: COLLECTOR_DIAGNOSTICS_SCHEMA,
      extensionVersion: chrome.runtime.getManifest().version,
      updatedAt: nowIso(),
      successReference: current.successReference || null,
      entries
    };

    while (entries.length > 1 && JSON.stringify(payload).length > COLLECTOR_DIAGNOSTICS_MAX_BYTES) {
      entries.shift();
      payload = { ...payload, entries };
    }

    await storeSet({ [COLLECTOR_DIAGNOSTICS_KEY]: payload });
  } catch (error) {
    console.warn("[Planilim] diagnostic non enregistré", error);
  }
}

async function saveCollectorSuccessReference(reference) {
  try {
    const data = await storeGet([COLLECTOR_DIAGNOSTICS_KEY]);
    const current = data[COLLECTOR_DIAGNOSTICS_KEY] || {};
    if (current.successReference) return;
    await storeSet({
      [COLLECTOR_DIAGNOSTICS_KEY]: {
        schemaVersion: COLLECTOR_DIAGNOSTICS_SCHEMA,
        extensionVersion: chrome.runtime.getManifest().version,
        updatedAt: nowIso(),
        entries: Array.isArray(current.entries) ? current.entries : [],
        successReference: {
          schemaVersion: COLLECTOR_DIAGNOSTICS_SCHEMA,
          extensionVersion: chrome.runtime.getManifest().version,
          capturedAt: nowIso(),
          ...reference
        }
      }
    });
  } catch {}
}

async function collectorDiagnosticsExport() {
  const data = await storeGet([
    COLLECTOR_DIAGNOSTICS_KEY,
    "v3SetupState",
    "collectorState",
    "academicSyncStatus"
  ]);
  const log = data[COLLECTOR_DIAGNOSTICS_KEY] || {
    schemaVersion: COLLECTOR_DIAGNOSTICS_SCHEMA,
    extensionVersion: chrome.runtime.getManifest().version,
    entries: [],
    successReference: null
  };
  const stamp = nowIso().replace(/[:.]/g, "-");
  return {
    ok: true,
    code: "COLLECTOR_DIAGNOSTICS_READY",
    fileName: `planilim-diagnostic-${stamp}.json`,
    data: {
      generatedAt: nowIso(),
      extensionVersion: chrome.runtime.getManifest().version,
      note: "Aucun cookie ni en-tête Authorization n'est exporté. Les corps GWT utiles au diagnostic peuvent contenir des identifiants techniques ADE.",
      context: {
        v3SetupState: data.v3SetupState || null,
        collectorState: data.collectorState || null,
        academicSyncStatus: data.academicSyncStatus || null
      },
      diagnostics: log
    }
  };
}

async function collectorDiagnosticsClear() {
  await chrome.storage.local.remove([COLLECTOR_DIAGNOSTICS_KEY]);
  return { ok: true, code: "COLLECTOR_DIAGNOSTICS_CLEARED" };
}

async function recordV3SequenceDiagnostic(tabId, sequence, validation, extra = {}) {
  const context = await storeGet(["v3SetupState", "collectorState"]);
  const timetableEntry = (sequence || []).find((entry) =>
    Array.isArray(entry?.rpcMethods) && entry.rpcMethods.includes("method10getTimetable")
  ) || null;

  let replay = null;
  if (timetableEntry?.body && timetableEntry?.url) {
    try {
      const response = await replayInPage(tabId, {
        method: timetableEntry.httpMethod || "POST",
        url: timetableEntry.url,
        headers: {},
        body: timetableEntry.body,
        timeoutMs: 12000
      });
      const responseText = String(response?.responseText || "");
      replay = {
        ok: Boolean(response?.ok),
        httpStatus: response?.httpStatus ?? null,
        responseLength: responseText.length,
        gwtAnalysis: analyzeGwtResponse(responseText),
        responseText: diagnosticText(responseText, 700000),
        error: response?.error || null
      };
    } catch (error) {
      replay = { ok: false, error: String(error) };
    }
  }

  await appendCollectorDiagnostic({
    type: "v3-sequence",
    code: validation?.code || (validation?.consistent === false ? "V3_WEEK_VALUES_INDEPENDENT" : "V3_SEQUENCE_DIAGNOSTIC"),
    resourceId:
      context.v3SetupState?.resourceId ??
      context.collectorState?.resourceId ??
      timetableEntry?.resourceId ??
      null,
    label: context.collectorState?.label || context.v3SetupState?.planningLabel || null,
    path: context.collectorState?.path || context.v3SetupState?.planningPath || null,
    tabId,
    validation,
    sequence: (sequence || []).map(diagnosticRequestEntry),
    timetableReplay: replay,
    ...extra
  });
}

async function recordCollectorModelCaptureFailure(tabId, target, capture, weekValue, extra = {}) {
  const data = await storeGet(["v3PassiveEntries", "timetableRequestHistory", "latestTimetableRequest"]);
  const recentPassive = (Array.isArray(data.v3PassiveEntries) ? data.v3PassiveEntries : [])
    .filter((entry) => entry?.tabId === tabId)
    .filter((entry) => Array.isArray(entry?.rpcMethods) && entry.rpcMethods.includes("method10getTimetable"))
    .slice(-6)
    .map(diagnosticRequestEntry);
  const history = (Array.isArray(data.timetableRequestHistory) ? data.timetableRequestHistory : [])
    .filter((entry) => entry?.tabId === tabId)
    .slice(-6)
    .map((entry) => diagnosticRequestEntry({
      ...entry,
      httpMethod: entry.method,
      rpcMethods: rpcMethodNames(entry.body || ""),
      service: serviceNameFromUrl(entry.url || "")
    }));

  await appendCollectorDiagnostic({
    type: "collector-model-capture",
    code: weekValue?.code || extra.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
    resourceId: Number(target?.resourceId) || null,
    target: {
      resourceId: Number(target?.resourceId) || null,
      label: target?.label || null,
      path: target?.path || null
    },
    tabId,
    weekValue: weekValue || null,
    capture: capture
      ? {
          capturedAt: capture.capturedAt ?? null,
          resourceId: capture.resourceId ?? null,
          method: capture.method || "POST",
          url: capture.url || null,
          bodyLength: String(capture.body || "").length,
          body: diagnosticText(capture.body || "", 220000),
          parse: parseGwtRequestBody(capture.body || "")
        }
      : null,
    latestTimetableRequest: data.latestTimetableRequest
      ? diagnosticRequestEntry({
          ...data.latestTimetableRequest,
          httpMethod: data.latestTimetableRequest.method,
          rpcMethods: rpcMethodNames(data.latestTimetableRequest.body || ""),
          service: serviceNameFromUrl(data.latestTimetableRequest.url || "")
        })
      : null,
    recentPassive,
    requestHistory: history,
    ...extra
  });
}

async function recordCollectorWeekFailure(model, target, item, responseText, decoded, code) {
  await appendCollectorDiagnostic({
    type: "collector-week-decode",
    code: code || decoded?.code || "COLLECTOR_WEEK_RPC_FAILED",
    resourceId: model?.resourceId ?? null,
    label: model?.label || null,
    path: model?.path || null,
    week: target ? { firstDate: target.firstDate, lastDate: target.lastDate, offset: target.offset } : null,
    request: item
      ? {
          operation: item.operation || null,
          url: item.url || null,
          targetValue: item.targetValue ?? null,
          bodyLength: String(item.body || "").length,
          body: diagnosticText(item.body || "", 220000),
          parse: parseGwtRequestBody(item.body || "")
        }
      : null,
    decoded: decoded || null,
    responseLength: String(responseText || "").length,
    responseAnalysis: analyzeGwtResponse(responseText || ""),
    responseText: diagnosticText(responseText || "", 700000)
  });
}

function decodeRequestBody(requestBody) {
  try {
    if (requestBody?.raw?.length) {
      const decoder = new TextDecoder("utf-8");
      let text = "";

      for (const part of requestBody.raw) {
        if (part.bytes) {
          text += decoder.decode(part.bytes, { stream: true });
        }
      }

      text += decoder.decode();
      return text;
    }

    if (requestBody?.formData) {
      return new URLSearchParams(
        Object.entries(requestBody.formData)
          .flatMap(([key, values]) =>
            (values || []).map((value) => [key, value])
          )
      ).toString();
    }
  } catch {}

  return "";
}

function extractResourceId(body) {
  if (typeof body !== "string") return null;

  // method10getTimetable sérialise la sélection sous la forme :
  //   ArrayList(1) -> Integer(resourceId)
  //   ArrayList(1) -> Integer(week)
  //
  // Pour les petites valeurs de semaine, GWT remplace parfois le second
  // Integer par une back-reference négative (-3 ... -9). L'ancienne regexp
  // dépendait précisément de "-8" et cessait donc d'associer la requête à sa
  // ressource dès que la semaine était sérialisée autrement.
  if (body.includes("method10getTimetable")) {
    const timetable = parseCollectorTimetableRequestBody(body);
    if (timetable?.ok && Number.isInteger(timetable.resourceId)) {
      return timetable.resourceId;
    }
  }

  // Compatibilité avec d'anciennes variantes ADE déjà observées.
  const patterns = [
    /\|11\|(\d{4,})\|10\|1\|-8\|/,
    /\|10\|(\d{4,})\|9\|1\|-8\|/,
    /\|(?:10|11)\|(\d{4,})\|(?:9|10)\|1\|-8\|/
  ];

  for (const pattern of patterns) {
    const match = body.match(pattern);
    if (match) return Number(match[1]);
  }

  return null;
}

function pickSafeHeaders(requestHeaders) {
  const allowed = new Set([
    "content-type",
    "x-gwt-module-base",
    "x-gwt-permutation"
  ]);

  const result = {};

  for (const header of requestHeaders || []) {
    const name = String(header?.name || "").toLowerCase();

    if (!allowed.has(name)) continue;

    result[name] = String(header?.value || "");
  }

  return result;
}

function hhmmToAde(value) {
  const match = String(value || "").match(/^(\d{2}):(\d{2})$/);
  if (!match) return null;
  return `${match[1]}h${match[2]}`;
}

function evidenceAgainstSample(responseText, sampleEvents) {
  const text = String(responseText || "");
  const sample = Array.isArray(sampleEvents)
    ? sampleEvents.slice(0, 30)
    : [];

  if (!text || !sample.length) {
    return {
      checkedEvents: 0,
      titleHits: 0,
      timeHits: 0,
      score: 0
    };
  }

  let titleHits = 0;
  let timeHits = 0;

  for (const event of sample) {
    const title = String(event.title || "").trim();

    if (
      title &&
      title !== "Cours" &&
      text.includes(title)
    ) {
      titleHits += 1;
    }

    const start = hhmmToAde(event.startTime);
    const end = hhmmToAde(event.endTime);

    if (
      start &&
      end &&
      (
        text.includes(`${start} - ${end}`) ||
        text.includes(`${start}-${end}`) ||
        (text.includes(start) && text.includes(end))
      )
    ) {
      timeHits += 1;
    }
  }

  const denom = Math.max(1, sample.length * 2);

  return {
    checkedEvents: sample.length,
    titleHits,
    timeHits,
    score: Number(((titleHits + timeHits) / denom).toFixed(3))
  };
}

function analyzeGwtResponse(responseText) {
  const text = String(responseText || "");
  const result = {
    responseLength: text.length,
    startsWithOk: text.trimStart().startsWith("//OK"),
    jsonParsed: false,
    topLevelLength: null,
    stringCount: 0,
    uniqueStringCount: 0,
    sampleStrings: [],
    timeLikeStrings: [],
    roomLikeStrings: []
  };

  if (!result.startsWithOk) return result;

  let parsed;

  try {
    parsed = JSON.parse(text.trimStart().slice(4));
    result.jsonParsed = true;
  } catch {
    return result;
  }

  if (Array.isArray(parsed)) {
    result.topLevelLength = parsed.length;
  }

  const strings = [];

  function walk(value) {
    if (typeof value === "string") {
      strings.push(value);
      return;
    }

    if (Array.isArray(value)) {
      for (const item of value) walk(item);
      return;
    }

    if (value && typeof value === "object") {
      for (const item of Object.values(value)) walk(item);
    }
  }

  walk(parsed);

  const unique = [...new Set(strings)];

  result.stringCount = strings.length;
  result.uniqueStringCount = unique.length;
  result.sampleStrings = unique
    .filter((value) => value && value.length <= 180)
    .slice(0, 120);

  result.timeLikeStrings = unique
    .filter((value) =>
      /\b\d{1,2}h\d{2}\b/.test(value) ||
      /\b\d{1,2}:\d{2}\b/.test(value)
    )
    .slice(0, 80);

  result.roomLikeStrings = unique
    .filter((value) =>
      /^(?:[A-Z]\s*\d+(?:\.\d+)?|AMP\b|SALLE\b|BATIMENT\b)/i.test(value)
    )
    .slice(0, 80);

  return result;
}

function replaySummary(replay, sampleEvents) {
  const responseText = String(replay?.responseText || "");
  const gwtOk = responseText.trimStart().startsWith("//OK");

  return {
    ok: Boolean(replay?.ok) && gwtOk,
    httpStatus: replay?.httpStatus ?? null,
    gwtOk,
    responseLength: responseText.length,
    evidence: evidenceAgainstSample(responseText, sampleEvents),
    gwtAnalysis: analyzeGwtResponse(responseText),
    responsePreview: responseText
      .slice(0, 280)
      .replace(/\s+/g, " ")
  };
}

function replayAccepted(profile, summary) {
  if (!summary?.ok) return false;

  if (
    profile?.sampleEvents?.length &&
    summary.evidence?.checkedEvents
  ) {
    return (
      summary.evidence.titleHits > 0 ||
      summary.evidence.timeHits > 0
    );
  }

  return true;
}

async function appendCaptureHistory(capture) {
  const data = await storeGet(["timetableRequestHistory"]);
  const history = Array.isArray(data.timetableRequestHistory)
    ? data.timetableRequestHistory
    : [];

  const entry = {
    capturedAt: capture.capturedAt,
    tabId: capture.tabId,
    frameId: capture.frameId,
    method: capture.method,
    url: capture.url,
    resourceId: capture.resourceId,
    headers: capture.headers || {},
    body: capture.body
  };

  const last = history[history.length - 1];

  if (last?.body === entry.body) {
    history[history.length - 1] = entry;
  } else {
    history.push(entry);
  }

  while (history.length > HISTORY_LIMIT) {
    history.shift();
  }

  await storeSet({
    latestTimetableRequest: entry,
    timetableRequestHistory: history
  });
}

function compareRequestBodies(previous, current) {
  if (!previous || !current) return null;

  const a = String(previous.body || "").split("|");
  const b = String(current.body || "").split("|");
  const max = Math.max(a.length, b.length);
  const differences = [];

  for (let index = 0; index < max; index += 1) {
    const before = a[index] ?? null;
    const after = b[index] ?? null;

    if (before === after) continue;

    differences.push({
      index,
      before,
      after
    });

    if (differences.length >= 120) break;
  }

  return {
    previousCapturedAt: previous.capturedAt,
    currentCapturedAt: current.capturedAt,
    previousResourceId: previous.resourceId ?? null,
    currentResourceId: current.resourceId ?? null,
    previousBodyLength: String(previous.body || "").length,
    currentBodyLength: String(current.body || "").length,
    previousTokenCount: a.length,
    currentTokenCount: b.length,
    differenceCountShown: differences.length,
    differences
  };
}


function serviceNameFromUrl(url) {
  try {
    const parsed = new URL(String(url || ""));
    const parts = parsed.pathname.split("/").filter(Boolean);
    return parts[parts.length - 1] || parsed.pathname;
  } catch {
    return String(url || "");
  }
}

function rpcMethodNames(body) {
  const text = String(body || "");
  return [...new Set(
    text.match(/method\d+[A-Za-z0-9_]+/g) || []
  )];
}

function compactRequestEntry(details, body) {
  return {
    at: Date.now(),
    requestId: String(details.requestId || ""),
    tabId: details.tabId,
    frameId: details.frameId,
    httpMethod: String(details.method || ""),
    url: String(details.url || ""),
    service: serviceNameFromUrl(details.url),
    rpcMethods: rpcMethodNames(body),
    resourceId: extractResourceId(body),
    bodyLength: String(body || "").length,
    tokenCount: String(body || "").split("|").length,
    body: String(body || "")
  };
}

function diffBodies(aBody, bBody, limit = 80) {
  const a = String(aBody || "").split("|");
  const b = String(bBody || "").split("|");
  const max = Math.max(a.length, b.length);
  const differences = [];

  for (let i = 0; i < max; i += 1) {
    const before = a[i] ?? null;
    const after = b[i] ?? null;

    if (before === after) continue;

    differences.push({
      index: i,
      before,
      after
    });

    if (differences.length >= limit) break;
  }

  return {
    beforeLength: String(aBody || "").length,
    afterLength: String(bBody || "").length,
    beforeTokenCount: a.length,
    afterTokenCount: b.length,
    differences
  };
}


async function appendV3PassiveRequest(entry) {
  if (
    !entry?.bodyLength ||
    !Array.isArray(entry.rpcMethods) ||
    !entry.rpcMethods.length
  ) {
    return;
  }

  v3PassiveWriteChain =
    v3PassiveWriteChain.then(
      async () => {
        const data =
          await storeGet([
            "v3PassiveEntries",
            "v3SetupState"
          ]);

        const cutoff =
          Date.now() -
          V3_SEQUENCE_MAX_AGE_MS;

        const entries =
          (
            Array.isArray(
              data.v3PassiveEntries
            )
              ? data.v3PassiveEntries
              : []
          )
            .filter(
              (item) =>
                Number(
                  item?.at || 0
                ) >= cutoff
            );

        entries.push(entry);

        while (
          entries.length > 120
        ) {
          entries.shift();
        }

        await storeSet({
          v3PassiveEntries:
            entries
        });

        const setup =
          data.v3SetupState;

        if (
          [
            "waiting_for_ade",
            "waiting_for_login",
            "needs_week_change"
          ].includes(
            setup?.state
          ) &&
          (
            !setup.tabId ||
            setup.tabId ===
              entry.tabId
          )
        ) {
          if (v3FinalizeTimer) {
            clearTimeout(
              v3FinalizeTimer
            );
          }

          v3FinalizeTimer =
            setTimeout(
              () => {
                tryDetectV3Setup()
                  .catch(() => {});
              },
              1600
            );
        }
      }
    )
      .catch(() => {});

  return v3PassiveWriteChain;
}

function extractV3CompleteSequence(
  entries,
  tabId,
  sinceAt = 0
) {
  const candidates =
    (entries || [])
      .filter(
        (entry) =>
          (
            !Number.isInteger(
              tabId
            ) ||
            entry.tabId === tabId
          ) &&
          Number(
            entry?.at || 0
          ) >=
            Number(
              sinceAt || 0
            )
      )
      .sort(
        (a, b) =>
          Number(a.at) -
          Number(b.at)
      );

  let position = 0;
  let current = [];
  let lastComplete = null;

  for (
    const entry
    of candidates
  ) {
    const key =
      operationKey(entry);

    if (
      key ===
      V3_EXPECTED_SEQUENCE[
        position
      ]
    ) {
      current.push(entry);
      position += 1;

      if (
        position ===
        V3_EXPECTED_SEQUENCE.length
      ) {
        lastComplete =
          current.map(
            (item) => ({
              ...item
            })
          );

        position = 0;
        current = [];
      }

      continue;
    }

    if (
      key ===
      V3_EXPECTED_SEQUENCE[0]
    ) {
      position = 1;
      current = [entry];
      continue;
    }

    // Les autres RPC ADE ne cassent pas une séquence en cours.
  }

  return lastComplete;
}


function extractV3FlexibleSequence(
  entries,
  tabId,
  sinceAt = 0
) {
  const exact =
    extractV3CompleteSequence(
      entries,
      tabId,
      sinceAt
    );

  if (exact) {
    return exact;
  }

  const candidates =
    (entries || [])
      .filter(
        (entry) =>
          (
            !Number.isInteger(
              tabId
            ) ||
            entry.tabId === tabId
          ) &&
          Number(
            entry?.at || 0
          ) >=
            Number(
              sinceAt || 0
            )
      )
      .sort(
        (a, b) =>
          Number(a.at) -
          Number(b.at)
      );

  const byOperation =
    new Map();

  for (const entry of candidates) {
    const key =
      operationKey(entry);

    if (
      !V3_EXPECTED_SEQUENCE.includes(
        key
      )
    ) {
      continue;
    }

    if (!byOperation.has(key)) {
      byOperation.set(
        key,
        []
      );
    }

    byOperation
      .get(key)
      .push(entry);
  }

  const requiredSingles = [
    "DirectPlanningPlanningServiceProxy::method6getLegends",
    "CorePlanningServiceProxy::method6getAvailabilities",
    "DirectPlanningPlanningServiceProxy::method10getTimetable",
    "CorePlanningServiceProxy::method43getUnavailabilities"
  ];

  if (
    requiredSingles.some(
      (key) =>
        !byOperation.get(key)?.length
    )
  ) {
    return null;
  }

  const display =
    byOperation.get(
      "CorePlanningServiceProxy::method3getDisplayConfiguration"
    ) || [];

  if (!display.length) {
    return null;
  }

  const latest =
    (key) => {
      const list =
        byOperation.get(key) || [];

      return list[
        list.length - 1
      ] || null;
    };

  const displayFirst =
    display.length >= 2
      ? display[
          display.length - 2
        ]
      : display[0];

  const displaySecond =
    display[
      display.length - 1
    ];

  return [
    latest(
      "DirectPlanningPlanningServiceProxy::method6getLegends"
    ),
    latest(
      "CorePlanningServiceProxy::method6getAvailabilities"
    ),
    latest(
      "DirectPlanningPlanningServiceProxy::method10getTimetable"
    ),
    displayFirst,
    latest(
      "CorePlanningServiceProxy::method43getUnavailabilities"
    ),
    displaySecond
  ].filter(Boolean);
}

function v3SequenceWeekValues(
  sequence
) {
  const values = [];

  for (
    const entry
    of sequence || []
  ) {
    const key =
      operationKey(entry);

    const payloadIndex =
      V3_WEEK_PAYLOAD_INDEX.get(
        key
      );

    if (
      !Number.isInteger(
        payloadIndex
      )
    ) {
      continue;
    }

    if (
      key ===
      "DirectPlanningPlanningServiceProxy::method10getTimetable"
    ) {
      const timetableWeek =
        collectorTimetableWeekValue(
          entry.body
        );

      if (!timetableWeek?.ok) {
        return {
          ok: false,
          code:
            timetableWeek?.code ||
            "V3_GWT_PARSE_FAILED",
          operation:
            key
        };
      }

      values.push({
        operation:
          key,
        payloadIndex:
          timetableWeek.index,
        value:
          timetableWeek.value,
        encoding:
          timetableWeek.encoding || null
      });
      continue;
    }

    const parsed =
      parseGwtRequestBody(
        entry.body
      );

    if (!parsed.ok) {
      return {
        ok: false,
        code:
          "V3_GWT_PARSE_FAILED",
        operation:
          key
      };
    }

    const token =
      parsed.payload[
        payloadIndex
      ];

    if (
      !/^-?\d+$/.test(
        String(token || "")
      )
    ) {
      return {
        ok: false,
        code:
          "V3_WEEK_VALUE_NOT_NUMERIC",
        operation:
          key,
        payloadIndex,
        token:
          token ?? null
      };
    }

    values.push({
      operation:
        key,
      payloadIndex,
      value:
        Number(token)
    });
  }

  if (values.length < 4) {
    return {
      ok: false,
      code:
        "V3_WEEK_VALUES_INCOMPLETE",
      values
    };
  }

  const unique =
    [
      ...new Set(
        values.map(
          (item) =>
            item.value
        )
      )
    ];

  // Les quatre RPC ADE n'utilisent pas toujours la même représentation
  // numérique de la semaine. Selon la méthode, GWT peut sérialiser la valeur
  // directement ou via une back-reference. L'ancienne logique exigeait que
  // les quatre nombres soient identiques, ce qui provoquait les erreurs
  // V3_WEEK_VALUES_DISAGREE sur des EDT pourtant parfaitement valides.
  //
  // Pour générer la semaine précédente, chaque opération peut être traitée
  // indépendamment : son propre jeton doit simplement diminuer de 1.
  const timetable = values.find(
    (item) =>
      item.operation ===
      "DirectPlanningPlanningServiceProxy::method10getTimetable"
  ) || values[0];

  return {
    ok: true,
    code:
      unique.length === 1
        ? "V3_WEEK_VALUES_ALIGNED"
        : "V3_WEEK_VALUES_INDEPENDENT",
    consistent:
      unique.length === 1,
    value:
      timetable?.value ?? unique[0],
    uniqueValues:
      unique,
    values
  };
}

function v3CloneEntryWithWeekValue(
  entry,
  weekValue
) {
  const clone = {
    ...entry,
    rpcMethods:
      Array.isArray(
        entry.rpcMethods
      )
        ? [...entry.rpcMethods]
        : []
  };

  const key =
    operationKey(entry);

  const payloadIndex =
    V3_WEEK_PAYLOAD_INDEX.get(
      key
    );

  if (
    Number.isInteger(
      payloadIndex
    )
  ) {
    const changed =
      key ===
        "DirectPlanningPlanningServiceProxy::method10getTimetable"
        ? rebuildCollectorTimetableWeekBody(
            entry.body,
            weekValue
          )
        : rebuildGwtBodyWithPayloadToken(
            entry.body,
            payloadIndex,
            weekValue
          );

    clone.body =
      changed.body;

    clone.bodyLength =
      clone.body.length;

    clone.tokenCount =
      clone.body
        .split("|")
        .length;
  }

  return clone;
}

function v3BuildSyntheticTracePair(
  sequence,
  currentWeek
) {
  const values =
    v3SequenceWeekValues(
      sequence
    );

  if (!values.ok) {
    return values;
  }

  const currentValue =
    values.value;

  const previousValue =
    currentValue - 1;

  const previousValueByOperation =
    new Map(
      (values.values || []).map(
        (item) => [
          item.operation,
          Number(item.value) - 1
        ]
      )
    );

  const previousWeek = {
    firstDate:
      addDaysIso(
        currentWeek.firstDate,
        -7
      ),
    lastDate:
      addDaysIso(
        currentWeek.lastDate,
        -7
      )
  };

  const twoWeeksBack = {
    firstDate:
      addDaysIso(
        currentWeek.firstDate,
        -14
      ),
    lastDate:
      addDaysIso(
        currentWeek.lastDate,
        -14
      )
  };

  const latestTrace = {
    startedAt:
      nowIso(),
    finishedAt:
      nowIso(),
    beforeWeek:
      previousWeek,
    afterWeek:
      currentWeek,
    requestCount:
      sequence.length,
    entries:
      sequence.map(
        (entry) => ({
          ...entry,
          rpcMethods:
            [...entry.rpcMethods]
        })
      )
  };

  const previousTrace = {
    startedAt:
      nowIso(),
    finishedAt:
      nowIso(),
    beforeWeek:
      twoWeeksBack,
    afterWeek:
      previousWeek,
    requestCount:
      sequence.length,
    entries:
      sequence.map(
        (entry) => {
          const key = operationKey(entry);
          const operationPreviousValue =
            previousValueByOperation.get(key);

          if (Number.isFinite(operationPreviousValue)) {
            return v3CloneEntryWithWeekValue(
              entry,
              operationPreviousValue
            );
          }

          return {
            ...entry,
            rpcMethods:
              Array.isArray(entry.rpcMethods)
                ? [...entry.rpcMethods]
                : []
          };
        }
      )
  };

  return {
    ok: true,
    currentValue,
    previousValue,
    weekValuesConsistent:
      values.consistent !== false,
    weekValues:
      values.values || [],
    traces: [
      previousTrace,
      latestTrace
    ]
  };
}

async function waitForV3Sequence(
  tabId,
  sinceAt,
  timeoutMs =
    V3_SETUP_TIMEOUT_MS
) {
  const started =
    Date.now();

  while (
    Date.now() -
      started <
    timeoutMs
  ) {
    const data =
      await storeGet([
        "v3PassiveEntries"
      ]);

    const sequence =
      extractV3FlexibleSequence(
        data.v3PassiveEntries,
        tabId,
        sinceAt
      );

    if (sequence) {
      return sequence;
    }

    await sleep(350);
  }

  return null;
}

async function v3TabLooksAuthenticated(
  tabId
) {
  try {
    const tab =
      await chrome.tabs.get(
        tabId
      );

    const url =
      String(
        tab?.url || ""
      );

    return (
      url.includes(
        "planning.unilim.fr"
      ) &&
      !/cas|login|auth/i.test(
        url
      )
    );
  } catch {
    return false;
  }
}

async function v3EnsureCurrentContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: {
        tabId,
        allFrames: true
      },
      files: [
        "ade-tree.js",
        "ade-content.js"
      ]
    });
    await sleep(180);
    return true;
  } catch {
    return false;
  }
}

async function v3ScrapePlanningPreview(tabId) {
  await v3EnsureCurrentContentScript(tabId);

  let frames = [];
  try {
    frames = await chrome.webNavigation.getAllFrames({ tabId }) || [];
  } catch {}

  if (!frames.length) {
    frames = [{ frameId: 0, url: "" }];
  }

  const results = [];
  for (const frame of frames) {
    try {
      const result = await chrome.tabs.sendMessage(
        tabId,
        { type: "MON_EDT_V4_SCRAPE_PREVIEW" },
        { frameId: frame.frameId }
      );
      if (!result) continue;
      results.push({
        ...result,
        frameId: frame.frameId,
        frameUrl: frame.url || result?.diagnostics?.href || ""
      });
    } catch {}
  }

  if (!results.length) {
    return {
      ok: false,
      code: "V4_PREVIEW_UNAVAILABLE",
      events: []
    };
  }

  const score = (result) => {
    let value = Number(result?.events?.length || 0) * 1000;
    value += Number(result?.diagnostics?.dayHeaderCount || 0) * 20;
    if (result?.ok) value += 100000;
    if (result?.planningLabel) value += 2500;
    const href = String(result?.frameUrl || result?.diagnostics?.href || "");
    if (href.includes("/direct/myplanning.jsp")) value += 500;
    if (href.includes(".cache.html")) value -= 300;
    return value;
  };

  results.sort((a, b) => score(b) - score(a));
  const best = { ...results[0] };
  if (!best.planningLabel) {
    best.planningLabel = results.find((item) => item?.planningLabel)?.planningLabel || null;
  }
  return best;
}

function v3PreviewResourceId(data, tabId) {
  const previewId = Number(data?.preview?.resourceId ?? data?.preview?.planningResource?.resourceId);
  if (Number.isFinite(previewId)) return previewId;

  const passive = Array.isArray(data?.v3PassiveEntries)
    ? data.v3PassiveEntries
    : [];

  const recent = passive
    .filter((entry) => entry?.tabId === tabId && entry?.resourceId != null)
    .sort((a, b) => Number(b?.at || 0) - Number(a?.at || 0));

  if (recent.length) return recent[0].resourceId;

  const latest = data?.latestTimetableRequest;
  if (latest?.tabId === tabId && latest?.resourceId != null) {
    return latest.resourceId;
  }

  return null;
}

async function tryDetectV3Setup() {
  if (v3FinalizeBusy) {
    return { ok: false, code: "V3_SETUP_BUSY" };
  }

  v3FinalizeBusy = true;
  try {
    const data = await storeGet([
      "v3SetupState",
      "v3PassiveEntries",
      "latestTimetableRequest"
    ]);

    const setup = data.v3SetupState;
    if (!setup || ![
      "waiting_for_ade",
      "waiting_for_login"
    ].includes(setup.state)) {
      return { ok: false, code: "V3_SETUP_NOT_WAITING" };
    }

    let tabId = setup.tabId;
    if (!Number.isInteger(tabId)) {
      const tab = await bestAdeTab();
      tabId = tab?.id;
    }

    if (!Number.isInteger(tabId)) {
      return { ok: false, code: "ADE_NOT_OPEN" };
    }

    const authenticated = await v3TabLooksAuthenticated(tabId);
    if (!authenticated) {
      await storeSet({
        v3SetupState: {
          ...setup,
          state: "waiting_for_login",
          tabId,
          message: "Reconnectez-vous puis ouvrez votre emploi du temps."
        }
      });
      return { ok: false, code: "AUTH_REQUIRED" };
    }

    const preview = await v3ScrapePlanningPreview(tabId);
    if (!preview?.ok || !preview?.week?.firstDate || !preview?.week?.lastDate) {
      await storeSet({
        v3SetupState: {
          ...setup,
          state: "waiting_for_ade",
          tabId,
          message: "Affichez l'emploi du temps que vous souhaitez synchroniser."
        }
      });
      return {
        ok: false,
        code: preview?.code || "V3_VISIBLE_WEEK_UNKNOWN",
        message: "L'emploi du temps n'est pas encore visible."
      };
    }

    const resourceId = v3PreviewResourceId({ ...data, preview }, tabId);
    const planningLabel = preview.planningLabel || null;

    await storeSet({
      v3SetupState: {
        ...setup,
        state: "detected",
        detectedAt: nowIso(),
        tabId,
        resourceId,
        planningLabel,
        week: preview.week,
        previewEventCount: Array.isArray(preview.events) ? preview.events.length : 0,
        message: "Emploi du temps détecté. Vérifiez-le puis validez la synchronisation."
      }
    });

    return {
      ok: true,
      code: "V3_PLANNING_DETECTED",
      tabId,
      resourceId,
      planningLabel,
      week: preview.week,
      eventCount: Array.isArray(preview.events) ? preview.events.length : 0
    };
  } finally {
    v3FinalizeBusy = false;
  }
}


async function v3KickWeekInBestFrame(
  tabId,
  direction = "next",
  targetWeekNumber = null,
  targetFirstDate = null
) {
  let frames = [];

  try {
    frames =
      await chrome.webNavigation
        .getAllFrames({
          tabId
        });
  } catch {}

  if (!frames.length) {
    frames = [{
      frameId: 0,
      url: ""
    }];
  }

  const results = [];

  for (const frame of frames) {
    try {
      const response =
        await chrome.tabs.sendMessage(
          tabId,
          {
            type:
              "MON_EDT_V4_KICK_WEEK",
            direction,
            targetWeekNumber: Number.isInteger(Number(targetWeekNumber))
              ? Number(targetWeekNumber)
              : null,
            targetFirstDate: targetFirstDate || null
          },
          {
            frameId:
              frame.frameId
          }
        );

      results.push({
        frameId:
          frame.frameId,
        frameUrl:
          frame.url ||
          "",
        response
      });

      if (response?.ok) {
        return {
          ok: true,
          code:
            response.code,
          selectedFrameId:
            frame.frameId,
          selectedFrameUrl:
            frame.url ||
            "",
          response,
          triedFrames:
            results.length
        };
      }
    } catch {}
  }

  // Au cas où le content script n'aurait pas encore été injecté
  // dans l'iframe planning, on le réinjecte une fois.
  try {
    await chrome.scripting.executeScript({
      target: {
        tabId,
        allFrames: true
      },
      files: [
        "ade-content.js"
      ]
    });

    await sleep(350);

    const retryFrames =
      await chrome.webNavigation
        .getAllFrames({
          tabId
        })
        .catch(
          () => [{
            frameId: 0,
            url: ""
          }]
        );

    for (
      const frame
      of retryFrames
    ) {
      try {
        const response =
          await chrome.tabs.sendMessage(
            tabId,
            {
              type:
                "MON_EDT_V4_KICK_WEEK",
              direction,
              targetWeekNumber: Number.isInteger(Number(targetWeekNumber))
                ? Number(targetWeekNumber)
                : null,
              targetFirstDate: targetFirstDate || null
            },
            {
              frameId:
                frame.frameId
            }
          );

        if (response?.ok) {
          return {
            ok: true,
            code:
              response.code,
            selectedFrameId:
              frame.frameId,
            selectedFrameUrl:
              frame.url ||
              "",
            response,
            reinjected:
              true
          };
        }
      } catch {}
    }
  } catch {}

  return {
    ok: false,
    code:
      "V3_AUTO_WEEK_KICK_UNAVAILABLE",
    triedFrames:
      results.map(
        (item) => ({
          frameId:
            item.frameId,
          frameUrl:
            item.frameUrl,
          code:
            item.response?.code ||
            null
        })
      )
  };
}

async function v3BootstrapByAutomaticWeekChange(
  tabId,
  sinceAt
) {
  const kick =
    await v3KickWeekInBestFrame(
      tabId
    );

  if (!kick.ok) {
    return {
      ok: false,
      code:
        kick.code,
      kick
    };
  }

  const sequence =
    await waitForV3Sequence(
      tabId,
      sinceAt,
      12000
    );

  if (!sequence) {
    return {
      ok: false,
      code:
        "V3_KICK_DID_NOT_PRODUCE_SEQUENCE",
      kick
    };
  }

  // Laisse ADE terminer le rendu de la nouvelle semaine
  // pour que scrapeVisibleWeek lise les bonnes dates.
  await sleep(700);

  return {
    ok: true,
    code:
      "V3_AUTOMATIC_BOOTSTRAP_READY",
    kick,
    sequence
  };
}


async function v3AcquireStableSequence(
  tabId,
  initialSinceAt,
  maxExtraKicks = 3
) {
  let sinceAt =
    Number(
      initialSinceAt || 0
    );

  let sequence = null;
  let lastValidation = null;
  const attempts = [];

  for (
    let attempt = 0;
    attempt <= maxExtraKicks;
    attempt += 1
  ) {
    const data =
      await storeGet([
        "v3PassiveEntries"
      ]);

    sequence =
      extractV3FlexibleSequence(
        data.v3PassiveEntries,
        tabId,
        sinceAt
      );

    if (!sequence) {
      sequence =
        await waitForV3Sequence(
          tabId,
          sinceAt,
          attempt === 0
            ? 5000
            : 9000
        );
    }

    if (sequence) {
      lastValidation =
        v3SequenceWeekValues(
          sequence
        );

      attempts.push({
        attempt,
        sinceAt,
        sequenceFound:
          true,
        validation:
          lastValidation
      });

      if (lastValidation.ok) {
        if (lastValidation.consistent === false) {
          await recordV3SequenceDiagnostic(
            tabId,
            sequence,
            lastValidation,
            {
              type: "v3-week-values-independent",
              code: "V3_WEEK_VALUES_INDEPENDENT_ACCEPTED",
              attempt,
              sinceAt,
              attempts
            }
          );
        }

        return {
          ok: true,
          code:
            "V3_STABLE_SEQUENCE_READY",
          sequence,
          validation:
            lastValidation,
          attempts
        };
      }
    } else {
      attempts.push({
        attempt,
        sinceAt,
        sequenceFound:
          false,
        validation:
          null
      });
    }

    if (attempt >= maxExtraKicks) {
      break;
    }

    // ADE/GWT sérialise parfois certaines semaines sous forme de
    // back-reference au lieu d'un Integer explicite. C'était notamment
    // le cas de S38 pendant nos tests v2.
    //
    // On ne demande rien à l'utilisateur : on passe automatiquement
    // à la semaine suivante jusqu'à retrouver une représentation stable.
    const kickStartedAt =
      Date.now();

    const kick =
      await v3KickWeekInBestFrame(
        tabId
      );

    attempts[
      attempts.length - 1
    ].kick =
      kick;

    if (!kick.ok) {
      break;
    }

    sinceAt =
      kickStartedAt;

    await sleep(900);
  }

  await recordV3SequenceDiagnostic(
    tabId,
    sequence,
    lastValidation,
    {
      type: "v3-sequence-failure",
      code:
        lastValidation?.code ||
        "V3_STABLE_SEQUENCE_NOT_FOUND",
      attempts
    }
  );

  return {
    ok: false,
    code:
      lastValidation?.code ||
      "V3_STABLE_SEQUENCE_NOT_FOUND",
    message:
      "ADE a bien produit ses RPC, mais la représentation GWT de la semaine n'est pas encore exploitable automatiquement.",
    lastValidation,
    attempts
  };
}

async function finalizeV3BaseFromTab(
  tabId,
  sinceAt = 0
) {
  const data =
    await storeGet([
      "latestTimetableRequest",
      "savedProfile",
      "cachedCurrentWeek",
      "v3SetupState"
    ]);

  const stable =
    await v3AcquireStableSequence(
      tabId,
      sinceAt,
      3
    );

  if (!stable.ok) {
    const previousSetup =
      data.v3SetupState ||
      {};

    await storeSet({
      v3SetupState: {
        ...previousSetup,
        state:
          "waiting_for_ade",
        tabId,
        bootstrapAttempts:
          stable.attempts,
        lastBootstrapCode:
          stable.code,
        message:
          stable.message
      }
    });

    return {
      ok: false,
      code:
        stable.code,
      message:
        stable.message,
      bootstrapAttempts:
        stable.attempts
    };
  }

  const sequence =
    stable.sequence;


  const scrape =
    await scrapeVisibleWeek(
      tabId
    );

  const week =
    scrape?.week ||
    data.cachedCurrentWeek?.week ||
    data.savedProfile?.sampleWeek ||
    null;

  if (
    !week?.firstDate ||
    !week?.lastDate
  ) {
    return {
      ok: false,
      code:
        "V3_VISIBLE_WEEK_UNKNOWN",
      message:
        "La semaine actuellement affichée par ADE n'a pas encore pu être déterminée."
    };
  }

  const synthetic =
    v3BuildSyntheticTracePair(
      sequence,
      week
    );

  if (!synthetic.ok) {
    return {
      ...synthetic,
      message:
        synthetic.code ===
          "V3_WEEK_VALUE_NOT_NUMERIC"
          ? "La représentation de cette semaine n'est pas encore exploitable. L'extension va réessayer automatiquement après validation."
          : "La base ADE n'est pas encore exploitable automatiquement."
    };
  }

  let capture =
    data.latestTimetableRequest ||
    null;

  const timetableEntry =
    sequence.find(
      (entry) =>
        entry.rpcMethods?.includes(
          "method10getTimetable"
        )
    );

  if (
    !capture ||
    (
      Number.isInteger(
        capture.tabId
      ) &&
      capture.tabId !== tabId
    )
  ) {
    capture = {
      capturedAt:
        Date.now(),
      tabId,
      frameId:
        timetableEntry?.frameId ??
        0,
      method:
        timetableEntry?.httpMethod ||
        "POST",
      url:
        timetableEntry?.url ||
        "",
      body:
        timetableEntry?.body ||
        "",
      resourceId:
        timetableEntry?.resourceId ??
        extractResourceId(
          timetableEntry?.body
        ),
      headers:
        data.savedProfile
          ?.rpcTemplate
          ?.headers ||
        {}
    };
  }

  const template =
    requestTemplateFromCapture(
      capture
    );

  if (
    !template.url ||
    !template.body
  ) {
    return {
      ok: false,
      code:
        "V3_TIMETABLE_TEMPLATE_MISSING",
      message:
        "Le RPC getTimetable est présent mais son modèle de requête n'est pas complet."
    };
  }

  const resourceId =
    scrape?.resourceId ??
    scrape?.planningResource?.resourceId ??
    capture.resourceId ??
    timetableEntry?.resourceId ??
    extractResourceId(
      timetableEntry?.body
    ) ??
    data.savedProfile?.resourceId ??
    null;

  const sampleEvents =
    Array.isArray(
      scrape?.events
    )
      ? scrape.events
      : (
          data.savedProfile
            ?.sampleEvents ||
          []
        );

  const profile = {
    savedAt:
      nowIso(),
    mode:
      "v3-auto-bootstrap",
    resourceId,
    planningLabel:
      scrape?.planningResource?.label ||
      scrape?.planningLabel ||
      data.v3SetupState?.planningLabel ||
      null,
    planningPath:
      scrape?.planningResource?.path ||
      data.v3SetupState?.planningPath ||
      null,
    rpcTemplate:
      template,
    sampleWeek:
      week,
    sampleEvents,
    autoSyncEnabled:
      true
  };

  await storeSet({
    savedProfile:
      profile,
    weekTraces:
      synthetic.traces,
    v3RuntimeBase: {
      capturedAt:
        nowIso(),
      tabId,
      resourceId,
      week,
      weekValue:
        synthetic.currentValue,
      sequence:
        sequence.map(
          (entry) => ({
            ...entry,
            rpcMethods:
              [...entry.rpcMethods]
          })
        )
    },
    v3SetupState: {
      state:
        "configured",
      configuredAt:
        nowIso(),
      tabId,
      resourceId,
      week
    },
    lastSuccessfulSyncAt:
      data.lastSuccessfulSyncAt ||
      null
  });

  await chrome.alarms.create(
    ALARM_NAME,
    {
      periodInMinutes:
        AUTO_SYNC_MINUTES
    }
  );

  return {
    ok: true,
    code:
      "V3_BASE_READY",
    message:
      "ADE est prêt. La séquence RPC fraîche a été détectée automatiquement.",
    resourceId,
    week,
    weekValue:
      synthetic.currentValue,
    eventCount:
      sampleEvents.length
  };
}

async function tryFinalizeV3Setup() {
  // Compatibilité avec les anciennes routes internes : pendant la phase de
  // sélection, on ne modifie plus jamais la semaine affichée.
  return await tryDetectV3Setup();
}

async function v3Connect() {
  const tabs = await adeTabs();

  let tab =
    tabs.find((item) => item.url?.includes("/direct/myplanning.jsp")) ||
    tabs[0] ||
    null;

  let tabId;
  const existingAde = Boolean(tab?.id);

  if (existingAde) {
    tabId = tab.id;
    await chrome.tabs.update(tabId, { active: true });
  } else {
    tab = await chrome.tabs.create({
      url: ADE_URL,
      active: true
    });
    tabId = tab.id;
  }

  const startedAtMs = Date.now();

  await storeSet({
    v3SetupState: {
      state: "waiting_for_ade",
      startedAt: nowIso(),
      startedAtMs,
      tabId,
      existingAde,
      message: "Affichez l'emploi du temps que vous souhaitez synchroniser."
    }
  });

  // Important : aucune navigation de semaine à cette étape.
  // On injecte seulement le lecteur dans la page déjà ouverte afin que
  // l'installation / mise à jour de l'extension ne nécessite pas de reload.
  if (existingAde) {
    await v3EnsureCurrentContentScript(tabId);
  }

  const detectLater = (delay) => {
    setTimeout(() => {
      tryDetectV3Setup().catch(() => {});
    }, delay);
  };

  detectLater(existingAde ? 250 : 1800);
  detectLater(existingAde ? 900 : 3500);
  detectLater(existingAde ? 2200 : 6500);

  return {
    ok: true,
    code: "V3_CONNECT_OPENED",
    message: existingAde
      ? "L'emploi du temps affiché est en cours de détection. Aucune semaine ne sera changée avant votre validation."
      : "Connectez-vous puis affichez l'emploi du temps souhaité. Aucune semaine ne sera changée avant votre validation.",
    tabId,
    existingAde
  };
}

async function v3MarkSelectedTabClosed(tabId) {
  const data = await storeGet(["v3SetupState"]);
  const setup = data.v3SetupState || null;
  const cancellableStates = [
    "waiting_for_ade",
    "waiting_for_login",
    "detected"
  ];

  if (!setup || setup.tabId !== tabId || !cancellableStates.includes(setup.state)) {
    return { ok: false, code: "V3_SETUP_TAB_NOT_SELECTED" };
  }

  await storeSet({
    v3SetupState: {
      ...setup,
      state: "ade_closed",
      closedAt: nowIso(),
      message: "ADE a été fermé avant la validation. La sélection a été annulée."
    }
  });

  return { ok: true, code: "V3_SETUP_CANCELLED_ADE_CLOSED" };
}

async function v3PrepareApprovedTabBase(tabId) {
  if (!Number.isInteger(tabId)) {
    return { ok: false, code: "ADE_TAB_MISSING" };
  }

  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) {
    return { ok: false, code: "ADE_TAB_MISSING" };
  }

  const authenticated = await v3TabLooksAuthenticated(tabId);
  if (!authenticated) {
    try {
      await chrome.tabs.update(tabId, { active: true });
    } catch {}
    return {
      ok: false,
      code: "AUTH_REQUIRED",
      keepTab: true,
      tabId
    };
  }

  await v3EnsureCurrentContentScript(tabId);
  await storeSet({ v3PassiveEntries: [] });

  let startedAt = Date.now();
  let kick = await v3KickWeekInBestFrame(tabId);

  if (!kick.ok) {
    // Le seul fallback est désormais automatique et n'arrive qu'après
    // validation explicite de l'utilisateur. Cela remplace le reload manuel.
    startedAt = Date.now();
    try {
      await chrome.tabs.reload(tabId);
      await waitTab(tabId, 25000);
      await sleep(1100);
      await v3EnsureCurrentContentScript(tabId);
    } catch {}
  } else {
    await sleep(850);
  }

  const finalized = await finalizeV3BaseFromTab(tabId, startedAt);
  if (!finalized?.ok) {
    return finalized;
  }

  return {
    ...finalized,
    tabId,
    initializedTab: true,
    approvedTab: true
  };
}

async function v3OpenFreshBaseAttempt() {
  const startedAt =
    Date.now();

  const tab =
    await chrome.tabs.create({
      url:
        ADE_URL,
      active:
        false
    });

  let keepInitializedTab =
    false;

  try {
    await waitTab(
      tab.id,
      25000
    );

    await sleep(1200);

    const auth =
      await v3TabLooksAuthenticated(
        tab.id
      );

    if (!auth) {
      await chrome.tabs.update(
        tab.id,
        {
          active: true
        }
      );

      return {
        ok: false,
        code:
          "AUTH_REQUIRED",
        keepTab:
          true,
        tabId:
          tab.id
      };
    }

    const profileData = await storeGet(["savedProfile"]);
    const savedProfile = profileData.savedProfile || null;
    if (savedProfile?.resourceId != null) {
      await v3EnsureCurrentContentScript(tab.id);
      const restored = await planningFrameMessage(tab.id, {
        type: "PLANILIM_ADE_SELECT_RESOURCE",
        target: {
          resourceId: savedProfile.resourceId,
          label: savedProfile.planningLabel || null,
          path: savedProfile.planningPath || null
        }
      });
      if (!restored?.ok) {
        return {
          ok: false,
          code: "V3_RESOURCE_RESTORE_FAILED",
          message: "ADE est ouvert, mais la formation enregistrée n'a pas pu être restaurée automatiquement.",
          restore: restored
        };
      }
      await sleep(850);
    }

    // On laisse finalizeV3BaseFromTab piloter tout le bootstrap.
    // Si le chargement initial ne fournit pas encore la séquence utile,
    // il déclenche lui-même de vrais changements de semaine dans ADE.
    // Cela évite d'abandonner trop tôt sur un onglet pourtant authentifié.
    const finalized =
      await finalizeV3BaseFromTab(
        tab.id,
        startedAt
      );

    if (finalized?.ok) {
      keepInitializedTab =
        true;

      return {
        ...finalized,
        tabId:
          tab.id,
        initializedTab:
          true
      };
    }

    return finalized;
  } finally {
    const current =
      await chrome.tabs.get(
        tab.id
      ).catch(
        () => null
      );

    if (
      current &&
      !current.active &&
      !keepInitializedTab
    ) {
      try {
        await chrome.tabs.remove(
          tab.id
        );
      } catch {}
    }
  }
}

async function v3RefreshFreshBase() {
  let last = null;

  for (
    let attempt = 1;
    attempt <= 2;
    attempt += 1
  ) {
    last =
      await v3OpenFreshBaseAttempt();

    if (last?.ok) {
      return {
        ...last,
        attempt
      };
    }

    if (
      last?.code ===
      "AUTH_REQUIRED"
    ) {
      return last;
    }

    await sleep(900);
  }

  return {
    ok: false,
    code:
      "V3_BASE_REFRESH_FAILED",
    message:
      "ADE n'a pas fourni de base RPC fraîche exploitable après deux tentatives automatiques. Aucune synchronisation massive n'a été lancée.",
    lastAttempt:
      last
  };
}

async function v3CloseBootstrapTab(tabId, keepForAuth = false, preserveTab = false) {
  if (!Number.isInteger(tabId)) {
    return;
  }

  const current =
    await chrome.tabs.get(
      tabId
    ).catch(
      () => null
    );

  if (!current) {
    return;
  }

  if (preserveTab) {
    return;
  }

  if (keepForAuth) {
    try {
      await chrome.tabs.update(
        tabId,
        { active: true }
      );
    } catch {}

    return;
  }

  if (!current.active) {
    try {
      await chrome.tabs.remove(
        tabId
      );
    } catch {}
  }
}

async function v3StableFullSync(options = {}) {
  await storeSet({
    v3SyncState: {
      state:
        "preparing_fresh_base",
      startedAt:
        nowIso()
    }
  });

  let base =
    null;
  let result =
    null;

  try {
    const setupData = await storeGet(["v3SetupState"]);
    const setup = setupData.v3SetupState || null;
    const approvedTabId = Number.isInteger(setup?.tabId)
      ? setup.tabId
      : null;

    if (setup?.state === "detected" && approvedTabId !== null) {
      const approvedTab = await chrome.tabs.get(approvedTabId).catch(() => null);
      if (approvedTab) {
        await storeSet({
          v3SetupState: {
            ...setup,
            state: "bootstrapping",
            confirmedAt: nowIso(),
            message: "Synchronisation en préparation."
          }
        });
        base = await v3PrepareApprovedTabBase(approvedTabId);
      } else {
        base = await v3RefreshFreshBase();
      }
    } else if (approvedTabId !== null) {
      const existing = await chrome.tabs.get(approvedTabId).catch(() => null);
      base = existing
        ? await v3PrepareApprovedTabBase(approvedTabId)
        : await v3RefreshFreshBase();
    } else {
      base = await v3RefreshFreshBase();
    }

    if (!base.ok) {
      const currentSetupData = await storeGet(["v3SetupState"]);
      const currentSetup = currentSetupData.v3SetupState || {};
      await storeSet({
        v3SyncState: {
          state:
            base.code ===
              "AUTH_REQUIRED"
              ? "auth_required"
              : "failed",
          finishedAt:
            nowIso(),
          code:
            base.code,
          message:
            base.message ||
            null
        },
        v3SetupState: {
          ...currentSetup,
          state:
            base.code === "AUTH_REQUIRED"
              ? "waiting_for_login"
              : "detected",
          message:
            base.code === "AUTH_REQUIRED"
              ? "Reconnectez-vous puis réaffichez votre emploi du temps."
              : "La préparation a échoué. L'emploi du temps reste sélectionné et vous pouvez réessayer."
        }
      });

      return base;
    }

    await storeSet({
      v3SyncState: {
        state:
          "syncing",
        startedAt:
          nowIso(),
        resourceId:
          base.resourceId,
        week:
          base.week,
        tabId:
          base.tabId
      }
    });

    // Point important de v3.0.4 : le même onglet qui vient de
    // terminer l'initialisation GWT sert aux 44 semaines. On ne
    // recrée plus un onglet vierge entre le bootstrap et les RPC.
    result =
      await syncFullAcademicYear({
        tabId:
          base.tabId,
        forceFullSequence: options.forceFullSequence === true,
        weekConcurrency: options.weekConcurrency ?? 1,
        delayMs: options.delayMs
      });

    await storeSet({
      v3SyncState: {
        state:
          result?.ok
            ? "ready"
            : (
                result?.code ===
                  "AUTH_REQUIRED"
                  ? "auth_required"
                  : "failed"
              ),
        finishedAt:
          nowIso(),
        code:
          result?.code ||
          null,
        message:
          result?.message ||
          null
      }
    });

    if (result?.ok) {
      const setupData = await storeGet(["v3SetupState"]);
      await storeSet({
        v3SetupState: {
          ...(setupData.v3SetupState || {}),
          state: "ready",
          finishedAt: nowIso(),
          lastSyncCode: result?.code || null
        }
      });
    }

    if (options?.notifyUser && result?.ok) {
      await notifyManualSyncSuccess(result);
    }

    return result;
  } finally {
    // La fermeture d'un onglet ne doit jamais retenir le résultat d'une
    // synchronisation déjà terminée (certains Chromium ne résolvent pas
    // toujours tabs.get/remove lorsque l'onglet change d'état au même instant).
    await Promise.race([
      v3CloseBootstrapTab(
        base?.tabId,
        result?.code ===
          "AUTH_REQUIRED",
        options?.preserveTab === true
      ),
      sleep(2500)
    ]);
  }
}

async function v3StableSmartSync() {
  let base =
    null;
  let result =
    null;

  try {
    base =
      await v3RefreshFreshBase();

    if (!base.ok) {
      return base;
    }

    result =
      await smartAcademicRefresh({
        tabId:
          base.tabId
      });

    return result;
  } finally {
    await v3CloseBootstrapTab(
      base?.tabId,
      result?.code ===
        "AUTH_REQUIRED"
    );
  }
}

async function v3ResetConnection() {
  await chrome.storage.local.remove([
    "savedProfile",
    "weekTraces",
    "v3RuntimeBase",
    "v3SetupState",
    "v3SyncState",
    "v3PassiveEntries"
  ]);

  return {
    ok: true,
    code:
      "V3_CONNECTION_RESET",
    message:
      "La connexion ADE a été réinitialisée. Le cache annuel déjà synchronisé n'a pas été supprimé."
  };
}

async function appendWeekTraceRequest(entry) {
  traceWriteChain = traceWriteChain.then(async () => {
    const data = await storeGet([
      "weekTraceActive",
      "weekTraceEntries"
    ]);

    if (!data.weekTraceActive) return;

    const entries = Array.isArray(data.weekTraceEntries)
      ? data.weekTraceEntries
      : [];

    // Ignore GETs/resources with no RPC body.
    if (!entry.bodyLength || !entry.rpcMethods.length) return;

    entries.push(entry);

    if (entries.length > 250) {
      entries.splice(0, entries.length - 250);
    }

    await storeSet({
      weekTraceEntries: entries
    });
  }).catch(() => {});

  return traceWriteChain;
}

async function startWeekTrace() {
  const tab = await bestAdeTab();

  if (!tab) {
    return {
      ok: false,
      code: "ADE_NOT_OPEN",
      message: "Ouvre ADE sur la semaine de départ avant de lancer la trace."
    };
  }

  const before = await scrapeVisibleWeek(tab.id);

  await storeSet({
    weekTraceActive: true,
    weekTraceStartedAt: nowIso(),
    weekTraceBeforeWeek: before?.week || null,
    weekTraceEntries: []
  });

  return {
    ok: true,
    code: "WEEK_TRACE_STARTED",
    message:
      "Trace démarrée. Change maintenant UNE SEULE fois de semaine dans ADE, attends le chargement, puis clique « Arrêter la trace ».",
    beforeWeek: before?.week || null
  };
}

async function stopWeekTrace() {
  const data = await storeGet([
    "weekTraceActive",
    "weekTraceStartedAt",
    "weekTraceBeforeWeek",
    "weekTraceEntries",
    "weekTraces"
  ]);

  if (!data.weekTraceActive) {
    return {
      ok: false,
      code: "NO_ACTIVE_WEEK_TRACE",
      message: "Aucune trace de semaine n'est en cours."
    };
  }

  const tab = await bestAdeTab();
  const after = tab
    ? await scrapeVisibleWeek(tab.id)
    : { week: null };

  const trace = {
    startedAt: data.weekTraceStartedAt || null,
    finishedAt: nowIso(),
    beforeWeek: data.weekTraceBeforeWeek || null,
    afterWeek: after?.week || null,
    requestCount: Array.isArray(data.weekTraceEntries)
      ? data.weekTraceEntries.length
      : 0,
    entries: Array.isArray(data.weekTraceEntries)
      ? data.weekTraceEntries
      : []
  };

  const traces = Array.isArray(data.weekTraces)
    ? data.weekTraces
    : [];

  traces.push(trace);

  while (traces.length > 6) {
    traces.shift();
  }

  await storeSet({
    weekTraceActive: false,
    weekTraceEntries: [],
    weekTraces: traces
  });

  return {
    ok: true,
    code: "WEEK_TRACE_SAVED",
    message: "Trace enregistrée.",
    trace: {
      beforeWeek: trace.beforeWeek,
      afterWeek: trace.afterWeek,
      requestCount: trace.requestCount,
      requests: trace.entries.map((entry) => ({
        service: entry.service,
        rpcMethods: entry.rpcMethods,
        resourceId: entry.resourceId,
        bodyLength: entry.bodyLength,
        tokenCount: entry.tokenCount
      }))
    },
    savedTraceCount: traces.length
  };
}

function summarizeTrace(trace) {
  return {
    startedAt: trace?.startedAt || null,
    finishedAt: trace?.finishedAt || null,
    beforeWeek: trace?.beforeWeek || null,
    afterWeek: trace?.afterWeek || null,
    requestCount: trace?.requestCount || 0,
    requests: (trace?.entries || []).map((entry, index) => ({
      index,
      service: entry.service,
      rpcMethods: entry.rpcMethods,
      resourceId: entry.resourceId,
      bodyLength: entry.bodyLength,
      tokenCount: entry.tokenCount
    }))
  };
}

function compareTraces(a, b) {
  const aEntries = a?.entries || [];
  const bEntries = b?.entries || [];
  const max = Math.max(aEntries.length, bEntries.length);
  const comparisons = [];

  for (let i = 0; i < max; i += 1) {
    const left = aEntries[i] || null;
    const right = bEntries[i] || null;

    if (!left || !right) {
      comparisons.push({
        index: i,
        left: left
          ? {
              service: left.service,
              rpcMethods: left.rpcMethods
            }
          : null,
        right: right
          ? {
              service: right.service,
              rpcMethods: right.rpcMethods
            }
          : null,
        alignment: "missing-side"
      });
      continue;
    }

    const sameOperation =
      left.service === right.service &&
      JSON.stringify(left.rpcMethods) === JSON.stringify(right.rpcMethods);

    const diff = diffBodies(left.body, right.body);

    comparisons.push({
      index: i,
      sameOperation,
      left: {
        service: left.service,
        rpcMethods: left.rpcMethods,
        resourceId: left.resourceId
      },
      right: {
        service: right.service,
        rpcMethods: right.rpcMethods,
        resourceId: right.resourceId
      },
      bodyDiff: diff
    });
  }

  return comparisons;
}


function parseGwtRequestBody(body) {
  const raw = String(body || "");
  const tokens = raw.split("|");

  const version = Number(tokens[0]);
  const flags = Number(tokens[1]);
  const stringTableCount = Number(tokens[2]);

  const validHeader =
    Number.isInteger(version) &&
    Number.isInteger(flags) &&
    Number.isInteger(stringTableCount) &&
    stringTableCount >= 0 &&
    tokens.length >= 3 + stringTableCount;

  if (!validHeader) {
    return {
      ok: false,
      code: "INVALID_GWT_HEADER",
      rawLength: raw.length,
      tokenCount: tokens.length,
      version: Number.isFinite(version) ? version : null,
      flags: Number.isFinite(flags) ? flags : null,
      stringTableCount: Number.isFinite(stringTableCount)
        ? stringTableCount
        : null
    };
  }

  const strings = tokens
    .slice(3, 3 + stringTableCount)
    .map((value, index) => ({
      index: index + 1,
      value
    }));

  const payload = tokens.slice(3 + stringTableCount);

  const annotatedPayload = payload.map((token, index) => {
    const numeric = /^-?\d+$/.test(token)
      ? Number(token)
      : null;

    const possibleStringRef =
      Number.isInteger(numeric) &&
      numeric >= 1 &&
      numeric <= strings.length
        ? strings[numeric - 1]?.value ?? null
        : null;

    return {
      index,
      token,
      possibleStringRef
    };
  });

  return {
    ok: true,
    version,
    flags,
    stringTableCount,
    rawLength: raw.length,
    tokenCount: tokens.length,
    strings,
    payloadTokenCount: payload.length,
    payload,
    annotatedPayload
  };
}


function gwtStringRefIndex(parsed, matcher) {
  const entry = (parsed?.strings || []).find((item) => matcher(String(item?.value || "")));
  return Number.isInteger(entry?.index) ? entry.index : null;
}

function resolveCollectorTimetableIntegerBackReference(parsed, token) {
  const numeric = Number(token);
  if (!Number.isInteger(numeric) || numeric >= 0) return null;

  const payload = parsed?.payload || [];
  const selectionRef = gwtStringRefIndex(
    parsed,
    (value) => value.includes("PlanningSelection/")
  );
  const arrayRef = gwtStringRefIndex(
    parsed,
    (value) => value.startsWith("java.util.ArrayList/")
  );
  const integerRef = gwtStringRefIndex(
    parsed,
    (value) => value.startsWith("java.lang.Integer/")
  );

  if (![selectionRef, arrayRef, integerRef].every(Number.isInteger)) return null;

  // Dans PlanningSelection, ADE écrit d'abord un ArrayList contenant les
  // entiers 0..6. GWT attribue les références objet dans cet ordre :
  // PlanningSelection = #1, ArrayList = #2, Integer(0) = #3, etc.
  // Une semaine 0..6 peut donc apparaître sous forme -3..-9 au lieu de
  // "IntegerType|valeur". On résout la référence à partir du flux lui-même
  // plutôt que de supposer que le jeton de semaine occupe toujours l'index 42.
  const selectionIndex = payload.findIndex(
    (value, index) =>
      String(value) === String(selectionRef) &&
      String(payload[index + 1] ?? "") === String(arrayRef)
  );

  if (selectionIndex < 0) return null;

  const cachedCount = Number(payload[selectionIndex + 2]);
  if (!Number.isInteger(cachedCount) || cachedCount < 1 || cachedCount > 64) return null;

  const objectRef = Math.abs(numeric);
  const firstCachedIntegerObjectRef = 3;
  const offset = objectRef - firstCachedIntegerObjectRef;
  if (offset < 0 || offset >= cachedCount) return null;

  const pairIndex = selectionIndex + 3 + offset * 2;
  if (String(payload[pairIndex] ?? "") !== String(integerRef)) return null;

  const value = Number(payload[pairIndex + 1]);
  return Number.isInteger(value) ? value : null;
}

function parseCollectorTimetableRequestBody(body) {
  const parsed = parseGwtRequestBody(body);
  if (!parsed?.ok) {
    return {
      ok: false,
      code: "COLLECTOR_GWT_PARSE_FAILED",
      parsed
    };
  }

  const payload = parsed.payload || [];
  const arrayRef = gwtStringRefIndex(
    parsed,
    (value) => value.startsWith("java.util.ArrayList/")
  );
  const integerRef = gwtStringRefIndex(
    parsed,
    (value) => value.startsWith("java.lang.Integer/")
  );

  if (!Number.isInteger(arrayRef) || !Number.isInteger(integerRef)) {
    return {
      ok: false,
      code: "COLLECTOR_GWT_TYPES_MISSING",
      parsed
    };
  }

  const candidates = [];

  for (let i = 0; i <= payload.length - 7; i += 1) {
    if (
      String(payload[i]) !== String(arrayRef) ||
      String(payload[i + 1]) !== "1" ||
      String(payload[i + 2]) !== String(integerRef) ||
      !/^\d{4,}$/.test(String(payload[i + 3] ?? "")) ||
      String(payload[i + 4]) !== String(arrayRef) ||
      String(payload[i + 5]) !== "1"
    ) {
      continue;
    }

    const resourceId = Number(payload[i + 3]);
    const weekHead = String(payload[i + 6] ?? "");

    if (weekHead === String(integerRef)) {
      const rawValue = String(payload[i + 7] ?? "");
      if (!/^-?\d+$/.test(rawValue)) continue;

      candidates.push({
        resourceId,
        resourcePayloadIndex: i + 3,
        weekValue: Number(rawValue),
        weekEncoding: "literal",
        weekEncodingIndex: i + 6,
        weekEncodingLength: 2,
        weekValueIndex: i + 7,
        integerTypeRef: integerRef,
        arrayTypeRef: arrayRef
      });
      continue;
    }

    if (/^-\d+$/.test(weekHead)) {
      const resolved = resolveCollectorTimetableIntegerBackReference(parsed, weekHead);
      if (!Number.isInteger(resolved)) continue;

      candidates.push({
        resourceId,
        resourcePayloadIndex: i + 3,
        weekValue: resolved,
        weekEncoding: "backref",
        weekEncodingIndex: i + 6,
        weekEncodingLength: 1,
        weekValueIndex: null,
        weekBackReference: Number(weekHead),
        integerTypeRef: integerRef,
        arrayTypeRef: arrayRef
      });
    }
  }

  if (!candidates.length) {
    return {
      ok: false,
      code: "COLLECTOR_TIMETABLE_SELECTION_NOT_FOUND",
      parsed
    };
  }

  // La structure visée se trouve à la fin de PlanningSelection. Si une future
  // variante GWT crée plusieurs motifs ressemblants, le dernier est le plus
  // proche des arguments réels resource/week de getTimetable.
  const selected = candidates[candidates.length - 1];

  return {
    ok: true,
    code: selected.weekEncoding === "backref"
      ? "COLLECTOR_TIMETABLE_BACKREF_RESOLVED"
      : "COLLECTOR_TIMETABLE_LITERAL_PARSED",
    parsed,
    ...selected
  };
}

function rebuildCollectorTimetableWeekBody(body, replacement) {
  const timetable = parseCollectorTimetableRequestBody(body);
  if (!timetable?.ok) {
    throw new Error(timetable?.code || "COLLECTOR_TIMETABLE_PARSE_FAILED");
  }

  const value = Number(replacement);
  if (!Number.isInteger(value)) {
    throw new Error(`Valeur de semaine invalide: ${replacement}`);
  }

  const tokens = String(body || "").split("|");
  const payloadStart = 3 + Number(timetable.parsed.stringTableCount);
  const absoluteIndex = payloadStart + Number(timetable.weekEncodingIndex);

  // Une back-reference GWT ne peut pas être remplacée localement par un nouvel
  // objet Integer sans renuméroter les références d'objets qui suivent. C'est
  // précisément ce qui provoquait des HTTP 500 en 4.5.8. Les modèles utilisés
  // pour le replay doivent donc provenir d'une vraie requête ADE littérale.
  if (timetable.weekEncoding !== "literal") {
    throw new Error("COLLECTOR_UNSAFE_BACKREF_TEMPLATE");
  }

  // Le type Integer existe déjà dans le flux : on ne change que sa valeur,
  // donc la longueur et la table d'objets GWT restent strictement identiques.
  tokens.splice(
    absoluteIndex + 1,
    1,
    String(value)
  );

  return {
    body: tokens.join("|"),
    before: timetable.weekValue,
    after: value,
    resourceId: timetable.resourceId,
    weekEncoding: timetable.weekEncoding,
    weekEncodingIndex: timetable.weekEncodingIndex
  };
}

function stringTableSemanticDiff(leftParsed, rightParsed) {
  const left = leftParsed?.strings || [];
  const right = rightParsed?.strings || [];

  const leftValues = left.map((item) => item.value);
  const rightValues = right.map((item) => item.value);

  const leftSet = new Set(leftValues);
  const rightSet = new Set(rightValues);

  const added = right
    .filter((item) => !leftSet.has(item.value))
    .map((item) => ({
      index: item.index,
      value: item.value
    }));

  const removed = left
    .filter((item) => !rightSet.has(item.value))
    .map((item) => ({
      index: item.index,
      value: item.value
    }));

  const sameValueMoved = [];

  for (const item of left) {
    const rightIndex = rightValues.indexOf(item.value);

    if (
      rightIndex >= 0 &&
      rightIndex + 1 !== item.index
    ) {
      sameValueMoved.push({
        value: item.value,
        beforeIndex: item.index,
        afterIndex: rightIndex + 1
      });
    }
  }

  const max = Math.max(left.length, right.length);
  const indexChanges = [];

  for (let index = 0; index < max; index += 1) {
    const before = left[index]?.value ?? null;
    const after = right[index]?.value ?? null;

    if (before === after) continue;

    indexChanges.push({
      stringIndex: index + 1,
      before,
      after
    });
  }

  return {
    beforeCount: left.length,
    afterCount: right.length,
    added,
    removed,
    sameValueMoved: sameValueMoved.slice(0, 80),
    indexChanges: indexChanges.slice(0, 120)
  };
}

function lcsTokenDiff(leftTokens, rightTokens) {
  const a = Array.isArray(leftTokens) ? leftTokens : [];
  const b = Array.isArray(rightTokens) ? rightTokens : [];

  const rows = a.length + 1;
  const cols = b.length + 1;
  const dp = Array.from(
    { length: rows },
    () => Array(cols).fill(0)
  );

  for (let i = a.length - 1; i >= 0; i -= 1) {
    for (let j = b.length - 1; j >= 0; j -= 1) {
      if (a[i] === b[j]) {
        dp[i][j] = dp[i + 1][j + 1] + 1;
      } else {
        dp[i][j] = Math.max(
          dp[i + 1][j],
          dp[i][j + 1]
        );
      }
    }
  }

  const operations = [];
  let i = 0;
  let j = 0;

  while (i < a.length || j < b.length) {
    if (
      i < a.length &&
      j < b.length &&
      a[i] === b[j]
    ) {
      operations.push({
        type: "equal",
        beforeIndex: i,
        afterIndex: j,
        value: a[i]
      });
      i += 1;
      j += 1;
      continue;
    }

    const deleteScore =
      i < a.length
        ? dp[i + 1]?.[j] ?? -1
        : -1;

    const insertScore =
      j < b.length
        ? dp[i]?.[j + 1] ?? -1
        : -1;

    if (
      j < b.length &&
      (
        i >= a.length ||
        insertScore >= deleteScore
      )
    ) {
      operations.push({
        type: "insert",
        beforeIndex: i,
        afterIndex: j,
        value: b[j]
      });
      j += 1;
    } else if (i < a.length) {
      operations.push({
        type: "delete",
        beforeIndex: i,
        afterIndex: j,
        value: a[i]
      });
      i += 1;
    }
  }

  const edits = operations.filter(
    (operation) => operation.type !== "equal"
  );

  const compact = [];
  let current = null;

  for (const operation of operations) {
    if (operation.type === "equal") {
      current = null;
      continue;
    }

    const key = operation.type;

    if (
      !current ||
      current.type !== key
    ) {
      current = {
        type: key,
        operations: []
      };
      compact.push(current);
    }

    current.operations.push(operation);
  }

  return {
    beforeTokenCount: a.length,
    afterTokenCount: b.length,
    lcsLength: dp[0][0],
    editCount: edits.length,
    edits: edits.slice(0, 160),
    compactEdits: compact.slice(0, 80)
  };
}

function semanticRequestDiff(leftBody, rightBody) {
  const left = parseGwtRequestBody(leftBody);
  const right = parseGwtRequestBody(rightBody);

  if (!left.ok || !right.ok) {
    return {
      ok: false,
      left,
      right
    };
  }

  return {
    ok: true,
    header: {
      version: {
        before: left.version,
        after: right.version
      },
      flags: {
        before: left.flags,
        after: right.flags
      },
      stringTableCount: {
        before: left.stringTableCount,
        after: right.stringTableCount
      },
      payloadTokenCount: {
        before: left.payloadTokenCount,
        after: right.payloadTokenCount
      }
    },
    stringTable: stringTableSemanticDiff(
      left,
      right
    ),
    payload: lcsTokenDiff(
      left.payload,
      right.payload
    ),
    leftParsed: {
      version: left.version,
      flags: left.flags,
      stringTableCount: left.stringTableCount,
      strings: left.strings,
      payloadTokenCount: left.payloadTokenCount,
      annotatedPayload: left.annotatedPayload
    },
    rightParsed: {
      version: right.version,
      flags: right.flags,
      stringTableCount: right.stringTableCount,
      strings: right.strings,
      payloadTokenCount: right.payloadTokenCount,
      annotatedPayload: right.annotatedPayload
    }
  };
}

function operationKey(entry) {
  return [
    String(entry?.service || ""),
    ...(entry?.rpcMethods || [])
  ].join("::");
}

function compareTraceSemantically(leftTrace, rightTrace) {
  const leftEntries = leftTrace?.entries || [];
  const rightEntries = rightTrace?.entries || [];

  const rightBuckets = new Map();

  for (const entry of rightEntries) {
    const key = operationKey(entry);

    if (!rightBuckets.has(key)) {
      rightBuckets.set(key, []);
    }

    rightBuckets.get(key).push(entry);
  }

  const comparisons = [];

  for (const left of leftEntries) {
    const key = operationKey(left);
    const bucket = rightBuckets.get(key) || [];
    const right = bucket.shift() || null;

    if (!right) {
      comparisons.push({
        operation: key,
        left: {
          service: left.service,
          rpcMethods: left.rpcMethods
        },
        right: null,
        semanticDiff: null
      });
      continue;
    }

    comparisons.push({
      operation: key,
      left: {
        service: left.service,
        rpcMethods: left.rpcMethods,
        resourceId: left.resourceId,
        bodyLength: left.bodyLength,
        tokenCount: left.tokenCount
      },
      right: {
        service: right.service,
        rpcMethods: right.rpcMethods,
        resourceId: right.resourceId,
        bodyLength: right.bodyLength,
        tokenCount: right.tokenCount
      },
      semanticDiff: semanticRequestDiff(
        left.body,
        right.body
      )
    });
  }

  for (const [key, bucket] of rightBuckets.entries()) {
    for (const right of bucket) {
      comparisons.push({
        operation: key,
        left: null,
        right: {
          service: right.service,
          rpcMethods: right.rpcMethods
        },
        semanticDiff: null
      });
    }
  }

  return comparisons;
}

function extractStableChangeCandidates(traceComparisons) {
  const candidates = [];

  for (const comparison of traceComparisons || []) {
    const diff = comparison?.semanticDiff;
    if (!diff?.ok) continue;

    const addedStrings = diff.stringTable?.added || [];
    const removedStrings = diff.stringTable?.removed || [];

    if (
      addedStrings.length ||
      removedStrings.length
    ) {
      candidates.push({
        operation: comparison.operation,
        kind: "string-table-change",
        addedStrings,
        removedStrings
      });
    }

    const edits =
      diff.payload?.edits || [];

    if (edits.length && edits.length <= 20) {
      candidates.push({
        operation: comparison.operation,
        kind: "payload-edits",
        edits
      });
    }
  }

  return candidates;
}


function findOperationEntry(trace, methodName) {
  return (trace?.entries || []).find(
    (entry) =>
      Array.isArray(entry?.rpcMethods) &&
      entry.rpcMethods.includes(methodName)
  ) || null;
}

function payloadFromBody(body) {
  const parsed = parseGwtRequestBody(body);

  if (!parsed.ok) return null;

  return {
    parsed,
    payload: [...parsed.payload]
  };
}

function rebuildGwtBodyWithPayloadToken(
  body,
  payloadIndex,
  replacement
) {
  const raw = String(body || "");
  const tokens = raw.split("|");

  const stringTableCount = Number(tokens[2]);

  if (
    !Number.isInteger(stringTableCount) ||
    stringTableCount < 0
  ) {
    throw new Error("En-tête GWT invalide.");
  }

  const payloadStart =
    3 + stringTableCount;

  const absoluteIndex =
    payloadStart + payloadIndex;

  if (
    absoluteIndex < payloadStart ||
    absoluteIndex >= tokens.length
  ) {
    throw new Error(
      `Index payload hors limites: ${payloadIndex}`
    );
  }

  const before =
    tokens[absoluteIndex];

  tokens[absoluteIndex] =
    String(replacement);

  return {
    body: tokens.join("|"),
    before,
    after: String(replacement),
    payloadIndex,
    absoluteTokenIndex: absoluteIndex
  };
}

function detectWeekParameterFromTwoTraces(
  previousTrace,
  latestTrace
) {
  const previous = findOperationEntry(
    previousTrace,
    "method10getTimetable"
  );

  const latest = findOperationEntry(
    latestTrace,
    "method10getTimetable"
  );

  if (!previous || !latest) {
    return {
      ok: false,
      code: "TIMETABLE_REQUEST_MISSING",
      message:
        "Une trace ne contient pas method10getTimetable."
    };
  }

  const left = payloadFromBody(previous.body);
  const right = payloadFromBody(latest.body);

  if (!left || !right) {
    return {
      ok: false,
      code: "GWT_PARSE_FAILED",
      message:
        "Impossible de décoder une requête getTimetable."
    };
  }

  if (
    left.parsed.stringTableCount !==
    right.parsed.stringTableCount
  ) {
    return {
      ok: false,
      code: "STRING_TABLE_CHANGED",
      message:
        "La structure getTimetable a changé entre les deux dernières traces."
    };
  }

  if (
    left.payload.length !==
    right.payload.length
  ) {
    return {
      ok: false,
      code: "PAYLOAD_LENGTH_CHANGED",
      message:
        "Les deux derniers payloads getTimetable n'ont pas la même longueur."
    };
  }

  const changes = [];

  for (
    let index = 0;
    index < left.payload.length;
    index += 1
  ) {
    const before =
      left.payload[index];
    const after =
      right.payload[index];

    if (before === after) continue;

    changes.push({
      index,
      before,
      after,
      beforeNumber:
        /^-?\d+$/.test(before)
          ? Number(before)
          : null,
      afterNumber:
        /^-?\d+$/.test(after)
          ? Number(after)
          : null
    });
  }

  const incrementByOne =
    changes.filter(
      (change) =>
        Number.isInteger(change.beforeNumber) &&
        Number.isInteger(change.afterNumber) &&
        change.afterNumber ===
          change.beforeNumber + 1
    );

  if (
    changes.length !== 1 ||
    incrementByOne.length !== 1
  ) {
    return {
      ok: false,
      code: "WEEK_PARAMETER_NOT_UNIQUE",
      message:
        "Le paramètre semaine n'est pas encore détectable de façon unique.",
      changes
    };
  }

  const candidate =
    incrementByOne[0];

  return {
    ok: true,
    code: "WEEK_PARAMETER_DETECTED",
    payloadIndex:
      candidate.index,
    previousValue:
      candidate.beforeNumber,
    currentValue:
      candidate.afterNumber,
    nextValue:
      candidate.afterNumber + 1,
    previousWeek:
      previousTrace?.afterWeek || null,
    currentWeek:
      latestTrace?.afterWeek || null,
    previousRequest: previous,
    latestRequest: latest,
    changes
  };
}

function addDaysIso(
  isoDate,
  days
) {
  if (!isoDate) return null;

  const date =
    new Date(`${isoDate}T12:00:00Z`);

  if (
    Number.isNaN(date.getTime())
  ) {
    return null;
  }

  date.setUTCDate(
    date.getUTCDate() + days
  );

  return date
    .toISOString()
    .slice(0, 10);
}

function nextWeekRange(week) {
  if (
    !week?.firstDate ||
    !week?.lastDate
  ) {
    return null;
  }

  return {
    firstDate:
      addDaysIso(
        week.firstDate,
        7
      ),
    lastDate:
      addDaysIso(
        week.lastDate,
        7
      )
  };
}

function courseLikeStrings(
  responseText
) {
  const analysis =
    analyzeGwtResponse(
      responseText
    );

  const strings =
    Array.isArray(
      analysis.sampleStrings
    )
      ? analysis.sampleStrings
      : [];

  return strings.filter(
    (value) => {
      if (
        !value ||
        value.includes("/") ||
        /^java\./.test(value) ||
        /^com\./.test(value)
      ) {
        return false;
      }

      return true;
    }
  );
}

async function testPredictedNextWeek() {
  const data = await storeGet([
    "weekTraces",
    "savedProfile"
  ]);

  const traces =
    Array.isArray(data.weekTraces)
      ? data.weekTraces
      : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code: "NEED_TWO_WEEK_TRACES",
      message:
        "Il faut au moins deux traces successives avant de prédire la semaine suivante."
    };
  }

  const previous =
    traces[traces.length - 2];

  const latest =
    traces[traces.length - 1];

  const detection =
    detectWeekParameterFromTwoTraces(
      previous,
      latest
    );

  if (!detection.ok) {
    return detection;
  }

  const mutated =
    rebuildGwtBodyWithPayloadToken(
      detection.latestRequest.body,
      detection.payloadIndex,
      detection.nextValue
    );

  const profile =
    data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code: "NO_PROFILE_HEADERS",
      message:
        "Le profil RPC doit être enregistré pour rejouer la requête."
    };
  }

  const template = {
    method:
      detection.latestRequest.method ||
      profile.rpcTemplate.method ||
      "POST",
    url:
      detection.latestRequest.url ||
      profile.rpcTemplate.url,
    headers:
      profile.rpcTemplate.headers || {},
    body:
      mutated.body
  };

  const predictedWeek =
    nextWeekRange(
      latest.afterWeek
    );

  let testTab = null;

  try {
    testTab =
      await openFreshAde();

    const replay =
      await replayInPage(
        testTab.id,
        template
      );

    const responseText =
      String(
        replay?.responseText || ""
      );

    const gwtOk =
      responseText
        .trimStart()
        .startsWith("//OK");

    const responseAnalysis =
      analyzeGwtResponse(
        responseText
      );

    const result = {
      ok:
        Boolean(replay?.ok) &&
        gwtOk,
      code:
        Boolean(replay?.ok) &&
        gwtOk
          ? "NEXT_WEEK_PREDICTION_OK"
          : "NEXT_WEEK_PREDICTION_FAILED",
      message:
        Boolean(replay?.ok) &&
        gwtOk
          ? "La semaine suivante a été demandée sans clic en modifiant uniquement le paramètre détecté."
          : "Le serveur ADE n'a pas accepté la requête de semaine suivante.",
      detectedParameter: {
        payloadIndex:
          detection.payloadIndex,
        previousValue:
          detection.previousValue,
        currentValue:
          detection.currentValue,
        testedValue:
          detection.nextValue
      },
      sourceWeek:
        latest.afterWeek || null,
      predictedWeek,
      httpStatus:
        replay?.httpStatus ?? null,
      gwtOk,
      responseLength:
        responseText.length,
      responseAnalysis,
      courseLikeStrings:
        courseLikeStrings(
          responseText
        ).slice(0, 80)
    };

    await storeSet({
      predictedNextWeek: {
        generatedAt: nowIso(),
        ...result,
        requestTemplate: template,
        responseText
      }
    });

    return result;
  } finally {
    if (testTab?.id) {
      try {
        await chrome.tabs.remove(
          testTab.id
        );
      } catch {}
    }
  }
}


function likelyCourseTitles(responseText) {
  const analysis =
    analyzeGwtResponse(responseText);

  const strings =
    Array.isArray(analysis.sampleStrings)
      ? analysis.sampleStrings
      : [];

  return strings.filter((value) =>
    /\((?:CM|TD|TP|TDP|CTD)\d*\)/i.test(
      String(value || "")
    )
  );
}

function likelyGroupLabels(responseText) {
  const analysis =
    analyzeGwtResponse(responseText);

  const strings =
    Array.isArray(analysis.sampleStrings)
      ? analysis.sampleStrings
      : [];

  return strings.filter((value) =>
    /^(?:CM|TD|TP|TDP|CTD)\b/i.test(
      String(value || "")
    )
  );
}

async function generateNextWeeks() {
  const data = await storeGet([
    "weekTraces",
    "savedProfile"
  ]);

  const traces =
    Array.isArray(data.weekTraces)
      ? data.weekTraces
      : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code: "NEED_TWO_WEEK_TRACES",
      message:
        "Il faut conserver au moins deux traces de semaine pour générer automatiquement les semaines suivantes."
    };
  }

  const previous =
    traces[traces.length - 2];

  const latest =
    traces[traces.length - 1];

  const detection =
    detectWeekParameterFromTwoTraces(
      previous,
      latest
    );

  if (!detection.ok) {
    return detection;
  }

  const profile =
    data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code: "NO_PROFILE_HEADERS",
      message:
        "Le profil RPC doit être enregistré avant la génération."
    };
  }

  const numberOfWeeks = 8;
  const weeks = [];
  let testTab = null;

  await storeSet({
    weekBatchStatus: {
      state: "running",
      startedAt: nowIso(),
      requestedWeeks: numberOfWeeks,
      completedWeeks: 0
    }
  });

  try {
    testTab = await openFreshAde();

    for (
      let offset = 1;
      offset <= numberOfWeeks;
      offset += 1
    ) {
      const parameterValue =
        detection.currentValue + offset;

      const mutated =
        rebuildGwtBodyWithPayloadToken(
          detection.latestRequest.body,
          detection.payloadIndex,
          parameterValue
        );

      const template = {
        method:
          detection.latestRequest.method ||
          profile.rpcTemplate.method ||
          "POST",
        url:
          detection.latestRequest.url ||
          profile.rpcTemplate.url,
        headers:
          profile.rpcTemplate.headers || {},
        body:
          mutated.body
      };

      const replay =
        await replayInPage(
          testTab.id,
          template
        );

      const responseText =
        String(
          replay?.responseText || ""
        );

      const gwtOk =
        responseText
          .trimStart()
          .startsWith("//OK");

      const week = {
        offset,
        parameterValue,
        week: {
          firstDate:
            addDaysIso(
              latest.afterWeek?.firstDate,
              7 * offset
            ),
          lastDate:
            addDaysIso(
              latest.afterWeek?.lastDate,
              7 * offset
            )
        },
        ok:
          Boolean(replay?.ok) &&
          gwtOk,
        httpStatus:
          replay?.httpStatus ?? null,
        gwtOk,
        responseLength:
          responseText.length,
        titles:
          likelyCourseTitles(
            responseText
          ),
        groups:
          likelyGroupLabels(
            responseText
          ),
        timeLikeStrings:
          analyzeGwtResponse(
            responseText
          ).timeLikeStrings || [],
        rawResponse:
          responseText,
        requestBody:
          mutated.body
      };

      weeks.push(week);

      await storeSet({
        weekBatchStatus: {
          state: "running",
          startedAt:
            (
              await storeGet([
                "weekBatchStatus"
              ])
            ).weekBatchStatus?.startedAt ||
            nowIso(),
          requestedWeeks:
            numberOfWeeks,
          completedWeeks:
            weeks.length,
          currentWeek:
            week.week,
          currentParameter:
            parameterValue
        }
      });

      // Reste raisonnable avec le serveur ADE.
      await sleep(250);
    }

    const successCount =
      weeks.filter(
        (week) => week.ok
      ).length;

    const result = {
      ok:
        successCount ===
        numberOfWeeks,
      code:
        successCount ===
        numberOfWeeks
          ? "WEEK_BATCH_OK"
          : "WEEK_BATCH_PARTIAL",
      message:
        successCount ===
        numberOfWeeks
          ? `${numberOfWeeks} semaines ont été générées automatiquement sans clic.`
          : `${successCount}/${numberOfWeeks} semaines ont répondu correctement.`,
      generatedAt: nowIso(),
      baseWeek:
        latest.afterWeek || null,
      parameter: {
        payloadIndex:
          detection.payloadIndex,
        baseValue:
          detection.currentValue
      },
      requestedWeeks:
        numberOfWeeks,
      successCount,
      weeks: weeks.map(
        (week) => ({
          offset:
            week.offset,
          parameterValue:
            week.parameterValue,
          week:
            week.week,
          ok:
            week.ok,
          httpStatus:
            week.httpStatus,
          gwtOk:
            week.gwtOk,
          responseLength:
            week.responseLength,
          titleCount:
            week.titles.length,
          titles:
            week.titles,
          timeLikeStrings:
            week.timeLikeStrings
        })
      )
    };

    await storeSet({
      generatedWeekBatch: {
        ...result,
        weeks
      },
      weekBatchStatus: {
        state: "finished",
        finishedAt: nowIso(),
        ok: result.ok,
        code: result.code,
        requestedWeeks:
          numberOfWeeks,
        completedWeeks:
          weeks.length
      }
    });

    return result;
  } catch (error) {
    const result = {
      ok: false,
      code: "WEEK_BATCH_EXCEPTION",
      message: String(error),
      generatedAt: nowIso(),
      completedWeeks:
        weeks.length
    };

    await storeSet({
      weekBatchStatus: {
        state: "finished",
        finishedAt: nowIso(),
        ok: false,
        code:
          result.code,
        completedWeeks:
          weeks.length
      }
    });

    return result;
  } finally {
    if (testTab?.id) {
      try {
        await chrome.tabs.remove(
          testTab.id
        );
      } catch {}
    }
  }
}

async function generatedWeeksSummary() {
  const data = await storeGet([
    "generatedWeekBatch",
    "weekBatchStatus"
  ]);

  const batch =
    data.generatedWeekBatch;

  if (!batch) {
    return {
      ok: false,
      code: "NO_WEEK_BATCH",
      message:
        "Aucun lot de semaines n'a encore été généré."
    };
  }

  return {
    ok: true,
    status:
      data.weekBatchStatus || null,
    generatedAt:
      batch.generatedAt,
    baseWeek:
      batch.baseWeek,
    parameter:
      batch.parameter,
    requestedWeeks:
      batch.requestedWeeks,
    successCount:
      batch.successCount,
    weeks:
      (batch.weeks || []).map(
        (week) => ({
          offset:
            week.offset,
          parameterValue:
            week.parameterValue,
          week:
            week.week,
          ok:
            week.ok,
          httpStatus:
            week.httpStatus,
          gwtOk:
            week.gwtOk,
          responseLength:
            week.responseLength,
          titleCount:
            Array.isArray(
              week.titles
            )
              ? week.titles.length
              : 0,
          titles:
            week.titles || [],
          groups:
            week.groups || [],
          timeLikeStrings:
            week.timeLikeStrings || []
        })
      )
  };
}


async function sha256Text(text) {
  const bytes =
    new TextEncoder().encode(
      String(text || "")
    );

  const digest =
    await crypto.subtle.digest(
      "SHA-256",
      bytes
    );

  return [...new Uint8Array(digest)]
    .map((value) =>
      value
        .toString(16)
        .padStart(2, "0")
    )
    .join("");
}

function exactPayloadChanges(
  leftBody,
  rightBody
) {
  const left =
    parseGwtRequestBody(
      leftBody
    );

  const right =
    parseGwtRequestBody(
      rightBody
    );

  if (!left.ok || !right.ok) {
    return {
      ok: false,
      leftOk:
        left.ok,
      rightOk:
        right.ok
    };
  }

  const max =
    Math.max(
      left.payload.length,
      right.payload.length
    );

  const changes = [];

  for (
    let index = 0;
    index < max;
    index += 1
  ) {
    const before =
      left.payload[index] ?? null;

    const after =
      right.payload[index] ?? null;

    if (before === after) {
      continue;
    }

    changes.push({
      index,
      before,
      after
    });
  }

  return {
    ok: true,
    leftPayloadLength:
      left.payload.length,
    rightPayloadLength:
      right.payload.length,
    changes
  };
}


function pairTraceEntriesByOperation(
  previousTrace,
  latestTrace
) {
  const previousBuckets =
    new Map();

  for (
    const entry
    of previousTrace?.entries || []
  ) {
    const key =
      operationKey(entry);

    if (
      !previousBuckets.has(key)
    ) {
      previousBuckets.set(
        key,
        []
      );
    }

    previousBuckets
      .get(key)
      .push(entry);
  }

  const paired = [];

  for (
    const latest
    of latestTrace?.entries || []
  ) {
    const key =
      operationKey(latest);

    const bucket =
      previousBuckets.get(key) || [];

    const previous =
      bucket.shift() || null;

    paired.push({
      key,
      previous,
      latest
    });
  }

  return paired;
}

function isVolatileClientTokenChange(change) {
  const before =
    String(
      change?.before ?? ""
    );

  const after =
    String(
      change?.after ?? ""
    );

  return (
    /^aCS[A-Za-z0-9]+$/.test(
      before
    ) &&
    /^aCS[A-Za-z0-9]+$/.test(
      after
    )
  );
}

function detectSingleIncrement(
  previousBody,
  latestBody
) {
  const left =
    parseGwtRequestBody(
      previousBody
    );

  const right =
    parseGwtRequestBody(
      latestBody
    );

  if (
    !left.ok ||
    !right.ok
  ) {
    return {
      ok: false,
      code:
        "PARSE_FAILED"
    };
  }

  if (
    left.payload.length !==
    right.payload.length
  ) {
    return {
      ok: false,
      code:
        "PAYLOAD_LENGTH_CHANGED",
      beforeLength:
        left.payload.length,
      afterLength:
        right.payload.length
    };
  }

  const changes = [];

  for (
    let index = 0;
    index < left.payload.length;
    index += 1
  ) {
    const before =
      left.payload[index];

    const after =
      right.payload[index];

    if (
      before === after
    ) {
      continue;
    }

    changes.push({
      index,
      before,
      after,
      beforeNumber:
        /^-?\d+$/.test(before)
          ? Number(before)
          : null,
      afterNumber:
        /^-?\d+$/.test(after)
          ? Number(after)
          : null
    });
  }

  if (!changes.length) {
    return {
      ok: true,
      unchanged: true,
      changes: [],
      ignoredVolatileChanges: []
    };
  }

  const increments =
    changes.filter(
      (change) =>
        Number.isInteger(
          change.beforeNumber
        ) &&
        Number.isInteger(
          change.afterNumber
        ) &&
        change.afterNumber ===
          change.beforeNumber + 1
    );

  const volatileChanges =
    changes.filter(
      (change) =>
        isVolatileClientTokenChange(
          change
        )
    );

  const unsupportedChanges =
    changes.filter(
      (change) =>
        !increments.includes(change) &&
        !volatileChanges.includes(change)
    );

  // Cas des appels sans numéro de semaine :
  // seul le token aCS... change d'une navigation réelle à l'autre.
  if (
    increments.length === 0 &&
    unsupportedChanges.length === 0
  ) {
    return {
      ok: true,
      unchanged: true,
      changes,
      ignoredVolatileChanges:
        volatileChanges
    };
  }

  // Cas normal des RPC liés à la semaine :
  // un seul entier augmente de 1, tandis que le token aCS...
  // peut aussi changer mais n'a pas d'effet sur la réponse planning.
  if (
    increments.length === 1 &&
    unsupportedChanges.length === 0
  ) {
    return {
      ok: true,
      payloadIndex:
        increments[0].index,
      previousValue:
        increments[0].beforeNumber,
      currentValue:
        increments[0].afterNumber,
      nextValue:
        increments[0].afterNumber + 1,
      changes,
      ignoredVolatileChanges:
        volatileChanges
    };
  }

  return {
    ok: false,
    code:
      "WEEK_INCREMENT_NOT_UNIQUE",
    changes,
    increments,
    volatileChanges,
    unsupportedChanges
  };
}
function buildNextWeekSequence(
  previousTrace,
  latestTrace
) {
  const pairs =
    pairTraceEntriesByOperation(
      previousTrace,
      latestTrace
    );

  const sequence = [];
  const diagnostics = [];

  for (const pair of pairs) {
    const latest =
      pair.latest;

    if (!latest?.body) {
      continue;
    }

    let body =
      latest.body;

    let mutation =
      null;

    if (
      pair.previous?.body
    ) {
      const detection =
        detectSingleIncrement(
          pair.previous.body,
          latest.body
        );

      diagnostics.push({
        operation:
          pair.key,
        detection
      });

      if (
        detection.ok &&
        !detection.unchanged
      ) {
        mutation =
          rebuildGwtBodyWithPayloadToken(
            latest.body,
            detection.payloadIndex,
            detection.nextValue
          );

        body =
          mutation.body;
      }
    }

    sequence.push({
      operation:
        pair.key,
      method:
        latest.method || "POST",
      url:
        latest.url,
      body,
      sourceBody:
        latest.body,
      mutation: mutation
        ? {
            payloadIndex:
              mutation.payloadIndex,
            before:
              mutation.before,
            after:
              mutation.after
          }
        : null
    });
  }

  return {
    sequence,
    diagnostics
  };
}

async function replaySequenceInFreshPage(
  sequence,
  headers
) {
  let tab = null;

  try {
    tab =
      await openFreshAde();

    const steps = [];

    for (
      let index = 0;
      index < sequence.length;
      index += 1
    ) {
      const item =
        sequence[index];

      const replay =
        await replayInPage(
          tab.id,
          {
            method:
              item.method ||
              "POST",
            url:
              item.url,
            headers:
              headers || {},
            body:
              item.body
          }
        );

      const responseText =
        String(
          replay?.responseText ||
          ""
        );

      const step = {
        index,
        operation:
          item.operation,
        mutation:
          item.mutation,
        httpStatus:
          replay?.httpStatus ??
          null,
        gwtOk:
          responseText
            .trimStart()
            .startsWith("//OK"),
        responseLength:
          responseText.length,
        responseHash:
          await sha256Text(
            responseText
          ),
        requestHash:
          await sha256Text(
            item.body
          ),
        responseText
      };

      steps.push(step);

      await sleep(150);
    }

    return {
      ok:
        steps.every(
          (step) =>
            step.httpStatus >= 200 &&
            step.httpStatus < 300 &&
            step.gwtOk
        ),
      steps
    };
  } finally {
    if (tab?.id) {
      try {
        await chrome.tabs.remove(
          tab.id
        );
      } catch {}
    }
  }
}

async function predictNextWeekWithFullSequence() {
  const data =
    await storeGet([
      "weekTraces",
      "savedProfile"
    ]);

  const traces =
    Array.isArray(
      data.weekTraces
    )
      ? data.weekTraces
      : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code:
        "NEED_TWO_REAL_TRACES",
      message:
        "Il faut au moins deux vraies transitions enregistrées."
    };
  }

  const previous =
    traces[traces.length - 2];

  const latest =
    traces[traces.length - 1];

  const built =
    buildNextWeekSequence(
      previous,
      latest
    );

  if (
    !built.sequence.length
  ) {
    return {
      ok: false,
      code:
        "EMPTY_SEQUENCE",
      message:
        "Aucune séquence RPC à rejouer."
    };
  }

  const profile =
    data.savedProfile;

  if (
    !profile?.rpcTemplate
  ) {
    return {
      ok: false,
      code:
        "NO_PROFILE",
      message:
        "Le profil RPC n'est plus disponible."
    };
  }

  const replay =
    await replaySequenceInFreshPage(
      built.sequence,
      profile.rpcTemplate.headers || {}
    );

  const timetableStep =
    replay.steps.find(
      (step) =>
        step.operation.includes(
          "method10getTimetable"
        )
    ) || null;

  if (!timetableStep) {
    return {
      ok: false,
      code:
        "NO_TIMETABLE_STEP",
      message:
        "La séquence ne contient pas getTimetable.",
      diagnostics:
        built.diagnostics
    };
  }

  const targetWeek =
    nextWeekRange(
      latest.afterWeek
    );

  const targetSequence =
    built.sequence.map(
      (item) => ({
        operation:
          item.operation,
        method:
          item.method,
        url:
          item.url,
        body:
          item.body,
        mutation:
          item.mutation
      })
    );

  const result = {
    ok:
      Boolean(replay.ok),
    code:
      replay.ok
        ? "FULL_SEQUENCE_PREDICTION_OK"
        : "FULL_SEQUENCE_PREDICTION_PARTIAL",
    message:
      replay.ok
        ? "La séquence complète du changement de semaine a été rejouée sur une page ADE fraîche."
        : "Au moins une étape de la séquence complète n'a pas été validée.",
    sourceTransition: {
      beforeWeek:
        latest.beforeWeek ||
        null,
      afterWeek:
        latest.afterWeek ||
        null
    },
    targetWeek,
    mutationDiagnostics:
      built.diagnostics,
    steps:
      replay.steps.map(
        (step) => ({
          index:
            step.index,
          operation:
            step.operation,
          mutation:
            step.mutation,
          httpStatus:
            step.httpStatus,
          gwtOk:
            step.gwtOk,
          responseLength:
            step.responseLength,
          requestHash:
            step.requestHash,
          responseHash:
            step.responseHash
        })
      ),
    timetable: {
      requestHash:
        timetableStep.requestHash,
      responseHash:
        timetableStep.responseHash,
      responseLength:
        timetableStep.responseLength,
      titles:
        likelyCourseTitles(
          timetableStep.responseText
        ),
      times:
        analyzeGwtResponse(
          timetableStep.responseText
        ).timeLikeStrings || []
    }
  };

  await storeSet({
    fullSequencePrediction: {
      generatedAt:
        nowIso(),
      ...result,
      targetSequence,
      timetableResponse:
        timetableStep.responseText
    }
  });

  return result;
}

function pairPredictedActualSequence(
  predictedSequence,
  actualTrace
) {
  const predictedBuckets =
    new Map();

  for (
    const entry
    of predictedSequence || []
  ) {
    const key =
      entry.operation;

    if (
      !predictedBuckets.has(key)
    ) {
      predictedBuckets.set(
        key,
        []
      );
    }

    predictedBuckets
      .get(key)
      .push(entry);
  }

  const pairs = [];

  for (
    const actual
    of actualTrace?.entries || []
  ) {
    const key =
      operationKey(actual);

    const bucket =
      predictedBuckets.get(key) || [];

    const predicted =
      bucket.shift() || null;

    pairs.push({
      operation:
        key,
      predicted,
      actual
    });
  }

  return pairs;
}


function compareBodiesIgnoringVolatileTokens(
  predictedBody,
  actualBody
) {
  const predicted =
    parseGwtRequestBody(
      predictedBody
    );

  const actual =
    parseGwtRequestBody(
      actualBody
    );

  if (
    !predicted.ok ||
    !actual.ok
  ) {
    return {
      ok: false,
      equivalent: false,
      code:
        "PARSE_FAILED"
    };
  }

  if (
    predicted.version !==
      actual.version ||
    predicted.flags !==
      actual.flags ||
    predicted.stringTableCount !==
      actual.stringTableCount ||
    predicted.payload.length !==
      actual.payload.length
  ) {
    return {
      ok: true,
      equivalent: false,
      code:
        "STRUCTURE_DIFFERS",
      predicted: {
        version:
          predicted.version,
        flags:
          predicted.flags,
        stringTableCount:
          predicted.stringTableCount,
        payloadLength:
          predicted.payload.length
      },
      actual: {
        version:
          actual.version,
        flags:
          actual.flags,
        stringTableCount:
          actual.stringTableCount,
        payloadLength:
          actual.payload.length
      }
    };
  }

  const stringTableEqual =
    JSON.stringify(
      predicted.strings.map(
        (item) => item.value
      )
    ) ===
    JSON.stringify(
      actual.strings.map(
        (item) => item.value
      )
    );

  if (!stringTableEqual) {
    return {
      ok: true,
      equivalent: false,
      code:
        "STRING_TABLE_DIFFERS"
    };
  }

  const changes = [];
  const ignoredVolatileChanges = [];
  const meaningfulChanges = [];

  for (
    let index = 0;
    index < predicted.payload.length;
    index += 1
  ) {
    const before =
      predicted.payload[index];

    const after =
      actual.payload[index];

    if (before === after) {
      continue;
    }

    const change = {
      index,
      before,
      after
    };

    changes.push(change);

    if (
      isVolatileClientTokenChange(
        change
      )
    ) {
      ignoredVolatileChanges.push(
        change
      );
    } else {
      meaningfulChanges.push(
        change
      );
    }
  }

  return {
    ok: true,
    equivalent:
      meaningfulChanges.length === 0,
    code:
      meaningfulChanges.length === 0
        ? "EQUIVALENT_IGNORING_VOLATILE_TOKEN"
        : "MEANINGFUL_PAYLOAD_DIFFERS",
    changes,
    ignoredVolatileChanges,
    meaningfulChanges
  };
}

async function validateFullSequenceAgainstRealTrace() {
  const data =
    await storeGet([
      "fullSequencePrediction",
      "weekTraces",
      "savedProfile"
    ]);

  const prediction =
    data.fullSequencePrediction;

  if (
    !prediction?.targetSequence?.length
  ) {
    return {
      ok: false,
      code:
        "NO_FULL_SEQUENCE_PREDICTION",
      message:
        "Lance d'abord le bouton 14."
    };
  }

  const traces =
    Array.isArray(
      data.weekTraces
    )
      ? data.weekTraces
      : [];

  if (!traces.length) {
    return {
      ok: false,
      code:
        "NO_REAL_TRACE",
      message:
        "Aucune vraie transition ADE n'a été enregistrée."
    };
  }

  const actualTrace =
    traces[traces.length - 1];

  const pairs =
    pairPredictedActualSequence(
      prediction.targetSequence,
      actualTrace
    );

  const requestComparisons = [];

  for (const pair of pairs) {
    const predictedBody =
      pair.predicted?.body ||
      "";

    const actualBody =
      pair.actual?.body ||
      "";

    const bodiesIdentical =
      Boolean(pair.predicted) &&
      predictedBody === actualBody;

    const semanticEquivalence =
      (
        pair.predicted &&
        pair.actual
      )
        ? compareBodiesIgnoringVolatileTokens(
            predictedBody,
            actualBody
          )
        : null;

    requestComparisons.push({
      operation:
        pair.operation,
      predictedPresent:
        Boolean(pair.predicted),
      actualPresent:
        Boolean(pair.actual),
      bodiesIdentical,
      equivalentIgnoringVolatileToken:
        Boolean(
          semanticEquivalence?.equivalent
        ),
      predictedHash:
        pair.predicted
          ? await sha256Text(
              predictedBody
            )
          : null,
      actualHash:
        pair.actual
          ? await sha256Text(
              actualBody
            )
          : null,
      semanticEquivalence,
      payloadDiff:
        (
          pair.predicted &&
          pair.actual
        )
          ? exactPayloadChanges(
              predictedBody,
              actualBody
            )
          : null
    });
  }

  const actualTimetable =
    findOperationEntry(
      actualTrace,
      "method10getTimetable"
    );

  const profile =
    data.savedProfile;

  let actualResponse = "";
  let actualReplayStatus = null;

  if (
    actualTimetable?.body &&
    profile?.rpcTemplate
  ) {
    let tab = null;

    try {
      tab =
        await openFreshAde();

      const replay =
        await replayInPage(
          tab.id,
          {
            method:
              actualTimetable.method ||
              "POST",
            url:
              actualTimetable.url ||
              profile.rpcTemplate.url,
            headers:
              profile.rpcTemplate.headers || {},
            body:
              actualTimetable.body
          }
        );

      actualResponse =
        String(
          replay?.responseText ||
          ""
        );

      actualReplayStatus = {
        httpStatus:
          replay?.httpStatus ??
          null,
        gwtOk:
          actualResponse
            .trimStart()
            .startsWith("//OK")
      };
    } finally {
      if (tab?.id) {
        try {
          await chrome.tabs.remove(
            tab.id
          );
        } catch {}
      }
    }
  }

  const predictedResponse =
    String(
      prediction.timetableResponse ||
      ""
    );

  const predictedResponseHash =
    await sha256Text(
      predictedResponse
    );

  const actualResponseHash =
    await sha256Text(
      actualResponse
    );

  const allBodiesIdentical =
    requestComparisons.length > 0 &&
    requestComparisons.every(
      (item) =>
        item.predictedPresent &&
        item.actualPresent &&
        item.bodiesIdentical
    );

  const allBodiesEquivalent =
    requestComparisons.length > 0 &&
    requestComparisons.every(
      (item) =>
        item.predictedPresent &&
        item.actualPresent &&
        (
          item.bodiesIdentical ||
          item.equivalentIgnoringVolatileToken
        )
    );

  const timetableResponseIdentical =
    Boolean(actualResponse) &&
    predictedResponse ===
      actualResponse;

  const targetWeek =
    prediction.targetWeek ||
    null;

  const realWeek =
    actualTrace.afterWeek ||
    null;

  const sameTargetWeek =
    Boolean(
      targetWeek?.firstDate &&
      realWeek?.firstDate &&
      targetWeek.firstDate ===
        realWeek.firstDate &&
      targetWeek.lastDate ===
        realWeek.lastDate
    );

  const ok =
    sameTargetWeek &&
    allBodiesEquivalent &&
    timetableResponseIdentical;

  const result = {
    ok,
    code: ok
      ? "FULL_SEQUENCE_CONFIRMED"
      : "FULL_SEQUENCE_MISMATCH",
    message: ok
      ? "Confirmation stricte réussie : mêmes paramètres utiles et même réponse getTimetable. Les seules différences de requêtes sont des tokens GWT volatils aCS..., sans effet sur le planning."
      : "La comparaison révèle encore une différence utile. Les détails indiquent précisément laquelle.",
    predictedTargetWeek:
      targetWeek,
    realTrace: {
      beforeWeek:
        actualTrace.beforeWeek ||
        null,
      afterWeek:
        actualTrace.afterWeek ||
        null
    },
    sameTargetWeek,
    allBodiesIdentical,
    allBodiesEquivalentIgnoringVolatileToken:
      allBodiesEquivalent,
    timetableResponseIdentical,
    predictedTimetableResponseHash:
      predictedResponseHash,
    actualTimetableResponseHash:
      actualResponseHash,
    actualReplayStatus,
    requestComparisons
  };

  await storeSet({
    lastFullSequenceValidation: {
      testedAt:
        nowIso(),
      ...result
    }
  });

  return result;
}

function medianNumber(values) {
  const numbers =
    values
      .map(Number)
      .filter(
        (value) =>
          Number.isFinite(value)
      )
      .sort(
        (a, b) => a - b
      );

  if (!numbers.length) {
    return null;
  }

  const middle =
    Math.floor(
      numbers.length / 2
    );

  if (
    numbers.length % 2
  ) {
    return numbers[middle];
  }

  return (
    numbers[middle - 1] +
    numbers[middle]
  ) / 2;
}

function parseAdeTimeRange(value) {
  const match =
    String(value || "")
      .trim()
      .match(
        /^(\d{1,2})h(\d{2})\s*-\s*(\d{1,2})h(\d{2})$/
      );

  if (!match) {
    return null;
  }

  return {
    start:
      `${match[1].padStart(2, "0")}:${match[2]}`,
    end:
      `${match[3].padStart(2, "0")}:${match[4]}`
  };
}

function classifyCourseType(
  title,
  group
) {
  const text =
    `${String(title || "")} ${String(group || "")}`;

  const match =
    text.match(
      /\b(CM|TD|TP|TDP|CTD|COURS|EXAM|EXAMEN)\s*\d*\b/i
    );

  return match
    ? match[1].toUpperCase()
    : null;
}

function cleanAdeTitle(
  title
) {
  return String(title || "")
    .replace(
      /\s*\((CM|TD|TP|TDP|CTD|COURS|EXAM|EXAMEN)\s*\d*\)\s*$/i,
      ""
    )
    .trim();
}

function looksLikeRoom(value) {
  const text =
    String(value || "")
      .trim();

  if (!text) {
    return false;
  }

  return (
    /\d/.test(text) ||
    /\b(salle|amphi|amphith[eé][aâ]tre|room|bureau|lab|labo)\b/i.test(
      text
    )
  );
}

function looksLikeBuilding(value) {
  return /^\s*b[aâ]timent\b/i.test(
    String(value || "")
  );
}

function looksLikeCourseTitle(value) {
  return /\((CM|TD|TP|TDP|CTD|COURS|EXAM|EXAMEN)\s*\d*\)\s*$/i.test(
    String(value || "")
  );
}

function looksLikeGroup(value) {
  return /^\s*(CM|TD|TP|TDP|CTD|COURS|EXAM|EXAMEN)\b/i.test(
    String(value || "")
  );
}

function decodeSquareEventsResponse(
  responseText,
  week
) {
  const text =
    String(responseText || "")
      .trimStart();

  if (
    !text.startsWith("//OK")
  ) {
    return {
      ok: false,
      code:
        "GWT_RESPONSE_NOT_OK",
      message:
        "La réponse ne commence pas par //OK."
    };
  }

  let stream;

  try {
    stream = globalThis.PlanilimGwtResponse?.parseGwtJsonPayload
      ? globalThis.PlanilimGwtResponse.parseGwtJsonPayload(text.slice(4))
      : JSON.parse(text.slice(4));
  } catch (error) {
    const message = String(error);
    const position = Number(message.match(/position\s+(\d+)/i)?.[1] || -1);
    const body = text.slice(4);
    return {
      ok: false,
      code:
        "GWT_RESPONSE_JSON_PARSE_FAILED",
      message,
      parsePosition: position >= 0 ? position : null,
      parseContext: position >= 0
        ? body.slice(Math.max(0, position - 60), Math.min(body.length, position + 60))
        : body.slice(0, 120),
      responseLength: text.length
    };
  }

  if (
    !Array.isArray(stream) ||
    stream.length < 4
  ) {
    return {
      ok: false,
      code:
        "GWT_RESPONSE_SHAPE_INVALID",
      message:
        "Le flux GWT n'a pas la forme attendue."
    };
  }

  const version =
    stream[
      stream.length - 1
    ];

  const flags =
    stream[
      stream.length - 2
    ];

  const stringTable =
    stream[
      stream.length - 3
    ];

  if (
    !Array.isArray(
      stringTable
    )
  ) {
    return {
      ok: false,
      code:
        "GWT_STRING_TABLE_MISSING",
      message:
        "Table de chaînes GWT introuvable."
    };
  }

  const payload =
    stream.slice(
      0,
      -3
    );

  const arrayListTypeIndex =
    stringTable.findIndex(
      (value) =>
        String(value).startsWith(
          "java.util.ArrayList/"
        )
    ) + 1;

  const eventTypeIndex =
    stringTable.findIndex(
      (value) =>
        String(value).includes(
          ".SquareEvent/"
        )
    ) + 1;

  const stringTypeIndex =
    stringTable.findIndex(
      (value) =>
        String(value).startsWith(
          "java.lang.String/"
        )
    ) + 1;

  let expectedEventCount =
    null;

  if (
    payload.length >= 2 &&
    payload[
      payload.length - 1
    ] ===
      arrayListTypeIndex
  ) {
    const possibleCount =
      Number(
        payload[
          payload.length - 2
        ]
      );

    if (
      Number.isInteger(
        possibleCount
      ) &&
      possibleCount >= 0
    ) {
      expectedEventCount =
        possibleCount;
    }
  }

  // Une semaine vide peut ne contenir aucun type SquareEvent
  // dans la table de chaînes. C'est un résultat valide.
  if (
    expectedEventCount === 0
  ) {
    return {
      ok: true,
      code:
        "SQUARE_EVENTS_DECODED",
      gwt: {
        version,
        flags,
        stringTableCount:
          stringTable.length,
        eventTypeIndex:
          eventTypeIndex > 0
            ? eventTypeIndex
            : null,
        stringTypeIndex:
          stringTypeIndex > 0
            ? stringTypeIndex
            : null,
        expectedEventCount: 0,
        detectedEventCount: 0,
        markerCount: 0
      },
      week:
        week || null,
      geometry: {
        medianColumnWidth:
          null
      },
      events: []
    };
  }

  if (
    eventTypeIndex <= 0 ||
    stringTypeIndex <= 0
  ) {
    return {
      ok: false,
      code:
        "SQUARE_EVENT_TYPES_MISSING",
      message:
        "SquareEvent ou java.lang.String n'a pas été trouvé dans la table GWT.",
      eventTypeIndex,
      stringTypeIndex,
      expectedEventCount
    };
  }

  // Un SquareEvent se termine dans le flux sérialisé par :
  // ..., <int>, 3, 1, 1, <SquareEvent type index>
  // Cette signature évite de confondre un champ numérique "2"
  // avec un marqueur d'objet.
  const markers = [];

  for (
    let index = 3;
    index < payload.length - 1;
    index += 1
  ) {
    if (
      payload[index] !==
        eventTypeIndex
    ) {
      continue;
    }

    if (
      payload[index - 1] === 1 &&
      payload[index - 2] === 1 &&
      payload[index - 3] === 3
    ) {
      markers.push(index);
    }
  }

  // Fallback si une variante ADE ne conserve pas exactement
  // la signature précédente.
  if (
    expectedEventCount !== null &&
    markers.length !==
      expectedEventCount
  ) {
    const allTypeMarkers = [];

    for (
      let index = 0;
      index < payload.length - 1;
      index += 1
    ) {
      if (
        payload[index] ===
        eventTypeIndex
      ) {
        allTypeMarkers.push(
          index
        );
      }
    }

    if (
      allTypeMarkers.length ===
      expectedEventCount
    ) {
      markers.splice(
        0,
        markers.length,
        ...allTypeMarkers
      );
    }
  }

  if (!markers.length) {
    return {
      ok: false,
      code:
        "NO_SQUARE_EVENT_MARKERS",
      message:
        "Aucun bloc SquareEvent n'a pu être repéré.",
      expectedEventCount
    };
  }

  const rawEvents = [];

  for (
    let eventIndex = 0;
    eventIndex < markers.length;
    eventIndex += 1
  ) {
    const end =
      markers[eventIndex];

    const start =
      eventIndex === 0
        ? 0
        : markers[
            eventIndex - 1
          ] + 1;

    const segment =
      payload.slice(
        start,
        end + 1
      );

    if (
      segment.length < 8
    ) {
      continue;
    }

    const top =
      Number(segment[0]);

    const left =
      Number(segment[1]);

    const width =
      Number(segment[2]);

    const height =
      Number(segment[3]);

    const reversed =
      [...segment]
        .reverse();

    const orderedStrings = [];

    for (
      let index = 0;
      index <
        reversed.length - 1;
      index += 1
    ) {
      if (
        reversed[index] !==
        stringTypeIndex
      ) {
        continue;
      }

      const stringIndex =
        Number(
          reversed[
            index + 1
          ]
        );

      if (
        !Number.isInteger(
          stringIndex
        ) ||
        stringIndex < 1 ||
        stringIndex >
          stringTable.length
      ) {
        continue;
      }

      orderedStrings.push({
        streamIndex:
          index,
        stringIndex,
        value:
          String(
            stringTable[
              stringIndex - 1
            ] ?? ""
          )
      });
    }

    const values =
      orderedStrings
        .map(
          (item) =>
            item.value
        )
        .filter(
          (value) =>
            value.trim() !== ""
        );

    const title =
      values.find(
        looksLikeCourseTitle
      ) ||
      values[0] ||
      null;

    const group =
      values.find(
        (value) =>
          value !== title &&
          looksLikeGroup(
            value
          )
      ) ||
      null;

    const timeText =
      values.find(
        (value) =>
          Boolean(
            parseAdeTimeRange(
              value
            )
          )
      ) ||
      null;

    const building =
      values.find(
        looksLikeBuilding
      ) ||
      null;

    const titlePosition =
      title
        ? values.indexOf(title)
        : -1;

    const groupPosition =
      group
        ? values.indexOf(group)
        : -1;

    const timePosition =
      timeText
        ? values.indexOf(
            timeText
          )
        : -1;

    const buildingPosition =
      building
        ? values.indexOf(
            building
          )
        : -1;

    const detailCandidates =
      values.filter(
        (value, index) => {
          if (
            value === title ||
            value === group ||
            value === timeText ||
            value === building
          ) {
            return false;
          }

          // Les détails utiles sont normalement placés
          // entre le groupe et l'horaire.
          if (
            groupPosition >= 0 &&
            timePosition >= 0
          ) {
            return (
              index >
                groupPosition &&
              index <
                timePosition
            );
          }

          return (
            index >
            Math.max(
              titlePosition,
              groupPosition
            )
          );
        }
      );

    let room =
      detailCandidates.find(
        looksLikeRoom
      ) ||
      null;

    if (!room) {
      const beforeTime =
        timePosition >= 0
          ? values.slice(
              Math.max(
                groupPosition + 1,
                0
              ),
              timePosition
            )
          : [];

      room =
        beforeTime.find(
          looksLikeRoom
        ) ||
        null;
    }

    const teachers =
      detailCandidates.filter(
        (value) =>
          value !== room
      );

    const timeRange =
      parseAdeTimeRange(
        timeText
      );

    rawEvents.push({
      rawIndex:
        eventIndex,
      geometry: {
        top:
          Number.isFinite(top)
            ? top
            : null,
        left:
          Number.isFinite(left)
            ? left
            : null,
        width:
          Number.isFinite(width)
            ? width
            : null,
        height:
          Number.isFinite(height)
            ? height
            : null
      },
      orderedStrings,
      rawStrings:
        values,
      title:
        title
          ? cleanAdeTitle(
              title
            )
          : null,
      rawTitle:
        title,
      type:
        classifyCourseType(
          title,
          group
        ),
      group:
        group
          ? group.trim()
          : null,
      room:
        room
          ? room.trim()
          : null,
      building:
        building
          ? building.trim()
          : null,
      teachers:
        teachers.map(
          (value) =>
            value.trim()
        ),
      timeText,
      start:
        timeRange?.start ||
        null,
      end:
        timeRange?.end ||
        null
    });
  }

  const medianWidth =
    medianNumber(
      rawEvents
        .map(
          (event) =>
            event.geometry.width
        )
        .filter(
          (value) =>
            Number.isFinite(
              value
            ) &&
            value > 0
        )
    );

  const normalizedEvents =
    rawEvents.map(
      (event) => {
        const dayIndex =
          (
            medianWidth &&
            Number.isFinite(
              event.geometry.left
            )
          )
            ? Math.max(
                0,
                Math.round(
                  event.geometry.left /
                  medianWidth
                )
              )
            : null;

        const date =
          (
            week?.firstDate &&
            Number.isInteger(
              dayIndex
            )
          )
            ? addDaysIso(
                week.firstDate,
                dayIndex
              )
            : null;

        return {
          date,
          dayIndex,
          start:
            event.start,
          end:
            event.end,
          title:
            event.title,
          type:
            event.type,
          group:
            event.group,
          teacher:
            event.teachers.length
              ? event.teachers.join(
                  " / "
                )
              : null,
          teachers:
            event.teachers,
          room:
            event.room,
          building:
            event.building,
          rawTitle:
            event.rawTitle,
          rawStrings:
            event.rawStrings,
          geometry:
            event.geometry
        };
      }
    );

  normalizedEvents.sort(
    (a, b) => {
      const dateCmp =
        String(
          a.date || ""
        ).localeCompare(
          String(
            b.date || ""
          )
        );

      if (dateCmp) {
        return dateCmp;
      }

      const startCmp =
        String(
          a.start || ""
        ).localeCompare(
          String(
            b.start || ""
          )
        );

      if (startCmp) {
        return startCmp;
      }

      return String(
        a.title || ""
      ).localeCompare(
        String(
          b.title || ""
        )
      );
    }
  );

  return {
    ok: true,
    code:
      "SQUARE_EVENTS_DECODED",
    gwt: {
      version,
      flags,
      stringTableCount:
        stringTable.length,
      eventTypeIndex,
      stringTypeIndex,
      expectedEventCount,
      detectedEventCount:
        normalizedEvents.length,
      markerCount:
        markers.length
    },
    week:
      week || null,
    geometry: {
      medianColumnWidth:
        medianWidth
    },
    events:
      normalizedEvents
  };
}

function normalizeCompareTitle(
  value
) {
  return cleanAdeTitle(
    String(value || "")
  )
    .toLocaleLowerCase(
      "fr-FR"
    )
    .replace(
      /\s+/g,
      " "
    )
    .trim();
}

function visibleEventTime(event) {
  const start =
    event?.start ||
    event?.startTime ||
    null;

  const end =
    event?.end ||
    event?.endTime ||
    null;

  if (
    start &&
    end
  ) {
    return {
      start:
        String(start).slice(
          0,
          5
        ),
      end:
        String(end).slice(
          0,
          5
        )
    };
  }

  const timeText =
    event?.time ||
    event?.timeText ||
    "";

  return parseAdeTimeRange(
    timeText
  );
}

async function decodePredictedSquareEvents() {
  const data =
    await storeGet([
      "fullSequencePrediction"
    ]);

  const prediction =
    data.fullSequencePrediction;

  if (
    !prediction?.timetableResponse
  ) {
    return {
      ok: false,
      code:
        "NO_TIMETABLE_RESPONSE_TO_DECODE",
      message:
        "Lance d'abord la prédiction stateful (bouton 14)."
    };
  }

  const decoded =
    decodeSquareEventsResponse(
      prediction.timetableResponse,
      prediction.targetWeek ||
        null
    );

  if (!decoded.ok) {
    return decoded;
  }

  const result = {
    ...decoded,
    generatedAt:
      nowIso(),
    source:
      "full-sequence-prediction"
  };

  await storeSet({
    decodedPredictedWeek:
      result
  });

  return result;
}

async function validateDecodedWeekAgainstVisible() {
  const data =
    await storeGet([
      "decodedPredictedWeek"
    ]);

  const decoded =
    data.decodedPredictedWeek;

  if (
    !decoded?.ok ||
    !Array.isArray(
      decoded.events
    )
  ) {
    return {
      ok: false,
      code:
        "NO_DECODED_WEEK",
      message:
        "Clique d'abord sur le bouton 16."
    };
  }

  const tab =
    await bestAdeTab();

  if (!tab) {
    return {
      ok: false,
      code:
        "ADE_NOT_OPEN",
      message:
        "Ouvre ADE sur la semaine décodée."
    };
  }

  const visible =
    await scrapeVisibleWeek(
      tab.id
    );

  if (
    !visible?.ok ||
    !Array.isArray(
      visible.events
    )
  ) {
    return {
      ok: false,
      code:
        "VISIBLE_WEEK_NOT_READABLE",
      message:
        "Le planning affiché n'a pas pu être lu.",
      diagnostics:
        visible?.diagnostics ||
        null
    };
  }

  const decodedEvents =
    decoded.events;

  const visibleEvents =
    visible.events;

  const matches = [];
  let titleTimeHits = 0;
  let dateHits = 0;

  for (
    const visibleEvent
    of visibleEvents
  ) {
    const visibleTitle =
      normalizeCompareTitle(
        visibleEvent.title ||
        visibleEvent.name ||
        visibleEvent.subject ||
        ""
      );

    const visibleTime =
      visibleEventTime(
        visibleEvent
      );

    let best = null;

    for (
      const decodedEvent
      of decodedEvents
    ) {
      if (
        normalizeCompareTitle(
          decodedEvent.title
        ) !==
        visibleTitle
      ) {
        continue;
      }

      const timeMatches =
        !visibleTime ||
        (
          decodedEvent.start ===
            visibleTime.start &&
          decodedEvent.end ===
            visibleTime.end
        );

      if (!timeMatches) {
        continue;
      }

      best =
        decodedEvent;
      break;
    }

    if (!best) {
      matches.push({
        visibleTitle,
        matched:
          false
      });
      continue;
    }

    titleTimeHits += 1;

    const visibleDate =
      visibleEvent.date ||
      visibleEvent.dayDate ||
      null;

    const dateMatches =
      !visibleDate ||
      !best.date ||
      String(
        visibleDate
      ).slice(0, 10) ===
        String(
          best.date
        ).slice(0, 10);

    if (dateMatches) {
      dateHits += 1;
    }

    matches.push({
      visibleTitle,
      visibleDate:
        visibleDate || null,
      decodedDate:
        best.date,
      start:
        best.start,
      end:
        best.end,
      matched:
        true,
      dateMatches
    });
  }

  const checked =
    visibleEvents.length;

  const titleTimeScore =
    checked
      ? titleTimeHits /
        checked
      : 0;

  const dateScore =
    checked
      ? dateHits /
        checked
      : 0;

  const sameWeek =
    Boolean(
      decoded.week?.firstDate &&
      visible.week?.firstDate &&
      decoded.week.firstDate ===
        visible.week.firstDate &&
      decoded.week.lastDate ===
        visible.week.lastDate
    );

  const ok =
    sameWeek &&
    checked > 0 &&
    titleTimeScore >= 0.95 &&
    dateScore >= 0.95;

  const result = {
    ok,
    code: ok
      ? "SQUARE_EVENT_DECODER_CONFIRMED"
      : "SQUARE_EVENT_DECODER_MISMATCH",
    message: ok
      ? "Décodage confirmé : les SquareEvent reconstruits correspondent aux cours réellement affichés, y compris les dates."
      : "Le décodage est partiel : consulte les scores et les correspondances.",
    decodedWeek:
      decoded.week || null,
    visibleWeek:
      visible.week || null,
    sameWeek,
    decodedEventCount:
      decodedEvents.length,
    visibleEventCount:
      checked,
    titleTimeHits,
    dateHits,
    titleTimeScore,
    dateScore,
    matches
  };

  await storeSet({
    lastSquareEventDecoderValidation: {
      testedAt:
        nowIso(),
      ...result
    }
  });

  return result;
}


function buildWeekSequenceForOffset(
  previousTrace,
  latestTrace,
  offset
) {
  const pairs =
    pairTraceEntriesByOperation(
      previousTrace,
      latestTrace
    );

  const sequence = [];
  const diagnostics = [];

  for (const pair of pairs) {
    const latest =
      pair.latest;

    if (!latest?.body) {
      continue;
    }

    let body =
      latest.body;

    let mutation =
      null;

    if (pair.previous?.body) {
      const detection =
        detectSingleIncrement(
          pair.previous.body,
          latest.body
        );

      diagnostics.push({
        operation:
          pair.key,
        detection
      });

      if (
        detection.ok &&
        !detection.unchanged
      ) {
        const targetValue =
          detection.currentValue +
          offset;

        const changed =
          rebuildGwtBodyWithPayloadToken(
            latest.body,
            detection.payloadIndex,
            targetValue
          );

        body =
          changed.body;

        mutation = {
          payloadIndex:
            changed.payloadIndex,
          before:
            changed.before,
          after:
            changed.after,
          previousValue:
            detection.previousValue,
          baseValue:
            detection.currentValue,
          targetValue
        };
      }
    }

    sequence.push({
      operation:
        pair.key,
      method:
        latest.method || "POST",
      url:
        latest.url,
      body,
      sourceBody:
        latest.body,
      mutation
    });
  }

  return {
    sequence,
    diagnostics
  };
}

function compactNormalizedEvent(event) {
  return {
    date:
      event?.date || null,
    start:
      event?.start || null,
    end:
      event?.end || null,
    title:
      event?.title || null,
    type:
      event?.type || null,
    group:
      event?.group || null,
    teacher:
      event?.teacher || null,
    teachers:
      Array.isArray(event?.teachers)
        ? event.teachers
        : [],
    room:
      event?.room || null,
    building:
      event?.building || null
  };
}


function compactScrapedEvent(event) {
  const teachers = Array.isArray(event?.teacherCandidates)
    ? event.teacherCandidates.filter(Boolean)
    : [];
  const group = event?.groupLine || event?.group || null;
  const typeMatch = String(group || "").match(/^(CM|TD|TP|TDP|CTD)\b/i);
  return {
    date: event?.date || null,
    start: event?.start || event?.startTime || null,
    end: event?.end || event?.endTime || null,
    title: event?.title || null,
    type: event?.type || (typeMatch ? typeMatch[1].toUpperCase() : null),
    group,
    teacher: event?.teacher || teachers[0] || null,
    teachers,
    room: event?.room || null,
    building: event?.building || null
  };
}

function mergeNormalizedEventLists(...lists) {
  return deduplicateEvents(
    lists.flatMap((list) => Array.isArray(list) ? list : [])
      .map((event) => compactNormalizedEvent(event))
      .filter((event) => event.date && event.start && event.title)
  ).sort((a, b) => {
    const date = String(a.date || "").localeCompare(String(b.date || ""));
    return date || String(a.start || "").localeCompare(String(b.start || ""));
  });
}

function weekResultFromScrapedPreview(preview, sourceCode = "WEEK_SCRAPED_FROM_REAL_NAVIGATION") {
  const week = preview?.week || null;
  if (!week?.firstDate || !week?.lastDate) return null;
  const events = (Array.isArray(preview?.events) ? preview.events : [])
    .map(compactScrapedEvent)
    .filter((event) => event.date && event.start && event.title);
  return {
    offset: null,
    week: { firstDate: week.firstDate, lastDate: week.lastDate },
    ok: true,
    code: sourceCode,
    syncedAt: nowIso(),
    eventCount: events.length,
    events: deduplicateEvents(events)
  };
}

async function generateAndDecodeNextWeeks() {
  const data =
    await storeGet([
      "weekTraces",
      "savedProfile"
    ]);

  const traces =
    Array.isArray(
      data.weekTraces
    )
      ? data.weekTraces
      : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code:
        "NEED_TWO_REAL_TRACES",
      message:
        "Il faut conserver au moins deux vraies transitions ADE."
    };
  }

  const previous =
    traces[traces.length - 2];

  const latest =
    traces[traces.length - 1];

  if (
    !latest?.afterWeek?.firstDate ||
    !latest?.afterWeek?.lastDate
  ) {
    return {
      ok: false,
      code:
        "BASE_WEEK_UNKNOWN",
      message:
        "La dernière trace ne contient pas les dates de la semaine de base."
    };
  }

  const profile =
    data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code:
        "NO_PROFILE",
      message:
        "Le profil RPC n'est plus disponible."
    };
  }

  const requestedWeeks = 8;
  const results = [];

  await storeSet({
    decodedBatchStatus: {
      state:
        "running",
      startedAt:
        nowIso(),
      requestedWeeks,
      completedWeeks:
        0
    }
  });

  try {
    for (
      let offset = 1;
      offset <= requestedWeeks;
      offset += 1
    ) {
      const targetWeek = {
        firstDate:
          addDaysIso(
            latest.afterWeek.firstDate,
            7 * offset
          ),
        lastDate:
          addDaysIso(
            latest.afterWeek.lastDate,
            7 * offset
          )
      };

      const built =
        buildWeekSequenceForOffset(
          previous,
          latest,
          offset
        );

      const replay =
        await replaySequenceInFreshPage(
          built.sequence,
          profile.rpcTemplate.headers || {}
        );

      const timetableStep =
        replay.steps.find(
          (step) =>
            step.operation.includes(
              "method10getTimetable"
            )
        ) || null;

      if (!timetableStep) {
        results.push({
          offset,
          week:
            targetWeek,
          ok:
            false,
          code:
            "NO_TIMETABLE_STEP",
          sequenceOk:
            replay.ok,
          eventCount:
            0,
          events:
            []
        });

        continue;
      }

      const decoded =
        decodeSquareEventsResponse(
          timetableStep.responseText,
          targetWeek
        );

      const events =
        decoded.ok
          ? decoded.events.map(
              compactNormalizedEvent
            )
          : [];

      const responseHash =
        await sha256Text(
          timetableStep.responseText
        );

      const titleSet =
        [...new Set(
          events
            .map(
              (event) =>
                event.title
            )
            .filter(Boolean)
        )];

      results.push({
        offset,
        week:
          targetWeek,
        ok:
          Boolean(
            replay.ok &&
            decoded.ok
          ),
        code:
          decoded.ok
            ? "WEEK_DECODED"
            : decoded.code,
        sequenceOk:
          replay.ok,
        responseHash,
        responseLength:
          timetableStep.responseLength,
        eventCount:
          events.length,
        expectedEventCount:
          decoded?.gwt?.expectedEventCount ??
          null,
        detectedEventCount:
          decoded?.gwt?.detectedEventCount ??
          null,
        titles:
          titleSet,
        events,
        sequenceMutations:
          built.sequence
            .filter(
              (item) =>
                item.mutation
            )
            .map(
              (item) => ({
                operation:
                  item.operation,
                payloadIndex:
                  item.mutation.payloadIndex,
                targetValue:
                  item.mutation.targetValue
              })
            )
      });

      await storeSet({
        decodedBatchStatus: {
          state:
            "running",
          requestedWeeks,
          completedWeeks:
            results.length,
          currentWeek:
            targetWeek
        }
      });

      await sleep(250);
    }

    const successCount =
      results.filter(
        (week) => week.ok
      ).length;

    const allEvents =
      results.flatMap(
        (week) =>
          week.events.map(
            (event) => ({
              ...event,
              weekFirstDate:
                week.week.firstDate
            })
          )
      );

    const distinctResponseCount =
      new Set(
        results
          .map(
            (week) =>
              week.responseHash
          )
          .filter(Boolean)
      ).size;

    const result = {
      ok:
        successCount ===
        requestedWeeks,
      code:
        successCount ===
        requestedWeeks
          ? "DECODED_WEEK_BATCH_OK"
          : "DECODED_WEEK_BATCH_PARTIAL",
      message:
        successCount ===
        requestedWeeks
          ? "Les 8 semaines suivantes ont été générées et décodées sans utiliser le DOM ADE."
          : `${successCount}/${requestedWeeks} semaines ont été générées et décodées correctement.`,
      generatedAt:
        nowIso(),
      baseWeek:
        latest.afterWeek,
      requestedWeeks,
      successCount,
      distinctResponseCount,
      totalEventCount:
        allEvents.length,
      weeks:
        results,
      allEvents
    };

    await storeSet({
      decodedWeekBatch:
        result,
      decodedBatchStatus: {
        state:
          "finished",
        finishedAt:
          nowIso(),
        ok:
          result.ok,
        code:
          result.code,
        requestedWeeks,
        completedWeeks:
          results.length
      }
    });

    return {
      ok:
        result.ok,
      code:
        result.code,
      message:
        result.message,
      generatedAt:
        result.generatedAt,
      baseWeek:
        result.baseWeek,
      requestedWeeks:
        result.requestedWeeks,
      successCount:
        result.successCount,
      distinctResponseCount:
        result.distinctResponseCount,
      totalEventCount:
        result.totalEventCount,
      weeks:
        results.map(
          (week) => ({
            offset:
              week.offset,
            week:
              week.week,
            ok:
              week.ok,
            code:
              week.code,
            responseHash:
              week.responseHash,
            responseLength:
              week.responseLength,
            eventCount:
              week.eventCount,
            expectedEventCount:
              week.expectedEventCount,
            detectedEventCount:
              week.detectedEventCount,
            titles:
              week.titles
          })
        )
    };
  } catch (error) {
    const result = {
      ok: false,
      code:
        "DECODED_WEEK_BATCH_EXCEPTION",
      message:
        String(error),
      completedWeeks:
        results.length
    };

    await storeSet({
      decodedBatchStatus: {
        state:
          "finished",
        finishedAt:
          nowIso(),
        ok:
          false,
        code:
          result.code,
        completedWeeks:
          results.length
      }
    });

    return result;
  }
}

async function decodedWeekBatchSummary() {
  const data =
    await storeGet([
      "decodedWeekBatch",
      "decodedBatchStatus"
    ]);

  const batch =
    data.decodedWeekBatch;

  if (!batch) {
    return {
      ok: false,
      code:
        "NO_DECODED_WEEK_BATCH",
      message:
        "Aucun lot multi-semaines décodé n'est disponible."
    };
  }

  return {
    ok: true,
    code:
      "DECODED_WEEK_BATCH_SUMMARY",
    status:
      data.decodedBatchStatus ||
      null,
    generatedAt:
      batch.generatedAt,
    baseWeek:
      batch.baseWeek,
    requestedWeeks:
      batch.requestedWeeks,
    successCount:
      batch.successCount,
    distinctResponseCount:
      batch.distinctResponseCount,
    totalEventCount:
      batch.totalEventCount,
    weeks:
      (batch.weeks || []).map(
        (week) => ({
          offset:
            week.offset,
          week:
            week.week,
          ok:
            week.ok,
          code:
            week.code,
          responseHash:
            week.responseHash,
          responseLength:
            week.responseLength,
          eventCount:
            week.eventCount,
          expectedEventCount:
            week.expectedEventCount,
          detectedEventCount:
            week.detectedEventCount,
          titles:
            week.titles,
          sampleEvents:
            (week.events || [])
              .slice(0, 3)
        })
      )
  };
}

async function decodedWeekBatchData() {
  const data =
    await storeGet([
      "decodedWeekBatch"
    ]);

  const batch =
    data.decodedWeekBatch;

  if (!batch) {
    return {
      ok: false,
      code:
        "NO_DECODED_WEEK_BATCH",
      message:
        "Aucun lot multi-semaines décodé n'est disponible."
    };
  }

  return {
    ok: true,
    code:
      "NORMALIZED_TIMETABLE_DATA",
    generatedAt:
      batch.generatedAt,
    baseWeek:
      batch.baseWeek,
    weekCount:
      batch.weeks?.length || 0,
    eventCount:
      batch.allEvents?.length || 0,
    events:
      batch.allEvents || []
  };
}


function looksLikeAuthenticationPage(
  responseText,
  httpStatus
) {
  const status =
    Number(httpStatus);

  if (
    status === 401 ||
    status === 403
  ) {
    return true;
  }

  const text =
    String(responseText || "");

  if (
    text.trimStart().startsWith("//OK") ||
    text.trimStart().startsWith("//EX")
  ) {
    return false;
  }

  return (
    /<html[\s>]/i.test(text) &&
    (
      /\bcas\b/i.test(text) ||
      /\blemonldap\b/i.test(text) ||
      /\bauthentification\b/i.test(text) ||
      /\bconnexion\b/i.test(text) ||
      /\blogin\b/i.test(text)
    )
  );
}

async function replaySingleSequenceItemInExistingTab(tabId, item, headers) {
  if (!item?.body || !item?.url) {
    return { ok: false, authRequired: false, steps: [] };
  }

  const replay = await replayInPage(tabId, {
    method: item.method || "POST",
    url: item.url,
    headers: headers || {},
    body: item.body
  });

  const responseText = String(replay?.responseText || "");
  const authRequired = looksLikeAuthenticationPage(responseText, replay?.httpStatus);
  const step = {
    index: 0,
    operation: item.operation,
    mutation: item.mutation,
    httpStatus: replay?.httpStatus ?? null,
    gwtOk: responseText.trimStart().startsWith("//OK"),
    authRequired,
    responseLength: responseText.length,
    requestHash: await sha256Text(item.body),
    responseHash: await sha256Text(responseText),
    responseText
  };

  const httpOk = Number.isFinite(Number(step.httpStatus)) && Number(step.httpStatus) >= 200 && Number(step.httpStatus) < 300;
  return {
    ok: !authRequired && step.gwtOk && httpOk,
    authRequired,
    steps: [step]
  };
}

async function replaySequenceInExistingTab(
  tabId,
  sequence,
  headers
) {
  const steps = [];

  for (
    let index = 0;
    index < sequence.length;
    index += 1
  ) {
    const item =
      sequence[index];

    const replay =
      await replayInPage(
        tabId,
        {
          method:
            item.method ||
            "POST",
          url:
            item.url,
          headers:
            headers || {},
          body:
            item.body
        }
      );

    const responseText =
      String(
        replay?.responseText ||
        ""
      );

    const authRequired =
      looksLikeAuthenticationPage(
        responseText,
        replay?.httpStatus
      );

    const step = {
      index,
      operation:
        item.operation,
      mutation:
        item.mutation,
      httpStatus:
        replay?.httpStatus ??
        null,
      gwtOk:
        responseText
          .trimStart()
          .startsWith("//OK"),
      authRequired,
      responseLength:
        responseText.length,
      requestHash:
        await sha256Text(
          item.body
        ),
      responseHash:
        await sha256Text(
          responseText
        ),
      responseText
    };

    steps.push(step);

    if (authRequired) {
      return {
        ok: false,
        authRequired: true,
        steps
      };
    }

    if (
      !step.gwtOk ||
      !Number.isFinite(
        Number(step.httpStatus)
      ) ||
      Number(step.httpStatus) < 200 ||
      Number(step.httpStatus) >= 300
    ) {
      return {
        ok: false,
        authRequired: false,
        steps
      };
    }

    await sleep(120);
  }

  return {
    ok: true,
    authRequired: false,
    steps
  };
}

function academicEndDateForWeek(
  week
) {
  if (!week?.firstDate) {
    return null;
  }

  const base =
    new Date(
      `${week.firstDate}T12:00:00Z`
    );

  if (
    Number.isNaN(
      base.getTime()
    )
  ) {
    return null;
  }

  const year =
    base.getUTCFullYear();

  const month =
    base.getUTCMonth() + 1;

  const endYear =
    month >= 7
      ? year + 1
      : year;

  return (
    `${endYear}-06-30`
  );
}

function weeksUntilInclusiveEnd(
  baseWeek,
  endDate
) {
  if (
    !baseWeek?.firstDate ||
    !endDate
  ) {
    return [];
  }

  const result = [];

  for (
    let offset = 0;
    offset < 60;
    offset += 1
  ) {
    const firstDate =
      addDaysIso(
        baseWeek.firstDate,
        7 * offset
      );

    if (!firstDate) {
      break;
    }

    if (
      firstDate >
      endDate
    ) {
      break;
    }

    result.push({
      offset,
      firstDate,
      lastDate:
        addDaysIso(
          baseWeek.lastDate,
          7 * offset
        )
    });
  }

  return result;
}

function eventStableKey(event) {
  return [
    event?.date || "",
    event?.start || "",
    event?.end || "",
    event?.title || "",
    event?.type || "",
    event?.group || "",
    event?.teacher || "",
    event?.room || "",
    event?.building || ""
  ].join("||");
}

function deduplicateEvents(events) {
  const seen =
    new Set();

  const result = [];

  for (
    const event
    of events || []
  ) {
    const key =
      eventStableKey(
        event
      );

    if (seen.has(key)) {
      continue;
    }

    seen.add(key);

    result.push(event);
  }

  return result;
}

async function syncAcademicPeriodForward() {
  const data =
    await storeGet([
      "weekTraces",
      "savedProfile",
      "academicSyncCache"
    ]);

  const traces =
    Array.isArray(
      data.weekTraces
    )
      ? data.weekTraces
      : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code:
        "NEED_TWO_REAL_TRACES",
      message:
        "Il faut conserver au moins deux vraies transitions ADE."
    };
  }

  const previous =
    traces[
      traces.length - 2
    ];

  const latest =
    traces[
      traces.length - 1
    ];

  const baseWeek =
    latest.afterWeek;

  if (
    !baseWeek?.firstDate ||
    !baseWeek?.lastDate
  ) {
    return {
      ok: false,
      code:
        "BASE_WEEK_UNKNOWN",
      message:
        "Les dates de la semaine de base sont inconnues."
    };
  }

  const profile =
    data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code:
        "NO_PROFILE",
      message:
        "Le profil RPC n'est plus disponible."
    };
  }

  const endDate =
    academicEndDateForWeek(
      baseWeek
    );

  const targets =
    weeksUntilInclusiveEnd(
      baseWeek,
      endDate
    );

  if (!targets.length) {
    return {
      ok: false,
      code:
        "NO_ACADEMIC_TARGETS",
      message:
        "Aucune semaine à synchroniser."
    };
  }

  const startedAt =
    nowIso();

  let cache = {
    schemaVersion: 1,
    source:
      "unilim-ade",
    resourceId:
      profile.resourceId ??
      null,
    startedAt,
    updatedAt:
      startedAt,
    baseWeek,
    endDate,
    weekCount:
      targets.length,
    completedWeekCount:
      0,
    weeks: [],
    events: [],
    authRequired:
      false
  };

  await storeSet({
    academicSyncStatus: {
      state:
        "running",
      startedAt,
      completedWeeks:
        0,
      requestedWeeks:
        targets.length,
      currentWeek:
        null
    },
    academicSyncCache:
      cache
  });

  let tab = null;

  try {
    tab =
      await openFreshAde();

    for (
      let index = 0;
      index < targets.length;
      index += 1
    ) {
      const target =
        targets[index];

      const built =
        buildWeekSequenceForOffset(
          previous,
          latest,
          target.offset
        );

      const replay =
        await replaySequenceInExistingTab(
          tab.id,
          built.sequence,
          profile.rpcTemplate.headers || {}
        );

      if (replay.authRequired) {
        cache = {
          ...cache,
          updatedAt:
            nowIso(),
          completedWeekCount:
            cache.weeks.length,
          authRequired:
            true
        };

        await storeSet({
          academicSyncCache:
            cache,
          academicSyncStatus: {
            state:
              "auth_required",
            code:
              "AUTH_REQUIRED",
            finishedAt:
              nowIso(),
            completedWeeks:
              cache.weeks.length,
            requestedWeeks:
              targets.length,
            currentWeek:
              target
          }
        });

        return {
          ok: false,
          code:
            "AUTH_REQUIRED",
          message:
            "La session UNILIM/ADE n'est plus authentifiée. Reconnecte-toi à ADE puis relance la synchronisation ; le cache déjà obtenu est conservé.",
          completedWeeks:
            cache.weeks.length,
          requestedWeeks:
            targets.length,
          cachedEventCount:
            cache.events.length
        };
      }

      const timetableStep =
        replay.steps.find(
          (step) =>
            step.operation.includes(
              "method10getTimetable"
            )
        ) || null;

      if (
        !replay.ok ||
        !timetableStep
      ) {
        const failure = {
          offset:
            target.offset,
          week: {
            firstDate:
              target.firstDate,
            lastDate:
              target.lastDate
          },
          ok:
            false,
          code:
            timetableStep
              ? "RPC_SEQUENCE_FAILED"
              : "NO_TIMETABLE_STEP",
          eventCount:
            0,
          events:
            []
        };

        cache.weeks.push(
          failure
        );

        cache.updatedAt =
          nowIso();

        cache.completedWeekCount =
          cache.weeks.length;

        await storeSet({
          academicSyncCache:
            cache,
          academicSyncStatus: {
            state:
              "running",
            startedAt,
            completedWeeks:
              cache.weeks.length,
            requestedWeeks:
              targets.length,
            currentWeek:
              failure.week
          }
        });

        continue;
      }

      const week = {
        firstDate:
          target.firstDate,
        lastDate:
          target.lastDate
      };

      const decoded =
        decodeSquareEventsResponse(
          timetableStep.responseText,
          week
        );

      const events =
        decoded.ok
          ? decoded.events.map(
              compactNormalizedEvent
            )
          : [];

      const weekResult = {
        offset:
          target.offset,
        week,
        ok:
          decoded.ok,
        code:
          decoded.ok
            ? "WEEK_DECODED"
            : decoded.code,
        responseHash:
          timetableStep.responseHash,
        responseLength:
          timetableStep.responseLength,
        eventCount:
          events.length,
        expectedEventCount:
          decoded?.gwt?.expectedEventCount ??
          null,
        detectedEventCount:
          decoded?.gwt?.detectedEventCount ??
          null,
        events
      };

      cache.weeks.push(
        weekResult
      );

      cache.events =
        deduplicateEvents([
          ...cache.events,
          ...events
        ]);

      cache.updatedAt =
        nowIso();

      cache.completedWeekCount =
        cache.weeks.length;

      await storeSet({
        academicSyncCache:
          cache,
        academicSyncStatus: {
          state:
            "running",
          startedAt,
          completedWeeks:
            cache.weeks.length,
          requestedWeeks:
            targets.length,
          currentWeek:
            week
        }
      });

      await sleep(220);
    }

    const successCount =
      cache.weeks.filter(
        (week) =>
          week.ok
      ).length;

    const distinctResponseCount =
      new Set(
        cache.weeks
          .map(
            (week) =>
              week.responseHash
          )
          .filter(Boolean)
      ).size;

    cache = {
      ...cache,
      updatedAt:
        nowIso(),
      finishedAt:
        nowIso(),
      successCount,
      distinctResponseCount,
      completedWeekCount:
        cache.weeks.length,
      authRequired:
        false
    };

    const result = {
      ok:
        successCount ===
        targets.length,
      code:
        successCount ===
        targets.length
          ? "ACADEMIC_FORWARD_SYNC_OK"
          : "ACADEMIC_FORWARD_SYNC_PARTIAL",
      message:
        successCount ===
        targets.length
          ? "Synchronisation terminée : toutes les semaines jusqu'à fin juin ont été générées et décodées."
          : `${successCount}/${targets.length} semaines ont été synchronisées correctement.`,
      baseWeek,
      endDate,
      requestedWeeks:
        targets.length,
      successCount,
      distinctResponseCount,
      eventCount:
        cache.events.length,
      firstSyncedWeek:
        cache.weeks[0]?.week ||
        null,
      lastSyncedWeek:
        cache.weeks[
          cache.weeks.length - 1
        ]?.week || null
    };

    await storeSet({
      academicSyncCache:
        cache,
      academicSyncStatus: {
        state:
          "finished",
        finishedAt:
          nowIso(),
        ok:
          result.ok,
        code:
          result.code,
        completedWeeks:
          cache.weeks.length,
        requestedWeeks:
          targets.length
      }
    });

    return result;
  } catch (error) {
    cache = {
      ...cache,
      updatedAt:
        nowIso(),
      completedWeekCount:
        cache.weeks.length
    };

    await storeSet({
      academicSyncCache:
        cache,
      academicSyncStatus: {
        state:
          "finished",
        finishedAt:
          nowIso(),
        ok:
          false,
        code:
          "ACADEMIC_FORWARD_SYNC_EXCEPTION",
        completedWeeks:
          cache.weeks.length,
        requestedWeeks:
          targets.length
      }
    });

    return {
      ok: false,
      code:
        "ACADEMIC_FORWARD_SYNC_EXCEPTION",
      message:
        String(error),
      completedWeeks:
        cache.weeks.length,
      requestedWeeks:
        targets.length,
      cachedEventCount:
        cache.events.length
    };
  } finally {
    if (tab?.id) {
      try {
        await chrome.tabs.remove(
          tab.id
        );
      } catch {}
    }
  }
}

async function academicSyncSummary() {
  const data =
    await storeGet([
      "academicSyncCache",
      "academicSyncStatus"
    ]);

  const cache =
    data.academicSyncCache;

  if (!cache) {
    return {
      ok: false,
      code:
        "NO_ACADEMIC_SYNC_CACHE",
      message:
        "Aucune synchronisation académique n'a encore été lancée."
    };
  }

  return {
    ok: true,
    code:
      "ACADEMIC_SYNC_SUMMARY",
    status:
      data.academicSyncStatus ||
      null,
    source:
      cache.source,
    resourceId:
      cache.resourceId,
    baseWeek:
      cache.baseWeek,
    endDate:
      cache.endDate,
    startedAt:
      cache.startedAt,
    updatedAt:
      cache.updatedAt,
    finishedAt:
      cache.finishedAt ||
      null,
    requestedWeeks:
      cache.weekCount,
    completedWeeks:
      cache.completedWeekCount,
    successCount:
      cache.successCount ??
      cache.weeks.filter(
        (week) => week.ok
      ).length,
    distinctResponseCount:
      cache.distinctResponseCount ??
      new Set(
        cache.weeks
          .map(
            (week) =>
              week.responseHash
          )
          .filter(Boolean)
      ).size,
    authRequired:
      Boolean(
        cache.authRequired
      ),
    eventCount:
      cache.events.length,
    weeks:
      cache.weeks.map(
        (week) => ({
          offset:
            week.offset,
          week:
            week.week,
          ok:
            week.ok,
          code:
            week.code,
          eventCount:
            week.eventCount,
          expectedEventCount:
            week.expectedEventCount,
          detectedEventCount:
            week.detectedEventCount,
          responseHash:
            week.responseHash
        })
      )
  };
}

async function academicPlanilimPayload() {
  const data =
    await storeGet([
      "academicSyncCache",
      "savedProfile"
    ]);

  const cache =
    data.academicSyncCache;

  if (!cache) {
    return {
      ok: false,
      code:
        "NO_ACADEMIC_SYNC_CACHE",
      message:
        "Synchronise d'abord la période académique."
    };
  }

  const profile =
    data.savedProfile;

  const events =
    deduplicateEvents(
      cache.events || []
    );

  return {
    ok: true,
    code:
      "PLANILIM_PAYLOAD_READY",
    payload: {
      schemaVersion: 1,
      source:
        "unilim-ade",
      generatedAt:
        nowIso(),
      resource: {
        id:
          profile?.resourceId ??
          cache.resourceId ??
          null
      },
      syncRange: {
        firstDate:
          cache.weeks[0]?.week?.firstDate ||
          cache.baseWeek?.firstDate ||
          null,
        lastDate:
          cache.weeks[
            cache.weeks.length - 1
          ]?.week?.lastDate ||
          null
      },
      weekCount:
        cache.weeks.length,
      eventCount:
        events.length,
      events
    }
  };
}


function isoDateOnly(value) {
  const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return match ? `${match[1]}-${match[2]}-${match[3]}` : null;
}

function mondayOnOrBeforeIso(isoDate) {
  const clean = isoDateOnly(isoDate);
  if (!clean) return null;
  const date = new Date(`${clean}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) return null;
  const daysFromMonday = (date.getUTCDay() + 6) % 7;
  date.setUTCDate(date.getUTCDate() - daysFromMonday);
  return date.toISOString().slice(0, 10);
}

function sundayOnOrAfterIso(isoDate) {
  const monday = mondayOnOrBeforeIso(isoDate);
  return monday ? addDaysIso(monday, 6) : null;
}

function academicYearBoundsForWeek(week) {
  if (!week?.firstDate) return null;
  const date = new Date(`${week.firstDate}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) return null;
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const startYear = month >= 7 ? year : year - 1;
  const septemberFirst = `${startYear}-09-01`;
  const juneThirtieth = `${startYear + 1}-06-30`;
  return {
    academicYear: `${startYear}-${startYear + 1}`,
    startDate: mondayOnOrBeforeIso(septemberFirst),
    endDate: sundayOnOrAfterIso(juneThirtieth),
    nominalStartDate: septemberFirst,
    nominalEndDate: juneThirtieth
  };
}

function daysBetweenIso(fromIso, toIso) {
  const from = new Date(`${fromIso}T12:00:00Z`);
  const to = new Date(`${toIso}T12:00:00Z`);
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) return null;
  return Math.round((to.getTime() - from.getTime()) / 86400000);
}

function weekOffsetFromBase(baseWeek, targetFirstDate) {
  if (!baseWeek?.firstDate || !targetFirstDate) return null;
  const days = daysBetweenIso(baseWeek.firstDate, targetFirstDate);
  if (days === null || days % 7 !== 0) return null;
  return days / 7;
}

function weeklyTargetsForRange(baseWeek, startDate, endDate) {
  if (!baseWeek?.firstDate || !startDate || !endDate) return [];
  const startMonday = mondayOnOrBeforeIso(startDate);
  const endSunday = sundayOnOrAfterIso(endDate);
  if (!startMonday || !endSunday) return [];
  const targets = [];
  for (let firstDate = startMonday; firstDate <= endSunday; firstDate = addDaysIso(firstDate, 7)) {
    const offset = weekOffsetFromBase(baseWeek, firstDate);
    if (!Number.isInteger(offset)) continue;
    targets.push({ offset, firstDate, lastDate: addDaysIso(firstDate, 6) });
  }
  return targets;
}

function weekCacheMap(weeks) {
  const map = new Map();
  for (const week of weeks || []) {
    const key = week?.week?.firstDate;
    if (key) map.set(key, week);
  }
  return map;
}

function rebuildEventsFromWeeks(weeks) {
  return deduplicateEvents(
    (weeks || [])
      .filter((week) => week?.ok && Array.isArray(week.events))
      .flatMap((week) => week.events)
  );
}

function sortedCachedWeeks(map) {
  return [...map.values()].sort((a, b) =>
    String(a?.week?.firstDate || "").localeCompare(String(b?.week?.firstDate || ""))
  );
}

function collectorFailedWeekSummary(targets, map) {
  const failures = [];
  for (const target of targets || []) {
    const result = map.get(target.firstDate) || null;
    if (result?.ok) continue;
    failures.push({
      firstDate: target.firstDate,
      code: result?.code || "WEEK_RESULT_MISSING"
    });
  }

  const counts = new Map();
  for (const failure of failures) {
    counts.set(failure.code, (counts.get(failure.code) || 0) + 1);
  }
  const summary = [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])))
    .map(([code, count]) => `${code} ×${count}`)
    .join(', ');

  return {
    failedWeekCount: failures.length,
    failedWeeks: failures,
    failedWeekSummary: summary || null
  };
}

async function syncTargetsIntoAcademicCache(targets, options = {}) {
  const data = await storeGet(["weekTraces", "savedProfile", "academicSyncCache"]);
  const traces = Array.isArray(data.weekTraces) ? data.weekTraces : [];
  if (traces.length < 2) {
    return { ok: false, code: "NEED_TWO_REAL_TRACES", message: "Il faut conserver au moins deux vraies transitions ADE." };
  }

  const previous = traces[traces.length - 2];
  const latest = traces[traces.length - 1];
  const baseWeek = latest.afterWeek;
  if (!baseWeek?.firstDate || !baseWeek?.lastDate) {
    return { ok: false, code: "BASE_WEEK_UNKNOWN", message: "La semaine de base est inconnue." };
  }

  const profile = data.savedProfile;
  if (!profile?.rpcTemplate) {
    return { ok: false, code: "NO_PROFILE", message: "Le profil RPC n'est plus disponible." };
  }

  const bounds = academicYearBoundsForWeek(baseWeek);
  const existing = data.academicSyncCache || {};
  const map = weekCacheMap(existing.weeks || []);
  const startedAt = nowIso();
  const statusLabel = options.statusLabel || "academic-sync";
  const forceFullSequence = options.forceFullSequence === true;
  const weekConcurrency = Math.max(1, Math.min(4, Number(options.weekConcurrency) || 1));
  const batchDelayMs = options.delayMs ?? (weekConcurrency > 1 ? 35 : 180);

  await storeSet({
    academicSyncStatus: {
      state: "running",
      mode: options.mode || "manual",
      statusLabel,
      startedAt,
      completedWeeks: 0,
      requestedWeeks: targets.length,
      currentWeek: null,
      weekConcurrency
    }
  });

  let tab = null;
  let ownsTab = false;
  try {
    if (Number.isInteger(options.tabId)) {
      tab = await chrome.tabs.get(options.tabId).catch(() => null);
      if (!tab) {
        return { ok: false, code: "ADE_TAB_MISSING", message: "L'onglet ADE initialisé n'est plus disponible." };
      }
      const authenticated = await v3TabLooksAuthenticated(tab.id);
      if (!authenticated) {
        return { ok: false, code: "AUTH_REQUIRED", message: "La session ADE a expiré. Reconnecte-toi à l'université." };
      }
    } else {
      tab = await openFreshAde();
      ownsTab = true;
    }

    const syncOneTarget = async (target, preferFullSequence = forceFullSequence) => {
      const built = buildWeekSequenceForOffset(previous, latest, target.offset);
      const timetableRequest = built.sequence.find((item) =>
        String(item.operation || "").includes("method10getTimetable")
      ) || null;

      let replay = !preferFullSequence && timetableRequest
        ? await replaySingleSequenceItemInExistingTab(
            tab.id,
            timetableRequest,
            profile.rpcTemplate.headers || {}
          )
        : await replaySequenceInExistingTab(
            tab.id,
            built.sequence,
            profile.rpcTemplate.headers || {}
          );

      const week = { firstDate: target.firstDate, lastDate: target.lastDate };
      if (replay.authRequired) return { authRequired: true, target, week };

      let timetableStep = replay.steps.find((step) =>
        String(step.operation || "").includes("method10getTimetable")
      ) || null;
      let decoded = replay.ok && timetableStep
        ? decodeSquareEventsResponse(timetableStep.responseText, week)
        : null;

      const decodedCountMismatch = decoded?.ok &&
        Number.isInteger(decoded?.gwt?.expectedEventCount) &&
        Number.isInteger(decoded?.gwt?.detectedEventCount) &&
        decoded.gwt.expectedEventCount !== decoded.gwt.detectedEventCount;

      if ((!decoded?.ok || decodedCountMismatch) && !preferFullSequence) {
        const fullReplay = await replaySequenceInExistingTab(
          tab.id,
          built.sequence,
          profile.rpcTemplate.headers || {}
        );
        if (fullReplay.authRequired) return { authRequired: true, target, week };
        replay = fullReplay;
        timetableStep = fullReplay.steps.find((step) =>
          String(step.operation || "").includes("method10getTimetable")
        ) || null;
        decoded = fullReplay.ok && timetableStep
          ? decodeSquareEventsResponse(timetableStep.responseText, week)
          : null;
      }

      let weekResult;
      if (!decoded?.ok || !timetableStep) {
        weekResult = {
          offset: target.offset,
          week,
          ok: false,
          code: decoded?.code || (timetableStep ? "RPC_SEQUENCE_FAILED" : "NO_TIMETABLE_STEP"),
          decodeMessage: decoded?.message || null,
          decodeContext: decoded?.parseContext || null,
          parsePosition: decoded?.parsePosition ?? null,
          syncedAt: nowIso(),
          eventCount: 0,
          events: []
        };
      } else {
        const events = decoded.events.map(compactNormalizedEvent);
        weekResult = {
          offset: target.offset,
          week,
          ok: true,
          code: "WEEK_DECODED",
          decodeMessage: null,
          decodeContext: null,
          parsePosition: null,
          syncedAt: nowIso(),
          responseHash: timetableStep.responseHash,
          responseLength: timetableStep.responseLength,
          eventCount: events.length,
          expectedEventCount: decoded?.gwt?.expectedEventCount ?? null,
          detectedEventCount: decoded?.gwt?.detectedEventCount ?? null,
          events
        };
      }

      return { authRequired: false, target, week, weekResult };
    };

    let completed = 0;
    for (let startIndex = 0; startIndex < targets.length; startIndex += weekConcurrency) {
      const batchTargets = targets.slice(startIndex, startIndex + weekConcurrency);
      const results = await Promise.all(batchTargets.map((target) => syncOneTarget(target)));

      for (const result of results) {
        if (result?.weekResult) {
          map.set(result.target.firstDate, result.weekResult);
          completed += 1;
        }
      }

      const authResult = results.find((result) => result?.authRequired);
      const weeks = sortedCachedWeeks(map);
      const cache = {
        schemaVersion: 2,
        source: "unilim-ade",
        resourceId: profile.resourceId ?? null,
        academicYear: bounds?.academicYear || null,
        startDate: bounds?.startDate || null,
        endDate: bounds?.endDate || null,
        baseWeek,
        updatedAt: nowIso(),
        authRequired: Boolean(authResult),
        weeks,
        events: rebuildEventsFromWeeks(weeks),
        completedWeekCount: weeks.length
      };

      if (authResult) {
        await storeSet({
          academicSyncCache: cache,
          academicSyncStatus: {
            state: "auth_required",
            code: "AUTH_REQUIRED",
            mode: options.mode || "manual",
            finishedAt: nowIso(),
            completedWeeks: completed,
            requestedWeeks: targets.length,
            currentWeek: authResult.week,
            weekConcurrency
          }
        });
        return {
          ok: false,
          code: "AUTH_REQUIRED",
          message: "La session ADE a expiré. Les données déjà mises en cache sont conservées.",
          completedWeeks: completed,
          requestedWeeks: targets.length,
          cachedWeekCount: weeks.length,
          cachedEventCount: cache.events.length
        };
      }

      const lastResult = results[results.length - 1];
      await storeSet({
        academicSyncCache: cache,
        academicSyncStatus: {
          state: "running",
          mode: options.mode || "manual",
          statusLabel,
          startedAt,
          completedWeeks: completed,
          requestedWeeks: targets.length,
          currentWeek: lastResult?.week || null,
          weekConcurrency
        }
      });

      if (batchDelayMs > 0 && startIndex + weekConcurrency < targets.length) {
        await sleep(batchDelayMs);
      }
    }

    // Le premier passage reste rapide et parallèle. Seules les semaines qui
    // ont réellement échoué sont rejouées ensuite, séquentiellement, avec la
    // séquence GWT complète. On garde donc la vitesse normale tout en évitant
    // qu'un timeout/transitoire isolé transforme tout l'EDT en échec.
    for (let repairPass = 0; repairPass < 4; repairPass += 1) {
      const failedTargets = targets.filter((target) => !map.get(target.firstDate)?.ok);
      if (!failedTargets.length) break;

      for (const target of failedTargets) {
        await sleep(180 + repairPass * 260);
        const repaired = await syncOneTarget(target, true);

        if (repaired?.authRequired) {
          const repairWeeks = sortedCachedWeeks(map);
          const repairCache = {
            schemaVersion: 2,
            source: "unilim-ade",
            resourceId: profile.resourceId ?? null,
            academicYear: bounds?.academicYear || null,
            startDate: bounds?.startDate || null,
            endDate: bounds?.endDate || null,
            baseWeek,
            updatedAt: nowIso(),
            authRequired: true,
            weeks: repairWeeks,
            events: rebuildEventsFromWeeks(repairWeeks),
            completedWeekCount: repairWeeks.length
          };
          await storeSet({
            academicSyncCache: repairCache,
            academicSyncStatus: {
              state: "auth_required",
              code: "AUTH_REQUIRED",
              mode: options.mode || "manual",
              finishedAt: nowIso(),
              completedWeeks: completed,
              requestedWeeks: targets.length,
              currentWeek: repaired.week || null,
              weekConcurrency
            }
          });
          return {
            ok: false,
            code: "AUTH_REQUIRED",
            message: "La session ADE a expiré pendant le rattrapage des semaines en échec.",
            completedWeeks: completed,
            requestedWeeks: targets.length,
            cachedWeekCount: repairWeeks.length,
            cachedEventCount: repairCache.events.length
          };
        }

        if (repaired?.weekResult) {
          map.set(target.firstDate, repaired.weekResult);
        }
      }
    }

    const weeks = sortedCachedWeeks(map);
    const events = rebuildEventsFromWeeks(weeks);
    const failureInfo = collectorFailedWeekSummary(targets, map);
    const successCount = targets.length - failureInfo.failedWeekCount;

    const cache = {
      schemaVersion: 2,
      source: "unilim-ade",
      resourceId: profile.resourceId ?? null,
      academicYear: bounds?.academicYear || null,
      startDate: bounds?.startDate || null,
      endDate: bounds?.endDate || null,
      baseWeek,
      updatedAt: nowIso(),
      finishedAt: nowIso(),
      authRequired: false,
      weeks,
      events,
      completedWeekCount: weeks.length,
      lastSyncMode: options.mode || "manual"
    };

    await storeSet({
      academicSyncCache: cache,
      academicSyncStatus: {
        state: "finished",
        mode: options.mode || "manual",
        finishedAt: nowIso(),
        ok: successCount === targets.length,
        code: successCount === targets.length ? "ACADEMIC_TARGET_SYNC_OK" : "ACADEMIC_TARGET_SYNC_PARTIAL",
        completedWeeks: completed,
        requestedWeeks: targets.length,
        weekConcurrency
      }
    });

    return {
      ok: successCount === targets.length,
      code: successCount === targets.length ? "ACADEMIC_TARGET_SYNC_OK" : "ACADEMIC_TARGET_SYNC_PARTIAL",
      message: failureInfo.failedWeekCount
        ? `${failureInfo.failedWeekCount} semaine(s) en échec après rattrapage : ${failureInfo.failedWeekSummary || "cause inconnue"}`
        : null,
      mode: options.mode || "manual",
      academicYear: bounds?.academicYear || null,
      requestedWeeks: targets.length,
      successCount,
      failedWeekCount: failureInfo.failedWeekCount,
      failedWeekSummary: failureInfo.failedWeekSummary,
      failedWeeks: failureInfo.failedWeeks,
      cachedWeekCount: weeks.length,
      cachedEventCount: events.length,
      firstTarget: targets[0] || null,
      lastTarget: targets[targets.length - 1] || null,
      weekConcurrency
    };
  } finally {
    if (ownsTab && tab?.id) {
      try { await chrome.tabs.remove(tab.id); } catch {}
    }
  }
}

async function syncFullAcademicYear(options = {}) {
  const data = await storeGet(["weekTraces"]);
  const traces = Array.isArray(data.weekTraces) ? data.weekTraces : [];
  if (traces.length < 2) {
    return { ok: false, code: "NEED_TWO_REAL_TRACES", message: "Il faut conserver au moins deux vraies transitions ADE." };
  }
  const baseWeek = traces[traces.length - 1]?.afterWeek;
  const bounds = academicYearBoundsForWeek(baseWeek);
  if (!bounds) return { ok: false, code: "ACADEMIC_BOUNDS_UNKNOWN" };
  const targets = weeklyTargetsForRange(baseWeek, bounds.startDate, bounds.endDate);
  return await syncTargetsIntoAcademicCache(targets, {
    mode: "full-academic-year",
    statusLabel: "Année universitaire complète",
    delayMs: options.delayMs ?? 180,
    weekConcurrency: options.weekConcurrency ?? 1,
    tabId:
      options.tabId,
    forceFullSequence: options.forceFullSequence === true
  });
}

function currentIsoDate() {
  return new Date().toISOString().slice(0, 10);
}

async function smartAcademicRefresh(options = {}) {
  const data = await storeGet(["weekTraces"]);
  const traces = Array.isArray(data.weekTraces) ? data.weekTraces : [];
  if (traces.length < 2) return { ok: false, code: "NEED_TWO_REAL_TRACES" };
  const baseWeek = traces[traces.length - 1]?.afterWeek;
  const bounds = academicYearBoundsForWeek(baseWeek);
  if (!bounds) return { ok: false, code: "ACADEMIC_BOUNDS_UNKNOWN" };

  let center = mondayOnOrBeforeIso(currentIsoDate());
  if (center < bounds.startDate) center = bounds.startDate;
  if (center > bounds.endDate) center = addDaysIso(bounds.endDate, -6);

  let start = addDaysIso(center, -7);
  let end = addDaysIso(center, 7 * 12 + 6);
  if (start < bounds.startDate) start = bounds.startDate;
  if (end > bounds.endDate) end = bounds.endDate;

  const targets = weeklyTargetsForRange(baseWeek, start, end);
  return await syncTargetsIntoAcademicCache(targets, {
    mode: "smart-auto-refresh",
    statusLabel: "Rafraîchissement automatique",
    delayMs: 140,
    tabId:
      options.tabId
  });
}

async function academicYearCacheSummary() {
  const data = await storeGet(["academicSyncCache", "academicSyncStatus"]);
  const cache = data.academicSyncCache;
  if (!cache) {
    return { ok: false, code: "NO_ACADEMIC_SYNC_CACHE", message: "Aucun cache académique n'est disponible." };
  }
  const weeks = cache.weeks || [];
  const nonEmptyWeeks = weeks.filter((week) => Number(week.eventCount) > 0);
  const emptyWeeks = weeks.filter((week) => week.ok && Number(week.eventCount) === 0);
  const failedWeeks = weeks.filter((week) => !week.ok);
  return {
    ok: true,
    code: "ACADEMIC_YEAR_CACHE_SUMMARY",
    status: data.academicSyncStatus || null,
    academicYear: cache.academicYear || null,
    startDate: cache.startDate || null,
    endDate: cache.endDate || null,
    resourceId: cache.resourceId ?? null,
    cachedWeekCount: weeks.length,
    nonEmptyWeekCount: nonEmptyWeeks.length,
    emptyWeekCount: emptyWeeks.length,
    failedWeekCount: failedWeeks.length,
    eventCount: Array.isArray(cache.events) ? cache.events.length : 0,
    authRequired: Boolean(cache.authRequired),
    lastUpdatedAt: cache.updatedAt || null,
    firstCachedWeek: weeks[0]?.week || null,
    lastCachedWeek: weeks[weeks.length - 1]?.week || null,
    nonEmptyWeeks: nonEmptyWeeks.map((week) => ({
      week: week.week,
      eventCount: week.eventCount,
      responseHash: week.responseHash
    })),
    failedWeeks: failedWeeks.map((week) => ({
      week: week.week,
      code: week.code,
      message: week.decodeMessage || null,
      parsePosition: week.parsePosition ?? null,
      context: week.decodeContext || null
    }))
  };
}

async function academicYearPlanilimPayload() {
  const data = await storeGet(["academicSyncCache", "savedProfile"]);
  const cache = data.academicSyncCache;
  if (!cache) {
    return { ok: false, code: "NO_ACADEMIC_SYNC_CACHE", message: "Synchronise d'abord l'année universitaire." };
  }
  const events = deduplicateEvents(cache.events || []).sort((a, b) => {
    const date = String(a.date || "").localeCompare(String(b.date || ""));
    return date || String(a.start || "").localeCompare(String(b.start || ""));
  });
  return {
    ok: true,
    code: "PLANILIM_ACADEMIC_YEAR_PAYLOAD_READY",
    payload: {
      schemaVersion: 2,
      source: "unilim-ade",
      generatedAt: nowIso(),
      academicYear: cache.academicYear || null,
      resource: {
        id: data.savedProfile?.resourceId ?? cache.resourceId ?? null,
        label: data.savedProfile?.planningLabel || null,
        path: data.savedProfile?.planningPath || null
      },
      syncRange: { firstDate: cache.startDate || null, lastDate: cache.endDate || null },
      weekCount: cache.weeks?.length || 0,
      eventCount: events.length,
      events
    }
  };
}

async function calibrateLatestRealWeek() {
  const data =
    await storeGet([
      "weekTraces",
      "generatedWeekBatch",
      "savedProfile"
    ]);

  const traces =
    Array.isArray(
      data.weekTraces
    )
      ? data.weekTraces
      : [];

  if (!traces.length) {
    return {
      ok: false,
      code: "NO_REAL_WEEK_TRACE",
      message:
        "Il faut d'abord enregistrer une vraie transition de semaine avec les boutons 4 et 5."
    };
  }

  const latestTrace =
    traces[traces.length - 1];

  const actualRequest =
    findOperationEntry(
      latestTrace,
      "method10getTimetable"
    );

  if (!actualRequest?.body) {
    return {
      ok: false,
      code: "REAL_TIMETABLE_REQUEST_MISSING",
      message:
        "La dernière trace ne contient pas getTimetable."
    };
  }

  const parsedActual =
    parseGwtRequestBody(
      actualRequest.body
    );

  if (!parsedActual.ok) {
    return {
      ok: false,
      code: "REAL_GWT_PARSE_FAILED",
      message:
        "Impossible de décoder la vraie requête getTimetable."
    };
  }

  // Index candidat découvert pendant les tests précédents.
  const candidatePayloadIndex = 42;

  const actualCandidateValue =
    parsedActual.payload[
      candidatePayloadIndex
    ] ?? null;

  const batch =
    data.generatedWeekBatch;

  const predictedWeeks =
    Array.isArray(batch?.weeks)
      ? batch.weeks
      : [];

  let predicted =
    predictedWeeks.find(
      (week) =>
        String(
          week.parameterValue
        ) ===
        String(
          actualCandidateValue
        )
    ) || null;

  // Fallback : si les dates sont connues côté trace et côté batch.
  if (!predicted) {
    predicted =
      predictedWeeks.find(
        (week) =>
          week?.week?.firstDate &&
          latestTrace?.afterWeek?.firstDate &&
          week.week.firstDate ===
            latestTrace.afterWeek.firstDate
      ) || null;
  }

  const profile =
    data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code: "NO_PROFILE",
      message:
        "Le profil RPC n'est plus disponible."
    };
  }

  let testTab = null;

  try {
    testTab =
      await openFreshAde();

    const template = {
      method:
        actualRequest.method ||
        profile.rpcTemplate.method ||
        "POST",
      url:
        actualRequest.url ||
        profile.rpcTemplate.url,
      headers:
        profile.rpcTemplate.headers || {},
      body:
        actualRequest.body
    };

    const actualReplay =
      await replayInPage(
        testTab.id,
        template
      );

    const actualResponse =
      String(
        actualReplay?.responseText ||
        ""
      );

    const actualRequestHash =
      await sha256Text(
        actualRequest.body
      );

    const actualResponseHash =
      await sha256Text(
        actualResponse
      );

    let predictedRequestHash =
      null;

    let predictedResponseHash =
      null;

    let requestBodiesIdentical =
      false;

    let responseBodiesIdentical =
      false;

    let requestDiff =
      null;

    if (predicted) {
      predictedRequestHash =
        await sha256Text(
          predicted.requestBody || ""
        );

      predictedResponseHash =
        await sha256Text(
          predicted.rawResponse || ""
        );

      requestBodiesIdentical =
        String(
          predicted.requestBody || ""
        ) ===
        String(
          actualRequest.body || ""
        );

      responseBodiesIdentical =
        String(
          predicted.rawResponse || ""
        ) ===
        actualResponse;

      requestDiff =
        exactPayloadChanges(
          predicted.requestBody || "",
          actualRequest.body || ""
        );
    }

    const result = {
      ok: true,
      code:
        "REAL_WEEK_CALIBRATION_READY",
      message:
        predicted
          ? (
              requestBodiesIdentical
                ? "La requête générée pour cette valeur est EXACTEMENT identique à la vraie requête ADE."
                : "La vraie requête ADE diffère de notre requête générée : le diagnostic indique où."
            )
          : "La vraie requête est décodée, mais aucune requête générée correspondante n'a été trouvée dans le lot précédent.",
      realTransition: {
        beforeWeek:
          latestTrace.beforeWeek ||
          null,
        afterWeek:
          latestTrace.afterWeek ||
          null,
        requestCount:
          latestTrace.requestCount ||
          0
      },
      candidate: {
        payloadIndex:
          candidatePayloadIndex,
        actualValue:
          actualCandidateValue
      },
      actual: {
        requestBodyLength:
          String(
            actualRequest.body || ""
          ).length,
        requestHash:
          actualRequestHash,
        httpStatus:
          actualReplay?.httpStatus ??
          null,
        gwtOk:
          actualResponse
            .trimStart()
            .startsWith("//OK"),
        responseLength:
          actualResponse.length,
        responseHash:
          actualResponseHash,
        responseTitles:
          likelyCourseTitles(
            actualResponse
          ),
        responseTimes:
          analyzeGwtResponse(
            actualResponse
          ).timeLikeStrings || []
      },
      predicted: predicted
        ? {
            parameterValue:
              predicted.parameterValue,
            week:
              predicted.week || null,
            requestHash:
              predictedRequestHash,
            responseHash:
              predictedResponseHash,
            responseLength:
              String(
                predicted.rawResponse || ""
              ).length,
            requestBodiesIdentical,
            responseBodiesIdentical,
            requestDiff
          }
        : null,
      conclusion:
        predicted
          ? (
              requestBodiesIdentical
                ? (
                    responseBodiesIdentical
                      ? "PREDICTION_REQUEST_AND_RESPONSE_MATCH_REAL_ADE"
                      : "REQUEST_MATCHES_BUT_RESPONSE_DIFFERS"
                  )
                : "PREDICTED_REQUEST_DOES_NOT_MATCH_REAL_ADE"
            )
          : "NO_PREDICTED_REQUEST_TO_COMPARE"
    };

    await storeSet({
      lastRealWeekCalibration: {
        testedAt: nowIso(),
        ...result
      }
    });

    return result;
  } finally {
    if (testTab?.id) {
      try {
        await chrome.tabs.remove(
          testTab.id
        );
      } catch {}
    }
  }
}

async function batchFingerprintReport() {
  const data =
    await storeGet([
      "generatedWeekBatch"
    ]);

  const weeks =
    Array.isArray(
      data.generatedWeekBatch?.weeks
    )
      ? data.generatedWeekBatch.weeks
      : [];

  if (!weeks.length) {
    return {
      ok: false,
      code: "NO_WEEK_BATCH",
      message:
        "Aucun lot généré à analyser."
    };
  }

  const rows = [];

  for (const week of weeks) {
    rows.push({
      parameterValue:
        week.parameterValue,
      week:
        week.week || null,
      requestHash:
        await sha256Text(
          week.requestBody || ""
        ),
      responseHash:
        await sha256Text(
          week.rawResponse || ""
        ),
      responseLength:
        String(
          week.rawResponse || ""
        ).length,
      titles:
        week.titles || [],
      timeLikeStrings:
        week.timeLikeStrings || []
    });
  }

  const distinctRequestHashes =
    new Set(
      rows.map(
        (row) => row.requestHash
      )
    );

  const distinctResponseHashes =
    new Set(
      rows.map(
        (row) => row.responseHash
      )
    );

  return {
    ok: true,
    code: "BATCH_FINGERPRINT_REPORT",
    requestCount:
      rows.length,
    distinctRequestCount:
      distinctRequestHashes.size,
    distinctResponseCount:
      distinctResponseHashes.size,
    allResponsesIdentical:
      distinctResponseHashes.size === 1,
    rows
  };
}

async function validatePredictedWeekAgainstVisible() {
  const data = await storeGet([
    "predictedNextWeek"
  ]);

  const prediction =
    data.predictedNextWeek;

  if (
    !prediction?.ok ||
    !prediction?.responseText
  ) {
    return {
      ok: false,
      code: "NO_PREDICTION_TO_VALIDATE",
      message:
        "Lance d'abord le test de semaine suivante sans clic."
    };
  }

  const tab =
    await bestAdeTab();

  if (!tab) {
    return {
      ok: false,
      code: "ADE_NOT_OPEN",
      message:
        "Ouvre ADE sur la semaine prédite avant de valider."
    };
  }

  const visible =
    await scrapeVisibleWeek(
      tab.id
    );

  if (
    !visible?.ok ||
    !visible.events?.length
  ) {
    return {
      ok: false,
      code: "VISIBLE_WEEK_NOT_READABLE",
      message:
        "La semaine actuellement affichée dans ADE n'est pas lisible.",
      visibleWeek:
        visible?.week || null
    };
  }

  const evidence =
    evidenceAgainstSample(
      prediction.responseText,
      visible.events
    );

  const expected =
    prediction.predictedWeek;

  const sameWeek =
    Boolean(
      expected?.firstDate &&
      visible?.week?.firstDate &&
      expected.firstDate ===
        visible.week.firstDate &&
      expected.lastDate ===
        visible.week.lastDate
    );

  const goodMatch =
    evidence.checkedEvents > 0 &&
    evidence.score >= 0.8;

  const ok =
    sameWeek &&
    goodMatch;

  const result = {
    ok,
    code: ok
      ? "PREDICTED_WEEK_CONFIRMED"
      : "PREDICTED_WEEK_MISMATCH",
    message: ok
      ? "Validation réussie : la semaine générée sans clic correspond à la semaine réellement affichée dans ADE."
      : "La prédiction ne correspond pas encore suffisamment à la semaine affichée.",
    expectedWeek:
      expected || null,
    visibleWeek:
      visible.week || null,
    visibleEventCount:
      visible.events.length,
    evidence,
    detectedParameter:
      prediction.detectedParameter || null
  };

  await storeSet({
    lastPredictedWeekValidation: {
      testedAt: nowIso(),
      ...result
    }
  });

  return result;
}

async function semanticWeekAnalysis() {
  const data = await storeGet([
    "weekTraces"
  ]);

  const traces = Array.isArray(data.weekTraces)
    ? data.weekTraces
    : [];

  if (traces.length < 2) {
    return {
      ok: false,
      code: "NEED_TWO_TRACES",
      message:
        "Il faut au minimum deux traces de changement de semaine."
    };
  }

  const comparisons = [];

  for (let index = 1; index < traces.length; index += 1) {
    const left = traces[index - 1];
    const right = traces[index];

    const requestComparisons =
      compareTraceSemantically(
        left,
        right
      );

    comparisons.push({
      pairIndex: index - 1,
      left: {
        beforeWeek: left.beforeWeek,
        afterWeek: left.afterWeek,
        requestCount: left.requestCount
      },
      right: {
        beforeWeek: right.beforeWeek,
        afterWeek: right.afterWeek,
        requestCount: right.requestCount
      },
      requestComparisons,
      changeCandidates:
        extractStableChangeCandidates(
          requestComparisons
        )
    });
  }

  const latest = comparisons[
    comparisons.length - 1
  ];

  const timetableComparison =
    latest?.requestComparisons?.find(
      (item) =>
        item.operation.includes(
          "method10getTimetable"
        )
    ) || null;

  return {
    ok: true,
    generatedAt: nowIso(),
    traceCount: traces.length,
    comparisons,
    latestTimetableSemanticDiff:
      timetableComparison,
    nextGoal:
      "Identifier une ou quelques valeurs qui évoluent avec S38/S39/S40, puis tester leur modification sur un RPC getTimetable rejoué."
  };
}

async function weekTraceDiagnostics() {
  const data = await storeGet([
    "weekTraceActive",
    "weekTraceBeforeWeek",
    "weekTraceEntries",
    "weekTraces"
  ]);

  const traces = Array.isArray(data.weekTraces)
    ? data.weekTraces
    : [];

  const lastTwo = traces.slice(-2);

  return {
    ok: true,
    active: Boolean(data.weekTraceActive),
    activeBeforeWeek: data.weekTraceBeforeWeek || null,
    activeRequestCount: Array.isArray(data.weekTraceEntries)
      ? data.weekTraceEntries.length
      : 0,
    savedTraceCount: traces.length,
    traces: traces.map(summarizeTrace),
    lastTwoComparison:
      lastTwo.length === 2
        ? {
            first: summarizeTrace(lastTwo[0]),
            second: summarizeTrace(lastTwo[1]),
            requestComparisons: compareTraces(lastTwo[0], lastTwo[1])
          }
        : null
  };
}

async function adeTabs() {
  return await chrome.tabs.query({
    url: ["https://planning.unilim.fr/*"]
  });
}

async function bestAdeTab() {
  const tabs = await adeTabs();

  return (
    tabs.find(
      (tab) =>
        tab.url?.includes("/direct/myplanning.jsp")
    ) ||
    tabs[0] ||
    null
  );
}

async function planningFrameMessage(tabId, message) {
  await v3EnsureCurrentContentScript(tabId);

  let frames = [];
  try {
    frames = await chrome.webNavigation.getAllFrames({ tabId }) || [];
  } catch {}
  if (!frames.length) frames = [{ frameId: 0, url: "" }];

  const results = [];
  for (const frame of frames) {
    try {
      const result = await chrome.tabs.sendMessage(
        tabId,
        message,
        { frameId: frame.frameId }
      );
      if (!result) continue;
      results.push({
        ...result,
        frameId: frame.frameId,
        frameUrl: frame.url || ""
      });
    } catch {}
  }

  results.sort((left, right) => {
    const score = (item) =>
      (item?.ok ? 100000 : 0) +
      Number(item?.rowCount || item?.tree?.rowCount || 0) * 100 +
      (String(item?.frameUrl || "").includes("/direct/myplanning.jsp") ? 500 : 0);
    return score(right) - score(left);
  });

  return results[0] || {
    ok: false,
    code: "ADE_TREE_MESSAGE_UNAVAILABLE"
  };
}

async function collectorTreeSnapshot() {
  const tab = await bestAdeTab();
  if (!tab?.id) {
    return {
      ok: false,
      code: "ADE_NOT_OPEN",
      message: "Ouvrez ADE et connectez-vous pour afficher les formations."
    };
  }

  const authenticated = await v3TabLooksAuthenticated(tab.id);
  if (!authenticated) {
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
    return {
      ok: false,
      code: "AUTH_REQUIRED",
      tabId: tab.id,
      message: "Connectez-vous à ADE, puis relancez la détection."
    };
  }

  const snapshot = await planningFrameMessage(tab.id, {
    type: "PLANILIM_ADE_TREE_SCAN"
  });
  return { ...snapshot, tabId: tab.id };
}

async function collectorExpandAndScan(message = {}) {
  const tab = await bestAdeTab();
  if (!tab?.id) return { ok: false, code: "ADE_NOT_OPEN" };
  const authenticated = await v3TabLooksAuthenticated(tab.id);
  if (!authenticated) {
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
    return { ok: false, code: "AUTH_REQUIRED", tabId: tab.id };
  }
  // ADE/GXT ne traite pas toujours les événements d'ouverture de son arbre
  // quand l'onglet est masqué. Le garder au premier plan rend le parcours
  // identique au clic utilisateur qui fonctionne dans Brave.
  await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
  await sleep(250);
  const result = await planningFrameMessage(tab.id, {
    type: "PLANILIM_ADE_EXPAND_AND_SCAN",
    options: {
      maxBranches: Math.max(1, Math.min(300, Number(message.maxBranches) || 200)),
      maxDurationMs: Math.max(5000, Math.min(60000, Number(message.maxDurationMs) || 45000)),
      maxDepth: Math.max(1, Math.min(4, Number(message.maxDepth) || 4)),
      scopeRoot: message.scopeRoot || "Groupes Etudiants",
      scopePath: message.scopePath || COLLECTOR_DEFAULT_SCOPE_PATH
    }
  });
  return { ...result, tabId: tab.id };
}

async function collectorSelectResource(tabId, target) {
  const selected = await planningFrameMessage(tabId, {
    type: "PLANILIM_ADE_SELECT_RESOURCE",
    target
  });

  return selected;
}

async function collectorToggleBranch(message = {}) {
  const tab = await bestAdeTab();
  if (!tab?.id) return { ok: false, code: "ADE_NOT_OPEN" };
  return await planningFrameMessage(tab.id, {
    type: "PLANILIM_ADE_TOGGLE_BRANCH",
    target: message.target || message
  });
}


async function collectorEnsureAdeInteractive(tabId) {
  if (!Number.isInteger(tabId)) return false;
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return false;
  if (tab.active) return true;
  try {
    await chrome.tabs.update(tabId, { active: true });
    await sleep(80);
  } catch {}
  return true;
}

async function collectorWaitForResourceSelection(tabId, resourceId, timeoutMs = 14000) {
  const startedAt = Date.now();
  let lastPreview = null;

  while (Date.now() - startedAt < timeoutMs) {
    lastPreview = await v3ScrapePlanningPreview(tabId).catch(() => null);
    const previewResourceId = Number(
      lastPreview?.resourceId ??
      lastPreview?.planningResource?.resourceId ??
      NaN
    );

    const data = await storeGet(["latestTimetableRequest"]);
    const capture = data.latestTimetableRequest || null;
    const captureMatches =
      capture?.tabId === tabId &&
      Number(capture?.resourceId) === Number(resourceId) &&
      Number(capture?.capturedAt || 0) >= startedAt - 1500;

    if (previewResourceId === Number(resourceId) || captureMatches) {
      return {
        ok: true,
        code: "COLLECTOR_RESOURCE_READY",
        preview: lastPreview,
        captureMatches
      };
    }

    await sleep(320);
  }

  return {
    ok: false,
    code: "COLLECTOR_RESOURCE_NOT_READY",
    message: "ADE n'a pas encore confirmé le chargement de cet emploi du temps.",
    preview: lastPreview
  };
}

async function collectorMoveToAcademicStart(tabId) {
  let preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
  let week = preview?.week || null;
  const bounds = academicYearBoundsForWeek(week);

  if (!bounds?.startDate || !week?.firstDate) {
    return {
      ok: false,
      code: "COLLECTOR_START_WEEK_UNKNOWN",
      preview
    };
  }

  let steps = 0;
  const maxSteps = 46;

  while (week.firstDate > bounds.startDate && steps < maxSteps) {
    await collectorEnsureAdeInteractive(tabId);
    const kicked = await v3KickWeekInBestFrame(tabId, "previous");
    if (!kicked?.ok) {
      return {
        ok: false,
        code: kicked?.code || "COLLECTOR_PREVIOUS_WEEK_UNAVAILABLE",
        steps,
        week,
        bounds,
        kick: kicked
      };
    }

    steps += 1;
    await sleep(650);
    preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
    const nextWeek = preview?.week || null;

    if (!nextWeek?.firstDate || nextWeek.firstDate >= week.firstDate) {
      await sleep(450);
      preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
    }

    week = preview?.week || week;
  }

  return {
    ok: Boolean(week?.firstDate && week.firstDate <= bounds.startDate),
    code: week?.firstDate && week.firstDate <= bounds.startDate
      ? "COLLECTOR_AT_ACADEMIC_START"
      : "COLLECTOR_ACADEMIC_START_NOT_REACHED",
    steps,
    week,
    bounds
  };
}

function isoWeekNumber(isoDate) {
  const clean = isoDateOnly(isoDate);
  if (!clean) return null;
  const date = new Date(`${clean}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) return null;
  const day = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1, 12));
  return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
}

async function collectorWaitFreshTimetableCapture(tabId, resourceId, sinceAt = 0, timeoutMs = 3500) {
  const started = Date.now();
  const key = `${Number(tabId)}:${Number(resourceId)}`;
  const minCapturedAt = Number(sinceAt || 0) - 800;
  let storageCheckedAt = 0;

  while (Date.now() - started < timeoutMs) {
    const memoryCapture = collectorRecentTimetableCaptures.get(key) || null;
    if (
      memoryCapture?.tabId === tabId &&
      Number(memoryCapture?.resourceId) === Number(resourceId) &&
      Number(memoryCapture?.capturedAt || 0) >= minCapturedAt
    ) {
      return memoryCapture;
    }

    // Le cache mémoire reçoit la requête dès onBeforeSendHeaders. Le stockage
    // n'est qu'un filet de sécurité si le service worker vient d'être réveillé.
    if (Date.now() - storageCheckedAt >= 450) {
      storageCheckedAt = Date.now();
      const data = await storeGet(["latestTimetableRequest"]);
      const capture = data.latestTimetableRequest || null;
      if (
        capture?.tabId === tabId &&
        Number(capture?.resourceId) === Number(resourceId) &&
        Number(capture?.capturedAt || 0) >= minCapturedAt
      ) {
        collectorRecentTimetableCaptures.set(key, capture);
        return capture;
      }
    }

    await sleep(60);
  }
  return null;
}

async function collectorWaitFreshLiteralTimetableCapture(
  tabId,
  resourceId,
  expectedWeekValue = null,
  sinceAt = 0,
  timeoutMs = 6500
) {
  const started = Date.now();
  const key = `${Number(tabId)}:${Number(resourceId)}`;
  const minCapturedAt = Number(sinceAt || 0) - 100;
  let storageCheckedAt = 0;

  const matchesLiteral = (capture) => {
    if (!capture?.body || !capture?.url) return false;
    if (Number(capture?.tabId) !== Number(tabId)) return false;
    if (Number(capture?.resourceId) !== Number(resourceId)) return false;

    const capturedAt = Number(capture?.capturedAt || 0);
    if (capturedAt && capturedAt < minCapturedAt) return false;

    const parsed = collectorTimetableWeekValue(capture.body);
    if (!parsed?.ok || parsed.encoding !== "literal") return false;
    if (
      Number.isFinite(Number(expectedWeekValue)) &&
      Number(parsed.value) !== Number(expectedWeekValue)
    ) {
      return false;
    }
    return true;
  };

  while (Date.now() - started < timeoutMs) {
    const memoryCapture = collectorRecentTimetableCaptures.get(key) || null;
    if (matchesLiteral(memoryCapture)) return memoryCapture;

    // Après un changement de semaine, ADE peut émettre d'abord l'ancien body
    // (back-reference), puis le vrai getTimetable littéral quelques centaines
    // de millisecondes plus tard. Ne jamais retourner le premier body seulement
    // parce qu'il est "récent" : c'était le dernier faux échec de la 4.6.2.
    if (Date.now() - storageCheckedAt >= 180) {
      storageCheckedAt = Date.now();
      const data = await storeGet(["latestTimetableRequest", "timetableRequestHistory"]);
      const latest = data.latestTimetableRequest || null;
      if (matchesLiteral(latest)) {
        collectorRecentTimetableCaptures.set(key, latest);
        return latest;
      }

      const history = Array.isArray(data.timetableRequestHistory)
        ? data.timetableRequestHistory
        : [];
      for (let index = history.length - 1; index >= 0 && index >= history.length - 12; index -= 1) {
        const candidate = history[index];
        if (!matchesLiteral(candidate)) continue;
        collectorRecentTimetableCaptures.set(key, candidate);
        return candidate;
      }
    }

    await sleep(70);
  }

  return null;
}

async function collectorCaptureVisibleWeekRpc(tabId, resourceId, preview, sinceAt = 0) {
  const week = preview?.week || null;
  if (!week?.firstDate || !week?.lastDate) return null;
  const capture = await collectorWaitFreshTimetableCapture(tabId, resourceId, sinceAt);
  if (!capture?.body || !capture?.url) return null;
  const replay = await replayInPage(tabId, requestTemplateFromCapture(capture));
  const responseText = String(replay?.responseText || "");
  if (looksLikeAuthenticationPage(responseText, replay?.httpStatus)) {
    return { authRequired: true };
  }
  const decoded = decodeSquareEventsResponse(responseText, week);
  if (!decoded?.ok) return null;
  const events = decoded.events.map(compactNormalizedEvent);

  // Une seule réponse réussie suffit comme référence de comparaison dans le
  // fichier de diagnostic. Elle permet de comparer un cas normal à un cas
  // ambigu sans alourdir le stockage local.
  await saveCollectorSuccessReference({
    type: "collector-week-success",
    code: "COLLECTOR_WEEK_SUCCESS_REFERENCE",
    resourceId: model?.resourceId ?? null,
    label: model?.label || null,
    path: model?.path || null,
    week,
    request: item
      ? {
          operation: item.operation || null,
          url: item.url || null,
          targetValue: item.targetValue ?? null,
          bodyLength: String(item.body || "").length,
          body: diagnosticText(item.body || "", 220000),
          parse: parseGwtRequestBody(item.body || "")
        }
      : null,
    responseLength: responseText.length,
    responseAnalysis: analyzeGwtResponse(responseText),
    responseText: diagnosticText(responseText, 700000),
    decoded: {
      ok: true,
      expectedEventCount: decoded?.gwt?.expectedEventCount ?? null,
      detectedEventCount: decoded?.gwt?.detectedEventCount ?? null,
      eventCount: events.length,
      sampleEvents: events.slice(0, 12)
    }
  });

  return {
    offset: null,
    week: { firstDate: week.firstDate, lastDate: week.lastDate },
    ok: true,
    code: "WEEK_DECODED_FROM_REAL_NAVIGATION",
    syncedAt: nowIso(),
    responseHash: await sha256Text(responseText),
    responseLength: responseText.length,
    eventCount: events.length,
    expectedEventCount: decoded?.gwt?.expectedEventCount ?? null,
    detectedEventCount: decoded?.gwt?.detectedEventCount ?? null,
    events
  };
}

async function collectorCaptureLeadingWeeks(tabId, resourceId) {
  const moved = await collectorMoveToAcademicStart(tabId);
  if (!moved?.ok) return { ok: false, weeks: [], move: moved };

  const weeks = [];
  let preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
  for (let index = 0; index < 4; index += 1) {
    const weekNo = isoWeekNumber(preview?.week?.firstDate);
    if (!Number.isFinite(weekNo) || weekNo >= 38) break;

    // Les semaines de rentrée sont précisément celles qui ont posé problème
    // au décodeur GWT. Ici la page ADE vient d'être réellement affichée : le
    // DOM est donc notre source de vérité, complétée par le RPC lorsqu'il est
    // lui aussi exploitable.
    const scraped = weekResultFromScrapedPreview(preview);
    const rpc = await collectorCaptureVisibleWeekRpc(
      tabId,
      resourceId,
      preview,
      Date.now() - 5000
    );
    if (rpc?.authRequired) return { ok: false, authRequired: true, weeks };

    if (scraped || rpc?.ok) {
      const events = mergeNormalizedEventLists(
        scraped?.events || [],
        rpc?.events || []
      );
      weeks.push({
        ...(rpc?.ok ? rpc : scraped),
        week: scraped?.week || rpc?.week,
        ok: true,
        code: rpc?.ok ? "WEEK_REAL_NAVIGATION_MERGED" : "WEEK_SCRAPED_FROM_REAL_NAVIGATION",
        eventCount: events.length,
        events
      });
    }

    const kickedAt = Date.now();
    await collectorEnsureAdeInteractive(tabId);
    const kick = await v3KickWeekInBestFrame(tabId, "next");
    if (!kick?.ok) break;
    await sleep(700);
    preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
    await collectorWaitFreshTimetableCapture(tabId, resourceId, kickedAt, 5000);
  }

  return { ok: true, weeks };
}

async function collectorMergeWeekOverrides(weekResults) {
  if (!Array.isArray(weekResults) || !weekResults.length) return;
  const data = await storeGet(["academicSyncCache"]);
  const cache = data.academicSyncCache || null;
  if (!cache) return;
  const map = weekCacheMap(cache.weeks || []);

  for (const result of weekResults) {
    const firstDate = result?.week?.firstDate;
    if (!firstDate) continue;

    const existing = map.get(firstDate) || null;
    if (existing?.ok && result?.ok) {
      // Le DOM visible et le RPC se complètent. Certains SquareEvent ADE sont
      // techniquement décodables mais perdent un champ de géométrie/heure ; ils
      // passent alors le contrôle de comptage tout en devenant invisibles côté
      // Planilim. On fusionne les deux sources au lieu de remplacer l'une par
      // l'autre, ce qui conserve le RPC annuel et récupère les cours visibles.
      const events = mergeNormalizedEventLists(existing.events || [], result.events || []);
      map.set(firstDate, {
        ...existing,
        ...result,
        ok: true,
        code: "WEEK_RPC_AND_VISIBLE_DOM_MERGED",
        responseHash: existing.responseHash || result.responseHash || null,
        responseLength: existing.responseLength || result.responseLength || null,
        expectedEventCount: existing.expectedEventCount ?? result.expectedEventCount ?? null,
        detectedEventCount: existing.detectedEventCount ?? result.detectedEventCount ?? null,
        eventCount: events.length,
        events
      });
      continue;
    }

    map.set(firstDate, result);
  }

  const weeks = sortedCachedWeeks(map);
  await storeSet({
    academicSyncCache: {
      ...cache,
      weeks,
      events: rebuildEventsFromWeeks(weeks),
      completedWeekCount: weeks.length,
      updatedAt: nowIso()
    }
  });
}



const COLLECTOR_MODEL_STORAGE_KEY = "collectorPreparedModels";
const COLLECTOR_PIPELINE_STORAGE_KEY = "collectorPipelineRuntime";
const COLLECTOR_RESOURCE_CONCURRENCY_DEFAULT = 1;
const COLLECTOR_WEEK_CONCURRENCY_DEFAULT = 8;

function collectorTimetableWeekValue(body) {
  const timetable = parseCollectorTimetableRequestBody(body);
  if (!timetable?.ok) {
    return {
      ok: false,
      code: timetable?.code || "COLLECTOR_GWT_PARSE_FAILED"
    };
  }

  return {
    ok: true,
    code: timetable.code,
    index: timetable.weekValueIndex ?? timetable.weekEncodingIndex,
    value: timetable.weekValue,
    resourceId: timetable.resourceId,
    encoding: timetable.weekEncoding,
    encodingIndex: timetable.weekEncodingIndex,
    encodingLength: timetable.weekEncodingLength,
    backReference: timetable.weekBackReference ?? null
  };
}

async function collectorCanonicalizeTimetableCapture(tabId, target, capture, weekValue) {
  if (!capture?.body || !capture?.url || !weekValue?.ok) {
    return { ok: false, code: weekValue?.code || "COLLECTOR_MODEL_CAPTURE_FAILED" };
  }

  let preview = await v3ScrapePlanningPreview(tabId).catch(() => null);

  // Une requête contenant déjà un Integer littéral peut être modifiée sans
  // changer la table d'objets GWT : seul le nombre de semaine change.
  if (weekValue.encoding === "literal") {
    return { ok: true, code: "COLLECTOR_LITERAL_TEMPLATE_READY", capture, weekValue, preview };
  }

  // Les semaines 0..6 sont souvent sérialisées par GWT sous forme de
  // back-reference (-3..-9). Remplacer cette back-reference par un nouvel
  // objet Integer change la numérotation des objets qui suivent et peut faire
  // répondre HTTP 500 au serveur. On demande donc directement à ADE une
  // semaine dont la valeur interne vaut 7 : ADE produit alors lui-même un
  // modèle littéral que l'on pourra rejouer sans altérer sa structure.
  const currentIsoWeek = preview?.week?.firstDate
    ? isoWeekNumber(preview.week.firstDate)
    : null;
  const currentValue = Number(weekValue.value);
  const delta = 7 - currentValue;

  if (!Number.isInteger(currentIsoWeek) || !Number.isInteger(currentValue) || delta <= 0 || delta > 12) {
    return {
      ok: false,
      code: "COLLECTOR_LITERAL_TEMPLATE_TARGET_UNKNOWN",
      message: "Impossible de déterminer une semaine ADE littérale sûre pour ce modèle.",
      capture,
      weekValue,
      preview
    };
  }

  const targetIsoWeek = currentIsoWeek + delta;
  const startedAt = Date.now();
  const kick = await v3KickWeekInBestFrame(tabId, "next", targetIsoWeek);
  if (!kick?.ok) {
    return {
      ok: false,
      code: kick?.code || "COLLECTOR_LITERAL_TEMPLATE_WEEK_SELECT_FAILED",
      message: "ADE n'a pas pu ouvrir la semaine de référence littérale.",
      kick
    };
  }

  const literalCapture = await collectorWaitFreshLiteralTimetableCapture(
    tabId,
    target.resourceId,
    7,
    startedAt,
    7000
  );
  const literalWeekValue = collectorTimetableWeekValue(literalCapture?.body || "");
  const previewDeadline = Date.now() + 2600;
  do {
    await sleep(180);
    preview = await v3ScrapePlanningPreview(tabId).catch(() => null);
    if (preview?.week?.firstDate && isoWeekNumber(preview.week.firstDate) === targetIsoWeek) break;
  } while (Date.now() < previewDeadline);

  if (!literalCapture?.body || !literalCapture?.url || !literalWeekValue?.ok || literalWeekValue.encoding !== "literal") {
    await recordCollectorModelCaptureFailure(
      tabId,
      target,
      literalCapture,
      literalWeekValue,
      {
        code: "COLLECTOR_LITERAL_TEMPLATE_NOT_CAPTURED",
        phase: "collectorCanonicalizeTimetableCapture",
        sourceWeekValue: weekValue,
        requestedIsoWeek: targetIsoWeek,
        kick
      }
    );
    return {
      ok: false,
      code: "COLLECTOR_LITERAL_TEMPLATE_NOT_CAPTURED",
      message: "ADE n'a pas fourni de modèle getTimetable littéral exploitable.",
      capture: literalCapture,
      weekValue: literalWeekValue,
      preview
    };
  }

  if (!preview?.week?.firstDate || isoWeekNumber(preview.week.firstDate) !== targetIsoWeek) {
    return {
      ok: false,
      code: "COLLECTOR_LITERAL_TEMPLATE_PREVIEW_MISMATCH",
      message: "ADE a fourni le modèle RPC mais l'affichage n'a pas confirmé la même semaine.",
      capture: literalCapture,
      weekValue: literalWeekValue,
      preview
    };
  }

  await appendCollectorDiagnostic({
    type: "collector-literal-template",
    code: "COLLECTOR_LITERAL_TEMPLATE_CAPTURED",
    resourceId: Number(target.resourceId),
    label: target.label || null,
    path: target.path || null,
    sourceEncoding: weekValue.encoding,
    sourceValue: weekValue.value,
    literalValue: literalWeekValue.value,
    requestedIsoWeek: targetIsoWeek,
    bodyLength: String(literalCapture.body || "").length
  });

  return {
    ok: true,
    code: "COLLECTOR_LITERAL_TEMPLATE_READY",
    capture: literalCapture,
    weekValue: literalWeekValue,
    preview
  };
}

function collectorRequestFromModel(model, target) {
  const request = model?.request || null;
  if (!request?.body || !request?.url) return null;

  const targetValue = Number(model.baseWeekValue) + Number(target.offset || 0);
  let changed;
  try {
    changed = rebuildCollectorTimetableWeekBody(request.body, targetValue);
  } catch {
    return null;
  }

  return {
    operation: "DirectPlanningPlanningServiceProxy::method10getTimetable",
    method: request.method || "POST",
    url: request.url,
    body: changed.body,
    targetValue
  };
}

async function collectorPreparedModels() {
  const data = await storeGet([COLLECTOR_MODEL_STORAGE_KEY]);
  return data[COLLECTOR_MODEL_STORAGE_KEY] || {};
}

async function collectorStorePreparedModel(model) {
  const models = await collectorPreparedModels();
  models[String(model.resourceId)] = model;
  await storeSet({ [COLLECTOR_MODEL_STORAGE_KEY]: models });
}

async function collectorClearPreparedModels(resourceIds = null) {
  if (!Array.isArray(resourceIds)) {
    await chrome.storage.local.remove([COLLECTOR_MODEL_STORAGE_KEY]);
    return;
  }
  const models = await collectorPreparedModels();
  for (const id of resourceIds) delete models[String(id)];
  await storeSet({ [COLLECTOR_MODEL_STORAGE_KEY]: models });
}

async function collectorBuildModelForTarget(tabId, target) {
  if (!target?.resourceId) {
    return { ok: false, code: "COLLECTOR_RESOURCE_MISSING" };
  }

  await collectorEnsureAdeInteractive(tabId);

  const startedAt = Date.now();
  const selection = await collectorSelectResource(tabId, target);
  if (!selection?.ok) return selection;

  // selectPlanningResource attend déjà que la ligne soit réellement sélectionnée.
  // On attend donc directement le vrai getTimetable de cette ressource au lieu
  // d'enchaîner une seconde attente DOM de 14 s. Dans la majorité des cas la
  // requête a même déjà été capturée pendant le clic.
  let capture = await collectorWaitFreshTimetableCapture(
    tabId,
    target.resourceId,
    startedAt,
    2600
  );
  let weekValue = collectorTimetableWeekValue(capture?.body || "");

  // Cas rare : cliquer une ressource déjà sélectionnée n'émet rien, ou ADE
  // tarde à produire une requête exploitable. Une seule navigation sert alors
  // à forcer getTimetable, sans introduire de logique spéciale sur les semaines.
  if (!capture?.body || !weekValue.ok) {
    const kickedAt = Date.now();
    const kick = await v3KickWeekInBestFrame(tabId, "next");
    if (kick?.ok) {
      capture = await collectorWaitFreshTimetableCapture(
        tabId,
        target.resourceId,
        kickedAt,
        3500
      );
      weekValue = collectorTimetableWeekValue(capture?.body || "");
    }
  }

  if (!capture?.body || !capture?.url || !weekValue.ok) {
    await recordCollectorModelCaptureFailure(
      tabId,
      target,
      capture,
      weekValue,
      {
        code: weekValue?.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
        phase: "collectorBuildModelForTarget"
      }
    );
    return {
      ok: false,
      code: weekValue?.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
      message: "Le modèle getTimetable de cet emploi du temps n'a pas pu être capturé.",
      resourceId: target.resourceId
    };
  }

  const canonical = await collectorCanonicalizeTimetableCapture(
    tabId, target, capture, weekValue
  );
  if (!canonical?.ok) return canonical;
  capture = canonical.capture;
  weekValue = canonical.weekValue;
  const preview = canonical.preview || await v3ScrapePlanningPreview(tabId).catch(() => null);
  if (!preview?.week?.firstDate || !preview?.week?.lastDate) {
    return {
      ok: false,
      code: "COLLECTOR_BASE_WEEK_MISSING",
      message: "La semaine de référence affichée par ADE n'a pas pu être lue.",
      resourceId: target.resourceId
    };
  }

  const model = {
    schemaVersion: 4,
    capturedAt: nowIso(),
    resourceId: Number(target.resourceId),
    label: target.label || selection.resource?.label || preview?.planningLabel || null,
    path: target.path || selection.resource?.path || null,
    baseWeek: {
      firstDate: preview.week.firstDate,
      lastDate: preview.week.lastDate
    },
    baseWeekValue: weekValue.value,
    weekPayloadIndex: weekValue.index,
    request: {
      method: capture.method || "POST",
      url: capture.url,
      body: capture.body,
      headers: capture.headers || {}
    },
    selectedVisibleWeek: null
  };

  return {
    ok: true,
    code: "COLLECTOR_MODEL_READY",
    model
  };
}


async function collectorBuildModelFromSelectedTarget(tabId, target, selectedAt = 0) {
  if (!target?.resourceId) return { ok: false, code: "COLLECTOR_RESOURCE_MISSING" };

  const sinceAt = Number(selectedAt || Date.now() - 1200);
  let capture = await collectorWaitFreshTimetableCapture(
    tabId,
    target.resourceId,
    sinceAt,
    2600
  );
  let weekValue = collectorTimetableWeekValue(capture?.body || "");

  // Un clic sur une ligne déjà sélectionnée peut ne pas produire de RPC.
  // Une seule navigation de semaine sert alors à provoquer getTimetable.
  if (!capture?.body || !weekValue.ok) {
    await collectorEnsureAdeInteractive(tabId);
    const kickedAt = Date.now();
    const kick = await v3KickWeekInBestFrame(tabId, "next");
    if (kick?.ok) {
      capture = await collectorWaitFreshTimetableCapture(
        tabId,
        target.resourceId,
        kickedAt,
        3500
      );
      weekValue = collectorTimetableWeekValue(capture?.body || "");
    }
  }

  if (!capture?.body || !capture?.url || !weekValue.ok) {
    await recordCollectorModelCaptureFailure(
      tabId,
      target,
      capture,
      weekValue,
      {
        code: weekValue?.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
        phase: "collectorBuildModelFromSelectedTarget"
      }
    );
    return {
      ok: false,
      code: weekValue?.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
      message: "Le modèle getTimetable de cet emploi du temps n'a pas pu être capturé.",
      resourceId: target.resourceId
    };
  }

  const canonical = await collectorCanonicalizeTimetableCapture(
    tabId, target, capture, weekValue
  );
  if (!canonical?.ok) return canonical;
  capture = canonical.capture;
  weekValue = canonical.weekValue;
  const preview = canonical.preview || await v3ScrapePlanningPreview(tabId).catch(() => null);
  if (!preview?.week?.firstDate || !preview?.week?.lastDate) {
    return {
      ok: false,
      code: "COLLECTOR_BASE_WEEK_MISSING",
      message: "La semaine de référence affichée par ADE n'a pas pu être lue.",
      resourceId: target.resourceId
    };
  }

  return {
    ok: true,
    code: "COLLECTOR_MODEL_READY",
    model: {
      schemaVersion: 4,
      capturedAt: nowIso(),
      resourceId: Number(target.resourceId),
      label: target.label || preview?.planningLabel || null,
      path: target.path || null,
      baseWeek: {
        firstDate: preview.week.firstDate,
        lastDate: preview.week.lastDate
      },
      baseWeekValue: weekValue.value,
      weekPayloadIndex: weekValue.index,
      request: {
        method: capture.method || "POST",
        url: capture.url,
        body: capture.body,
        headers: capture.headers || {}
      },
      selectedVisibleWeek: null
    }
  };
}

function compactCollectorSyncResult(result, model = null) {
  if (!result) return null;
  return {
    ok: Boolean(result?.ok),
    code: result?.code || null,
    resourceId: result?.resourceId ?? model?.resourceId ?? null,
    label: result?.label || model?.label || null,
    path: result?.path || model?.path || null,
    eventCount: Number(result?.eventCount || 0),
    weekCount: Number(result?.weekCount || 0),
    requestedWeeks: Number(result?.requestedWeeks || 0),
    successfulWeekCount: Number(result?.successfulWeekCount || 0),
    verified: result?.verified === true,
    failedWeekCount: Number(result?.failedWeekCount || 0),
    message: result?.message || null,
    authRequired: Boolean(result?.authRequired || result?.code === "AUTH_REQUIRED")
  };
}

async function collectorEnsureAdeTab() {
  let tab = await bestAdeTab();
  if (tab?.id) return { tab, created: false };

  // Le collecteur est lancé depuis le site : l'utilisateur ne doit pas avoir
  // à ouvrir ADE manuellement avant de cliquer sur le bouton.
  tab = await chrome.tabs.create({
    url: ADE_URL,
    active: true
  });

  try {
    await waitTab(tab.id, 30000);
  } catch {}

  // L'onglet peut désormais être sur CAS si la session universitaire a expiré.
  const refreshed = await chrome.tabs.get(tab.id).catch(() => tab);
  return { tab: refreshed || tab, created: true };
}


async function collectorSyncSelectedTargetStable(tabId, target) {
  if (!Number.isInteger(tabId) || !target?.resourceId) {
    return { ok: false, code: "COLLECTOR_RESOURCE_MISSING", resourceId: target?.resourceId ?? null };
  }

  let ready = await collectorWaitForResourceSelection(tabId, target.resourceId, 5000);
  for (let selectionAttempt = 0; !ready?.ok && selectionAttempt < 2; selectionAttempt += 1) {
    await collectorEnsureAdeInteractive(tabId);
    await sleep(250 + selectionAttempt * 300);
    const reselected = await collectorSelectResource(tabId, target).catch(() => null);
    if (reselected?.ok) {
      ready = await collectorWaitForResourceSelection(tabId, target.resourceId, 7000 + selectionAttempt * 2000);
    }
  }

  if (!ready?.ok) {
    return {
      ok: false,
      code: ready?.code || "COLLECTOR_RESOURCE_NOT_READY",
      resourceId: target.resourceId,
      label: target.label || null,
      path: target.path || null,
      message: ready?.message || "ADE n'a pas confirmé la sélection de cet emploi du temps après plusieurs tentatives."
    };
  }

  const selectedResource = {
    ...target,
    label: target.label || ready?.preview?.planningLabel || null,
    path: target.path || null
  };

  await storeSet({
    collectorState: {
      state: "syncing",
      phase: "verified_method10",
      startedAt: nowIso(),
      resourceId: Number(selectedResource.resourceId),
      label: selectedResource.label || null,
      path: selectedResource.path || null
    }
  });

  // 4.5.9 : la collecte annuelle ne dépend plus de la séquence GWT complète.
  // On capture un vrai method10getTimetable de la ressource, on force si
  // nécessaire un modèle littéral produit par ADE, puis on ne modifie que la
  // valeur de semaine de ce même appel.
  const built = await collectorBuildModelForTarget(tabId, selectedResource);
  if (!built?.ok || !built?.model) {
    return {
      ok: false,
      code: built?.code || "COLLECTOR_MODEL_CAPTURE_FAILED",
      resourceId: Number(selectedResource.resourceId),
      label: selectedResource.label || null,
      path: selectedResource.path || null,
      message: built?.message || null
    };
  }

  const sync = await collectorSyncPreparedModel(tabId, built.model, {
    weekConcurrency: 4,
    allowVisualFallback: false
  });

  if (!sync?.ok) {
    return {
      ok: false,
      code: sync?.code || "COLLECTOR_SYNC_FAILED",
      resourceId: Number(selectedResource.resourceId),
      label: selectedResource.label || null,
      path: selectedResource.path || null,
      message: sync?.message || null,
      eventCount: Number(sync?.eventCount || 0),
      weekCount: Number(sync?.weekCount || 0),
      requestedWeeks: Number(sync?.requestedWeeks || 0),
      successfulWeekCount: Number(sync?.successfulWeekCount || 0),
      failedWeekCount: Number(sync?.failedWeekCount || 0),
      failedWeekSummary: sync?.failedWeekSummary || null,
      authRequired: Boolean(sync?.authRequired || sync?.code === "AUTH_REQUIRED")
    };
  }

  const requestedWeeks = Number(sync.requestedWeeks || 0);
  const successfulWeekCount = Number(sync.successfulWeekCount || 0);
  const weekCount = Number(sync.weekCount || 0);
  const verified = Boolean(sync.verified) &&
    requestedWeeks > 0 &&
    successfulWeekCount === requestedWeeks &&
    weekCount === requestedWeeks;

  if (!verified) {
    return {
      ok: false,
      code: "COLLECTOR_COMPLETENESS_CHECK_FAILED",
      resourceId: Number(selectedResource.resourceId),
      label: selectedResource.label || null,
      path: selectedResource.path || null,
      eventCount: Number(sync.eventCount || 0),
      weekCount,
      requestedWeeks,
      successfulWeekCount,
      failedWeekCount: Math.max(0, requestedWeeks - successfulWeekCount),
      message: `Validation finale incomplète (${successfulWeekCount}/${requestedWeeks} semaines). L'ancien EDT a été conservé.`
    };
  }

  return {
    ok: true,
    code: "COLLECTOR_RESOURCE_SYNCED_VERIFIED",
    resourceId: Number(selectedResource.resourceId),
    label: selectedResource.label || null,
    path: selectedResource.path || null,
    eventCount: Number(sync.eventCount || 0),
    weekCount,
    requestedWeeks,
    successfulWeekCount,
    verified: true,
    failedWeekCount: 0
  };
}

async function collectorPipelineReset(message = {}) {
  const ensured = await collectorEnsureAdeTab();
  const tab = ensured?.tab || null;
  if (!tab?.id) return { ok: false, code: "ADE_OPEN_FAILED", message: "ADE n'a pas pu être ouvert." };
  const authenticated = await v3TabLooksAuthenticated(tab.id);
  if (!authenticated) {
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
    return {
      ok: false,
      code: "AUTH_REQUIRED",
      tabId: tab.id,
      adeOpened: Boolean(ensured?.created),
      message: ensured?.created
        ? "ADE a été ouvert. Connecte-toi à l'université puis relance la synchronisation."
        : "Reconnecte-toi à ADE puis relance la synchronisation."
    };
  }
  await collectorEnsureAdeInteractive(tab.id);

  // Les anciens audits 4.6.0/4.6.1 pouvaient occuper plusieurs Mo. Ils sont
  // compactés avant une collecte complète pour laisser toute la place aux
  // payloads des 216 EDT. Les payloads eux-mêmes ne sont jamais supprimés ici.
  await compactCollectorDiagnosticsStorage().catch(() => {});

  const reset = await planningFrameMessage(tab.id, { type: "PLANILIM_ADE_PIPELINE_RESET" });
  await chrome.storage.local.remove([COLLECTOR_PIPELINE_STORAGE_KEY, COLLECTOR_MODEL_STORAGE_KEY]);
  await storeSet({
    collectorState: {
      state: "pipeline_ready",
      phase: "discover_capture_download",
      discovered: 0,
      completed: 0,
      startedAt: nowIso()
    }
  });
  return { ok: reset?.ok !== false, code: "COLLECTOR_PIPELINE_RESET", tabId: tab.id };
}

async function collectorPipelineStep(message = {}) {
  const tab = await bestAdeTab();
  if (!tab?.id) return { ok: false, code: "ADE_NOT_OPEN" };
  const authenticated = await v3TabLooksAuthenticated(tab.id);
  if (!authenticated) return { ok: false, code: "AUTH_REQUIRED", tabId: tab.id };

  const weekConcurrency = Math.max(1, Math.min(8, Number(message.weekConcurrency) || 8));
  const data = await storeGet([COLLECTOR_PIPELINE_STORAGE_KEY]);
  const runtime = data[COLLECTOR_PIPELINE_STORAGE_KEY] || {
    discoveredCount: 0,
    completedCount: 0,
    discoveryDone: false
  };

  if (runtime.discoveryDone) {
    return {
      ok: true,
      code: "COLLECTOR_PIPELINE_DONE",
      done: true,
      discoveryDone: true,
      discoveredCount: Number(runtime.discoveredCount || 0),
      completedCount: Number(runtime.completedCount || 0),
      discovered: null,
      discoveredFailure: null,
      completedResult: null
    };
  }

  // Un seul EDT à la fois. On le découvre, on capture son modèle puis on
  // télécharge son année AVANT de toucher au suivant. Cela conserve le gain du
  // parcours unique sans modifier l'état ADE pendant les RPC du planning courant.
  const step = await planningFrameMessage(tab.id, {
    type: "PLANILIM_ADE_PIPELINE_NEXT",
    options: {
      reset: Boolean(message.reset),
      scopePath: message.scopePath || COLLECTOR_DEFAULT_SCOPE_PATH,
      maxDepth: Math.max(1, Math.min(4, Number(message.maxDepth) || 4)),
      maxActions: Math.max(60, Math.min(1200, Number(message.maxActions) || 500))
    }
  });

  if (!step?.ok) {
    return {
      ok: false,
      code: step?.code || "COLLECTOR_PIPELINE_DISCOVERY_FAILED",
      message: step?.message || null,
      done: false,
      discoveryDone: false,
      discoveredCount: Number(runtime.discoveredCount || 0),
      completedCount: Number(runtime.completedCount || 0)
    };
  }

  if (step.done || !step.target) {
    const discoveredCount = Math.max(
      Number(runtime.discoveredCount || 0),
      Number(step.discoveredCount || 0)
    );
    const completedCount = Number(runtime.completedCount || 0);
    await storeSet({
      [COLLECTOR_PIPELINE_STORAGE_KEY]: {
        discoveredCount,
        completedCount,
        discoveryDone: true,
        updatedAt: nowIso()
      },
      collectorState: {
        state: "ready",
        phase: "discover_capture_download",
        discovered: discoveredCount,
        completed: completedCount,
        finishedAt: nowIso()
      }
    });
    return {
      ok: true,
      code: "COLLECTOR_PIPELINE_DONE",
      done: true,
      discoveryDone: true,
      discoveredCount,
      completedCount,
      discovered: null,
      discoveredFailure: null,
      completedResult: null,
      expandedCount: Number(step.expandedCount || 0)
    };
  }

  const discoveredTarget = step.target;
  const discoveredCount = Math.max(
    Number(runtime.discoveredCount || 0) + 1,
    Number(step.discoveredCount || 0)
  );

  let discoveredFailure = null;
  let completedResult = null;
  let completedCount = Number(runtime.completedCount || 0);

  if (step.selection?.ok === false) {
    discoveredFailure = {
      ok: false,
      code: step.selection?.code || "COLLECTOR_PIPELINE_SELECTION_FAILED",
      resourceId: discoveredTarget.resourceId ?? null,
      label: discoveredTarget.label || null,
      path: discoveredTarget.path || null,
      message: step.selection?.message || null
    };
  } else {
    const synced = await collectorSyncSelectedTargetStable(tab.id, discoveredTarget)
      .catch((error) => ({
        ok: false,
        code: "COLLECTOR_PIPELINE_SYNC_EXCEPTION",
        message: String(error),
        resourceId: discoveredTarget.resourceId ?? null,
        label: discoveredTarget.label || null,
        path: discoveredTarget.path || null
      }));
    completedResult = compactCollectorSyncResult(synced, discoveredTarget);
    completedCount += 1;
  }

  await storeSet({
    [COLLECTOR_PIPELINE_STORAGE_KEY]: {
      discoveredCount,
      completedCount,
      discoveryDone: false,
      updatedAt: nowIso()
    },
    collectorState: {
      state: "pipeline_running",
      phase: "discover_capture_download",
      discovered: discoveredCount,
      completed: completedCount,
      currentResourceId: discoveredTarget.resourceId ?? null,
      updatedAt: nowIso()
    }
  });

  return {
    ok: true,
    code: "COLLECTOR_PIPELINE_STEP",
    done: false,
    discoveryDone: false,
    discoveredCount,
    completedCount,
    discovered: discoveredTarget,
    discoveredFailure,
    completedResult,
    expandedCount: Number(step.expandedCount || 0)
  };
}

async function collectorCaptureModel(message = {}) {
  const target = message.target || message.resource || message;
  if (!target?.resourceId) {
    return { ok: false, code: "COLLECTOR_RESOURCE_MISSING" };
  }

  let tabId = Number(message.tabId);
  if (!Number.isInteger(tabId)) {
    const snapshot = await collectorTreeSnapshot();
    if (!snapshot?.ok) return snapshot;
    tabId = snapshot.tabId;
  }

  const built = await collectorBuildModelForTarget(tabId, target);
  if (!built?.ok || !built.model) return built;

  if (message.store !== false) {
    await collectorStorePreparedModel(built.model);
  }

  return {
    ok: true,
    code: "COLLECTOR_MODEL_READY",
    resourceId: built.model.resourceId,
    label: built.model.label,
    path: built.model.path,
    baseWeek: built.model.baseWeek
  };
}

async function collectorReplayModelWeek(tabId, model, target, attempt = 0) {
  const item = collectorRequestFromModel(model, target);
  if (!item) {
    return {
      authRequired: false,
      weekResult: {
        offset: target.offset,
        week: { firstDate: target.firstDate, lastDate: target.lastDate },
        ok: false,
        code: "COLLECTOR_MODEL_REQUEST_MISSING",
        syncedAt: nowIso(),
        eventCount: 0,
        events: []
      }
    };
  }

  const replay = await replayInPage(tabId, {
    method: item.method,
    url: item.url,
    headers: model.request?.headers || {},
    body: item.body,
    timeoutMs: 12000
  });
  const responseText = String(replay?.responseText || "");
  if (looksLikeAuthenticationPage(responseText, replay?.httpStatus)) {
    return { authRequired: true, weekResult: null };
  }

  const week = { firstDate: target.firstDate, lastDate: target.lastDate };
  let decoded = replay?.ok ? decodeSquareEventsResponse(responseText, week) : null;
  const mismatch = decoded?.ok &&
    Number.isInteger(decoded?.gwt?.expectedEventCount) &&
    Number.isInteger(decoded?.gwt?.detectedEventCount) &&
    decoded.gwt.expectedEventCount !== decoded.gwt.detectedEventCount;

  if ((!decoded?.ok || mismatch) && attempt < 1) {
    await sleep(120 + Math.floor(Math.random() * 120));
    return await collectorReplayModelWeek(tabId, model, target, attempt + 1);
  }

  if (!decoded?.ok || mismatch) {
    const failureCode = mismatch
      ? "COLLECTOR_EVENT_COUNT_MISMATCH"
      : (decoded?.code || replay?.error || "COLLECTOR_WEEK_RPC_FAILED");

    await recordCollectorWeekFailure(
      model,
      target,
      item,
      responseText,
      decoded,
      failureCode
    );

    // Diagnostic ciblé 4.5.9 : si un replay fabriqué échoue, on rejoue une
    // fois le body natif capturé auprès d'ADE et le body reconstruit pour la
    // semaine de base. Cela permet de distinguer immédiatement un problème de
    // contexte HTTP d'un problème de mutation GWT.
    try {
      const nativeReplay = await replayInPage(tabId, {
        method: model.request?.method || "POST",
        url: model.request?.url,
        headers: model.request?.headers || {},
        body: model.request?.body || "",
        timeoutMs: 12000
      });
      const baseItem = collectorRequestFromModel(model, { offset: 0 });
      const rebuiltReplay = baseItem
        ? await replayInPage(tabId, {
            method: baseItem.method,
            url: baseItem.url,
            headers: model.request?.headers || {},
            body: baseItem.body,
            timeoutMs: 12000
          })
        : null;
      await appendCollectorDiagnostic({
        type: "collector-replay-verification",
        code: "COLLECTOR_REPLAY_VERIFICATION",
        resourceId: model?.resourceId ?? null,
        label: model?.label || null,
        path: model?.path || null,
        failedWeek: { firstDate: target.firstDate, lastDate: target.lastDate, offset: target.offset },
        failedCode: failureCode,
        templateEncoding: collectorTimetableWeekValue(model.request?.body || "")?.encoding || null,
        templateValue: model.baseWeekValue,
        nativeAndRebuiltBaseBodiesEqual: Boolean(baseItem && baseItem.body === model.request?.body),
        nativeReplay: {
          ok: Boolean(nativeReplay?.ok),
          httpStatus: nativeReplay?.httpStatus ?? null,
          responseLength: String(nativeReplay?.responseText || "").length,
          responseText: diagnosticText(nativeReplay?.responseText || "", 220000),
          error: nativeReplay?.error || null
        },
        rebuiltBaseReplay: rebuiltReplay ? {
          ok: Boolean(rebuiltReplay?.ok),
          httpStatus: rebuiltReplay?.httpStatus ?? null,
          responseLength: String(rebuiltReplay?.responseText || "").length,
          responseText: diagnosticText(rebuiltReplay?.responseText || "", 220000),
          error: rebuiltReplay?.error || null
        } : null
      });
    } catch {}

    return {
      authRequired: false,
      weekResult: {
        offset: target.offset,
        week,
        ok: false,
        code: failureCode,
        decodeMessage: decoded?.message || null,
        syncedAt: nowIso(),
        eventCount: 0,
        events: []
      }
    };
  }

  const events = decoded.events.map(compactNormalizedEvent);
  return {
    authRequired: false,
    weekResult: {
      offset: target.offset,
      week,
      ok: true,
      code: "COLLECTOR_WEEK_DECODED_FAST",
      syncedAt: nowIso(),
      responseLength: responseText.length,
      eventCount: events.length,
      expectedEventCount: decoded?.gwt?.expectedEventCount ?? null,
      detectedEventCount: decoded?.gwt?.detectedEventCount ?? null,
      events
    }
  };
}

function collectorWeekResultSignature(result) {
  if (!result?.ok || !Array.isArray(result?.events)) return null;
  const keys = result.events.map((event) => eventStableKey(event)).sort();
  return `${keys.length}::${keys.join("\n")}`;
}

function collectorVerificationTargets(targets) {
  const preferredOffsets = [-3, -2, -1, 0, 1, 2, 7, 14, 21, 28];
  const selected = [];
  const seen = new Set();

  for (const offset of preferredOffsets) {
    const target = targets.find((item) => Number(item?.offset) === offset);
    if (!target?.firstDate || seen.has(target.firstDate)) continue;
    seen.add(target.firstDate);
    selected.push(target);
    if (selected.length >= 8) break;
  }

  if (selected.length < 6) {
    for (const target of targets) {
      if (!target?.firstDate || seen.has(target.firstDate)) continue;
      seen.add(target.firstDate);
      selected.push(target);
      if (selected.length >= 8) break;
    }
  }

  return selected;
}

async function collectorVerifyParallelResults(tabId, model, targets, weekMap) {
  const sentinels = collectorVerificationTargets(targets);
  const checks = [];
  let authRequired = false;

  for (const target of sentinels) {
    const parallel = weekMap.get(target.firstDate) || null;
    const sequentialReplay = await collectorReplayModelWeek(tabId, model, target);
    if (sequentialReplay?.authRequired) {
      authRequired = true;
      break;
    }
    const sequential = sequentialReplay?.weekResult || null;
    const parallelSignature = collectorWeekResultSignature(parallel);
    const sequentialSignature = collectorWeekResultSignature(sequential);
    const same = Boolean(parallelSignature && sequentialSignature && parallelSignature === sequentialSignature);

    checks.push({
      week: target.firstDate,
      offset: target.offset,
      same,
      parallelOk: Boolean(parallel?.ok),
      sequentialOk: Boolean(sequential?.ok),
      parallelEventCount: Number(parallel?.eventCount || 0),
      sequentialEventCount: Number(sequential?.eventCount || 0),
      parallelExpectedEventCount: parallel?.expectedEventCount ?? null,
      sequentialExpectedEventCount: sequential?.expectedEventCount ?? null,
      parallelDetectedEventCount: parallel?.detectedEventCount ?? null,
      sequentialDetectedEventCount: sequential?.detectedEventCount ?? null
    });

    // Le résultat séquentiel est plus fiable : même quand tout concorde, on le
    // conserve pour ces semaines de contrôle afin que le payload final utilise
    // exactement ce qui vient d'être vérifié.
    if (sequential?.week?.firstDate) {
      weekMap.set(sequential.week.firstDate, sequential);
    }
    await sleep(35);
  }

  const mismatches = checks.filter((item) => !item.same);
  return {
    ok: !authRequired && mismatches.length === 0,
    authRequired,
    checks,
    mismatchCount: mismatches.length,
    mismatches
  };
}

async function collectorReplayAllWeeksSequential(tabId, model, targets, options = {}) {
  const map = new Map();
  let authRequired = false;

  for (let index = 0; index < targets.length; index += 1) {
    const target = targets[index];
    const replayed = await collectorReplayModelWeek(tabId, model, target);
    if (replayed?.authRequired) {
      authRequired = true;
      break;
    }
    if (replayed?.weekResult?.week?.firstDate) {
      map.set(replayed.weekResult.week.firstDate, replayed.weekResult);
    }
    if (options.onWeekProgress) {
      try { await options.onWeekProgress(index + 1, targets.length); } catch {}
    }
    if (index < targets.length - 1) await sleep(30);
  }

  return { ok: !authRequired, authRequired, map };
}

function collectorBuildPayloadFromWeeks(model, weeks) {
  const bounds = academicYearBoundsForWeek(model.baseWeek);
  const normalizedWeeks = [...weeks].sort((a, b) =>
    String(a?.week?.firstDate || "").localeCompare(String(b?.week?.firstDate || ""))
  );
  const events = deduplicateEvents(rebuildEventsFromWeeks(normalizedWeeks)).sort((a, b) => {
    const d = String(a.date || "").localeCompare(String(b.date || ""));
    return d || String(a.start || "").localeCompare(String(b.start || ""));
  });
  return {
    schemaVersion: 2,
    source: "unilim-ade",
    generatedAt: nowIso(),
    academicYear: bounds?.academicYear || null,
    resource: {
      id: model.resourceId,
      label: model.label || null,
      path: model.path || null
    },
    syncRange: {
      firstDate: bounds?.startDate || null,
      lastDate: bounds?.endDate || null
    },
    weekCount: normalizedWeeks.length,
    eventCount: events.length,
    events
  };
}

async function collectorStorePayloadFromModel(model, weeks, status = {}) {
  const payload = collectorBuildPayloadFromWeeks(model, weeks);
  const data = await storeGet(["collectorResources"]);
  const resources = data.collectorResources || {};
  resources[String(model.resourceId)] = {
    resourceId: model.resourceId,
    label: model.label || null,
    path: model.path || null,
    academicYear: payload.academicYear || null,
    eventCount: payload.eventCount,
    weekCount: payload.weekCount,
    updatedAt: nowIso(),
    partial: Boolean(status.partial),
    verified: status.verified === true,
    requestedWeekCount: Number(status.requestedWeekCount || payload.weekCount || 0),
    successfulWeekCount: Number(status.successfulWeekCount || payload.weekCount || 0),
    failedWeekCount: Number(status.failedWeekCount || 0),
    collectionMode: status?.consistency?.fallbackSequential
      ? "sequential-fallback"
      : (status?.consistency?.checked ? "parallel-verified" : "sequential"),
    consistencyMismatchCount: Number(status?.consistency?.mismatchCount || 0),
    payload
  };
  await storeSet({ collectorResources: resources });
  return payload;
}

async function collectorRepairLeadingWeeksForModel(tabId, model, weekMap) {
  await collectorEnsureAdeInteractive(tabId);
  const startedAt = Date.now();
  const selection = await collectorSelectResource(tabId, {
    resourceId: model.resourceId,
    label: model.label,
    path: model.path
  });
  if (!selection?.ok) return { ok: false, code: selection?.code || "COLLECTOR_REPAIR_SELECT_FAILED" };
  const ready = await collectorWaitForResourceSelection(tabId, model.resourceId, 14000);
  if (!ready?.ok) return ready;
  const leading = await collectorCaptureLeadingWeeks(tabId, model.resourceId);
  if (leading?.authRequired) return { ok: false, code: "AUTH_REQUIRED", authRequired: true };
  for (const week of leading?.weeks || []) {
    if (week?.week?.firstDate) weekMap.set(week.week.firstDate, week);
  }
  return {
    ok: true,
    code: "COLLECTOR_LEADING_WEEKS_REPAIRED",
    repairedCount: (leading?.weeks || []).length,
    startedAt
  };
}

async function collectorSyncPreparedModel(tabId, model, options = {}) {
  const bounds = academicYearBoundsForWeek(model?.baseWeek);
  if (!bounds) return { ok: false, code: "ACADEMIC_BOUNDS_UNKNOWN", resourceId: model?.resourceId };
  const targets = weeklyTargetsForRange(model.baseWeek, bounds.startDate, bounds.endDate);
  const weekConcurrency = Math.max(1, Math.min(8, Number(options.weekConcurrency) || COLLECTOR_WEEK_CONCURRENCY_DEFAULT));
  const weekMap = new Map();
  let authRequired = false;

  for (let start = 0; start < targets.length; start += weekConcurrency) {
    const batch = targets.slice(start, start + weekConcurrency);
    const results = await Promise.all(batch.map(target => collectorReplayModelWeek(tabId, model, target)));
    for (let i = 0; i < results.length; i += 1) {
      const result = results[i];
      if (result?.authRequired) authRequired = true;
      if (result?.weekResult) weekMap.set(batch[i].firstDate, result.weekResult);
    }
    if (authRequired) break;
    if (options.onWeekProgress) {
      try { await options.onWeekProgress(Math.min(start + batch.length, targets.length), targets.length); } catch {}
    }
    if (start + weekConcurrency < targets.length) await sleep(20);
  }

  if (authRequired) {
    return { ok: false, code: "AUTH_REQUIRED", authRequired: true, resourceId: model.resourceId };
  }

  if (model.selectedVisibleWeek?.week?.firstDate) {
    weekMap.set(model.selectedVisibleWeek.week.firstDate, model.selectedVisibleWeek);
  }

  // Une semaine vide est une donnée valide. En revanche une semaine absente
  // ou mal décodée ne doit pas faire échouer tout l'EDT au premier incident
  // réseau : on ne rejoue que les semaines en échec, séquentiellement.
  let repair = { passes: 0, attemptedWeeks: 0, recoveredWeeks: 0 };
  for (let repairPass = 0; repairPass < 3; repairPass += 1) {
    const failedTargets = targets.filter(target => !weekMap.get(target.firstDate)?.ok);
    if (!failedTargets.length) break;
    repair.passes += 1;

    for (const target of failedTargets) {
      repair.attemptedWeeks += 1;
      await sleep(120 + repairPass * 220);
      const beforeOk = Boolean(weekMap.get(target.firstDate)?.ok);
      const retried = await collectorReplayModelWeek(tabId, model, target);
      if (retried?.authRequired) {
        return { ok: false, code: "AUTH_REQUIRED", authRequired: true, resourceId: model.resourceId };
      }
      if (retried?.weekResult) {
        weekMap.set(target.firstDate, retried.weekResult);
        if (!beforeOk && retried.weekResult.ok) repair.recoveredWeeks += 1;
      }
    }
  }

  let consistency = {
    checked: false,
    mismatchCount: 0,
    fallbackSequential: false,
    checks: []
  };

  // ADE n'est pas totalement stateless : plusieurs getTimetable simultanés
  // peuvent parfois renvoyer une semaine voisine tout en restant HTTP 200.
  // C'est précisément le type d'erreur qui passait inaperçu en 4.5.9.
  // Après le passage rapide, on re-télécharge quelques semaines sentinelles
  // séquentiellement et on compare les événements complets. Au moindre écart,
  // on jette le résultat parallèle et on refait cet EDT entièrement en mode
  // séquentiel avant toute publication.
  if (weekConcurrency > 1 && targets.length) {
    const verification = await collectorVerifyParallelResults(tabId, model, targets, weekMap);
    if (verification?.authRequired) {
      return { ok: false, code: "AUTH_REQUIRED", authRequired: true, resourceId: model.resourceId };
    }

    consistency = {
      checked: true,
      mismatchCount: Number(verification?.mismatchCount || 0),
      fallbackSequential: false,
      checks: verification?.checks || []
    };

    if (!verification?.ok) {
      consistency.fallbackSequential = true;
      const sequential = await collectorReplayAllWeeksSequential(tabId, model, targets, {
        onWeekProgress: options.onWeekProgress
      });
      if (sequential?.authRequired) {
        return { ok: false, code: "AUTH_REQUIRED", authRequired: true, resourceId: model.resourceId };
      }

      weekMap.clear();
      for (const [firstDate, result] of sequential.map || []) {
        weekMap.set(firstDate, result);
      }

      await appendCollectorDiagnostic({
        type: "collector-concurrency-guard",
        code: "COLLECTOR_PARALLEL_MISMATCH_FALLBACK_SEQUENTIAL",
        resourceId: model?.resourceId ?? null,
        label: model?.label || null,
        path: model?.path || null,
        requestedWeekCount: targets.length,
        parallelWeekConcurrency: weekConcurrency,
        mismatchCount: consistency.mismatchCount,
        checks: consistency.checks,
        sequentialWeekCount: weekMap.size
      });
    }
  }

  const weeks = [...weekMap.values()].sort((a, b) =>
    String(a?.week?.firstDate || "").localeCompare(String(b?.week?.firstDate || ""))
  );
  const failureInfo = collectorFailedWeekSummary(targets, weekMap);
  const failedWeekCount = failureInfo.failedWeekCount;
  const successfulWeekCount = targets.length - failedWeekCount;
  const partial = failedWeekCount > 0 || successfulWeekCount !== targets.length;

  // Une collecte partielle ne doit JAMAIS remplacer le dernier payload complet.
  // On construit un aperçu local pour le diagnostic, mais on ne l'enregistre
  // dans collectorResources qu'après validation de toutes les semaines.
  const previewPayload = collectorBuildPayloadFromWeeks(model, weeks);
  let payload = previewPayload;
  if (!partial) {
    payload = await collectorStorePayloadFromModel(model, weeks, {
      partial: false,
      failedWeekCount: 0,
      verified: true,
      requestedWeekCount: targets.length,
      successfulWeekCount,
      consistency
    });
  }

  return {
    ok: !partial,
    code: partial ? "COLLECTOR_RESOURCE_PARTIAL_NOT_STORED" : "COLLECTOR_RESOURCE_SYNCED_VERIFIED",
    message: partial
      ? `${failedWeekCount} semaine(s) en échec après rattrapage : ${failureInfo.failedWeekSummary || "cause inconnue"}. L'ancien EDT complet a été conservé.`
      : null,
    resourceId: model.resourceId,
    label: model.label,
    path: model.path,
    eventCount: payload.eventCount,
    weekCount: payload.weekCount,
    requestedWeeks: targets.length,
    successfulWeekCount,
    verified: !partial,
    failedWeekCount,
    failedWeekSummary: failureInfo.failedWeekSummary,
    failedWeeks: failureInfo.failedWeeks,
    repair,
    consistency,
    needsVisualLeadingRepair: false,
    __weekMap: weekMap,
    __model: model
  };
}


function collectorAuditNormalizeText(value) {
  return cleanAdeTitle(String(value || ""))
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("fr-FR")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function collectorAuditEventView(event, includeRaw = false) {
  const teachers = Array.isArray(event?.teachers)
    ? event.teachers.filter(Boolean)
    : (event?.teacher ? [event.teacher] : []);
  const view = {
    date: event?.date || null,
    start: event?.start || event?.startTime || null,
    end: event?.end || event?.endTime || null,
    title: event?.title || null,
    type: event?.type || null,
    group: event?.group || event?.groupLine || null,
    teacher: event?.teacher || teachers[0] || null,
    teachers,
    room: event?.room || null,
    building: event?.building || null
  };
  if (includeRaw) {
    view.dayIndex = Number.isInteger(event?.dayIndex) ? event.dayIndex : null;
    view.rawTitle = event?.rawTitle || null;
    view.rawStrings = Array.isArray(event?.rawStrings) ? event.rawStrings : null;
    view.details = Array.isArray(event?.details) ? event.details : null;
    view.rawText = event?.rawText || null;
    view.geometry = event?.geometry || null;
  }
  return view;
}

function collectorAuditEventBaseKey(event) {
  const view = collectorAuditEventView(event, false);
  return [
    view.date || "",
    view.start || "",
    view.end || "",
    collectorAuditNormalizeText(view.title)
  ].join("||");
}

function collectorAuditEventTimeKey(event) {
  const view = collectorAuditEventView(event, false);
  return [view.date || "", view.start || "", view.end || ""].join("||");
}

function collectorAuditCompareWeek(decodedEvents, visibleEvents) {
  const decoded = (Array.isArray(decodedEvents) ? decodedEvents : []).map((event, index) => ({
    index,
    raw: event,
    view: collectorAuditEventView(event, true),
    baseKey: collectorAuditEventBaseKey(event),
    timeKey: collectorAuditEventTimeKey(event)
  }));
  const visible = (Array.isArray(visibleEvents) ? visibleEvents : []).map((event, index) => ({
    index,
    raw: event,
    view: collectorAuditEventView(event, true),
    baseKey: collectorAuditEventBaseKey(event),
    timeKey: collectorAuditEventTimeKey(event)
  }));

  const usedDecoded = new Set();
  const matches = [];
  const visibleOnly = [];
  const titleDisagreements = [];

  for (const candidate of visible) {
    let match = decoded.find((entry) => !usedDecoded.has(entry.index) && entry.baseKey === candidate.baseKey) || null;
    let mode = "exact";

    if (!match) {
      const sameTime = decoded.filter((entry) => !usedDecoded.has(entry.index) && entry.timeKey === candidate.timeKey);
      if (sameTime.length === 1) {
        match = sameTime[0];
        mode = "same-time";
      }
    }

    if (!match) {
      visibleOnly.push(candidate.view);
      continue;
    }

    usedDecoded.add(match.index);
    const sameTitle = collectorAuditNormalizeText(match.view.title) === collectorAuditNormalizeText(candidate.view.title);
    const matched = {
      mode,
      visible: candidate.view,
      decoded: match.view,
      sameTitle
    };
    matches.push(matched);
    if (!sameTitle) titleDisagreements.push(matched);
  }

  const decodedOnly = decoded
    .filter((entry) => !usedDecoded.has(entry.index))
    .map((entry) => entry.view);

  const invalidDecoded = decoded
    .filter((entry) => !entry.view.date || !entry.view.start || !entry.view.end || !entry.view.title)
    .map((entry) => entry.view);

  return {
    decodedCount: decoded.length,
    visibleCount: visible.length,
    matchedCount: matches.length,
    visibleOnlyCount: visibleOnly.length,
    decodedOnlyCount: decodedOnly.length,
    invalidDecodedCount: invalidDecoded.length,
    titleDisagreementCount: titleDisagreements.length,
    visibleOnly,
    decodedOnly,
    invalidDecoded,
    titleDisagreements,
    matches
  };
}

function collectorAuditDuplicateSummary(events) {
  const counts = new Map();
  const sample = new Map();
  for (const event of Array.isArray(events) ? events : []) {
    const key = eventStableKey(event);
    counts.set(key, (counts.get(key) || 0) + 1);
    if (!sample.has(key)) sample.set(key, collectorAuditEventView(event, false));
  }
  return [...counts.entries()]
    .filter(([, count]) => count > 1)
    .map(([key, count]) => ({ key, count, event: sample.get(key) }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 80);
}

async function collectorEventAuditCurrentEdt(message = {}) {
  const tab = await bestAdeTab();
  if (!tab?.id) {
    return {
      ok: false,
      code: "ADE_NOT_OPEN",
      message: "Ouvre ADE sur l'emploi du temps à auditer, puis relance l'audit."
    };
  }

  const authenticated = await v3TabLooksAuthenticated(tab.id);
  if (!authenticated) {
    return { ok: false, code: "AUTH_REQUIRED", message: "Reconnecte-toi à ADE avant de lancer l'audit." };
  }

  await collectorEnsureAdeInteractive(tab.id);
  let initialPreview = await v3ScrapePlanningPreview(tab.id).catch(() => null);
  const resourceId = Number(initialPreview?.resourceId ?? initialPreview?.planningResource?.resourceId ?? NaN);
  if (!Number.isFinite(resourceId)) {
    return {
      ok: false,
      code: "AUDIT_RESOURCE_UNKNOWN",
      message: "Sélectionne d'abord l'emploi du temps à auditer dans l'arbre ADE."
    };
  }

  const target = {
    resourceId,
    label: initialPreview?.planningLabel || initialPreview?.planningResource?.label || null,
    path: initialPreview?.planningResource?.path || null
  };

  await storeSet({
    collectorEventAuditStatus: {
      state: "running",
      startedAt: nowIso(),
      resourceId,
      label: target.label,
      completedWeeks: 0,
      totalWeeks: 0
    }
  });

  // On construit exactement le même modèle que la collecte normale afin que
  // l'audit teste le chemin de données réellement publié par Planilim.
  const built = await collectorBuildModelFromSelectedTarget(tab.id, target, Date.now() - 5000);
  if (!built?.ok || !built?.model) {
    await storeSet({ collectorEventAuditStatus: { state: "finished", ok: false, code: built?.code || "AUDIT_MODEL_FAILED", finishedAt: nowIso() } });
    return {
      ok: false,
      code: built?.code || "AUDIT_MODEL_FAILED",
      message: built?.message || "Le modèle getTimetable de l'EDT n'a pas pu être préparé."
    };
  }

  const model = built.model;
  const bounds = academicYearBoundsForWeek(model.baseWeek);
  const targets = bounds
    ? weeklyTargetsForRange(model.baseWeek, bounds.startDate, bounds.endDate)
    : [];
  if (!targets.length) {
    return { ok: false, code: "AUDIT_NO_WEEKS", message: "La plage de semaines de l'année n'a pas pu être déterminée." };
  }

  await storeSet({
    collectorEventAuditStatus: {
      state: "running",
      startedAt: nowIso(),
      resourceId,
      label: model.label || target.label,
      completedWeeks: 0,
      totalWeeks: targets.length
    }
  });

  const moved = await collectorMoveToAcademicStart(tab.id);
  if (!moved?.ok) {
    return {
      ok: false,
      code: moved?.code || "AUDIT_START_WEEK_FAILED",
      message: "ADE n'a pas pu être positionné au début de l'année universitaire."
    };
  }

  const weekSummaries = [];
  const mismatches = [];
  const allDecodedCompact = [];
  let replayFailureCount = 0;

  for (let index = 0; index < targets.length; index += 1) {
    const targetWeek = targets[index];
    let visible = await v3ScrapePlanningPreview(tab.id).catch(() => null);

    // Le navigateur peut mettre un peu de temps à rafraîchir les en-têtes de
    // jours après un changement de semaine. On attend la semaine attendue.
    const deadline = Date.now() + 3600;
    while (visible?.week?.firstDate !== targetWeek.firstDate && Date.now() < deadline) {
      await sleep(180);
      visible = await v3ScrapePlanningPreview(tab.id).catch(() => null);
    }

    const item = collectorRequestFromModel(model, targetWeek);
    let replay = null;
    let decoded = null;
    let responseText = "";

    if (item) {
      replay = await replayInPage(tab.id, {
        method: item.method,
        url: item.url,
        headers: model.request?.headers || {},
        body: item.body,
        timeoutMs: 12000
      });
      responseText = String(replay?.responseText || "");
      if (replay?.ok) decoded = decodeSquareEventsResponse(responseText, {
        firstDate: targetWeek.firstDate,
        lastDate: targetWeek.lastDate
      });
    }

    const decodedEventsRaw = decoded?.ok && Array.isArray(decoded.events) ? decoded.events : [];
    const decodedCompact = decodedEventsRaw.map(compactNormalizedEvent);
    const visibleEvents = Array.isArray(visible?.events) ? visible.events : [];
    const comparison = collectorAuditCompareWeek(decodedEventsRaw, visibleEvents);
    const expectedEventCount = decoded?.gwt?.expectedEventCount ?? null;
    const detectedEventCount = decoded?.gwt?.detectedEventCount ?? null;
    const wrongVisibleWeek = visible?.week?.firstDate !== targetWeek.firstDate;
    const replayFailed = !replay?.ok || !decoded?.ok;
    if (replayFailed) replayFailureCount += 1;

    const suspicious = replayFailed || wrongVisibleWeek ||
      comparison.visibleOnlyCount > 0 || comparison.decodedOnlyCount > 0 ||
      comparison.invalidDecodedCount > 0 || comparison.titleDisagreementCount > 0 ||
      (Number.isInteger(expectedEventCount) && Number.isInteger(detectedEventCount) && expectedEventCount !== detectedEventCount);

    weekSummaries.push({
      week: { firstDate: targetWeek.firstDate, lastDate: targetWeek.lastDate },
      offset: targetWeek.offset,
      visibleWeek: visible?.week || null,
      visibleEventCount: comparison.visibleCount,
      decodedEventCount: comparison.decodedCount,
      expectedEventCount,
      detectedEventCount,
      matchedCount: comparison.matchedCount,
      visibleOnlyCount: comparison.visibleOnlyCount,
      decodedOnlyCount: comparison.decodedOnlyCount,
      invalidDecodedCount: comparison.invalidDecodedCount,
      titleDisagreementCount: comparison.titleDisagreementCount,
      replayOk: Boolean(replay?.ok),
      decodeOk: Boolean(decoded?.ok),
      code: suspicious ? "EVENT_AUDIT_MISMATCH" : "EVENT_AUDIT_MATCH"
    });

    allDecodedCompact.push(...decodedCompact);

    if (suspicious && mismatches.length < 10) {
      mismatches.push({
        week: { firstDate: targetWeek.firstDate, lastDate: targetWeek.lastDate },
        visibleWeek: visible?.week || null,
        replay: {
          ok: Boolean(replay?.ok),
          httpStatus: replay?.httpStatus ?? null,
          error: replay?.error || null,
          responseLength: responseText.length
        },
        decode: decoded ? {
          ok: Boolean(decoded.ok),
          code: decoded.code || null,
          message: decoded.message || null,
          expectedEventCount,
          detectedEventCount,
          markerCount: decoded?.gwt?.markerCount ?? null,
          medianColumnWidth: decoded?.geometry?.medianColumnWidth ?? null
        } : null,
        comparison: {
          visibleEventCount: comparison.visibleCount,
          decodedEventCount: comparison.decodedCount,
          matchedCount: comparison.matchedCount,
          visibleOnly: comparison.visibleOnly,
          decodedOnly: comparison.decodedOnly,
          invalidDecoded: comparison.invalidDecoded,
          titleDisagreements: comparison.titleDisagreements
        },
        visibleEvents: visibleEvents.map((event) => collectorAuditEventView(event, true)),
        decodedEvents: decodedEventsRaw.map((event) => collectorAuditEventView(event, true)),
        request: item ? {
          targetValue: item.targetValue,
          bodyLength: String(item.body || "").length,
          body: diagnosticText(item.body || "", 90000)
        } : null,
        responseText: diagnosticText(responseText, 140000)
      });
    }

    await storeSet({
      collectorEventAuditStatus: {
        state: "running",
        startedAt: null,
        resourceId,
        label: model.label || target.label,
        completedWeeks: index + 1,
        totalWeeks: targets.length,
        currentWeek: targetWeek.firstDate,
        mismatchCount: weekSummaries.filter((week) => week.code === "EVENT_AUDIT_MISMATCH").length
      }
    });

    if (index < targets.length - 1) {
      await collectorEnsureAdeInteractive(tab.id);
      const nextTarget = targets[index + 1];
      const kicked = await v3KickWeekInBestFrame(
        tab.id,
        "next",
        isoWeekNumber(nextTarget.firstDate),
        nextTarget.firstDate
      );
      if (!kicked?.ok) {
        weekSummaries.push({
          week: { firstDate: targets[index + 1].firstDate, lastDate: targets[index + 1].lastDate },
          code: "EVENT_AUDIT_NAVIGATION_FAILED",
          navigationCode: kicked?.code || null
        });
        break;
      }
      await sleep(520);
    }
  }

  const duplicates = collectorAuditDuplicateSummary(allDecodedCompact);
  const decodedUnique = deduplicateEvents(allDecodedCompact);
  const deduplicatedCount = decodedUnique.length;
  const storedData = await storeGet(["collectorResources"]);
  const storedResource = storedData.collectorResources?.[String(resourceId)] || null;
  const storedEvents = Array.isArray(storedResource?.payload?.events)
    ? storedResource.payload.events
    : [];
  const decodedByKey = new Map(decodedUnique.map((event) => [eventStableKey(event), event]));
  const storedByKey = new Map(storedEvents.map((event) => [eventStableKey(event), event]));
  const decodedNotStored = [...decodedByKey.entries()]
    .filter(([key]) => !storedByKey.has(key))
    .slice(0, 80)
    .map(([, event]) => collectorAuditEventView(event, true));
  const storedNotDecoded = [...storedByKey.entries()]
    .filter(([key]) => !decodedByKey.has(key))
    .slice(0, 80)
    .map(([, event]) => collectorAuditEventView(event, true));
  const overallStoredComparison = {
    decodedUniqueCount: decodedUnique.length,
    storedUniqueCount: storedByKey.size,
    decodedNotStoredCount: [...decodedByKey.keys()].filter((key) => !storedByKey.has(key)).length,
    storedNotDecodedCount: [...storedByKey.keys()].filter((key) => !decodedByKey.has(key)).length,
    decodedNotStored,
    storedNotDecoded
  };
  const mismatchCount = weekSummaries.filter((week) => week.code === "EVENT_AUDIT_MISMATCH").length;

  const auditRecord = {
    type: "collector-event-audit",
    code: mismatchCount ? "COLLECTOR_EVENT_AUDIT_MISMATCHES" : "COLLECTOR_EVENT_AUDIT_CLEAN",
    resourceId,
    label: model.label || target.label || null,
    path: model.path || target.path || null,
    academicYear: bounds?.academicYear || null,
    requestedWeekCount: targets.length,
    auditedWeekCount: weekSummaries.length,
    mismatchCount,
    replayFailureCount,
    decodedBeforeDedupCount: allDecodedCompact.length,
    decodedAfterDedupCount: deduplicatedCount,
    duplicateGroupCount: duplicates.length,
    duplicates,
    storedPayload: storedResource ? {
      eventCount: Number(storedResource?.payload?.eventCount ?? storedResource?.eventCount ?? 0),
      weekCount: Number(storedResource?.payload?.weekCount ?? storedResource?.weekCount ?? 0),
      verified: storedResource?.verified === true,
      collectionMode: storedResource?.collectionMode || null,
      consistencyMismatchCount: Number(storedResource?.consistencyMismatchCount || 0),
      updatedAt: storedResource?.updatedAt || null
    } : null,
    overallStoredComparison,
    weeks: weekSummaries,
    mismatches,
    note: "Les semaines EVENT_AUDIT_MISMATCH comparent directement les cours visibles dans ADE au décodage method10getTimetable utilisé par Planilim."
  };

  await appendCollectorDiagnostic(auditRecord);
  await storeSet({
    collectorEventAuditStatus: {
      state: "finished",
      finishedAt: nowIso(),
      ok: true,
      code: auditRecord.code,
      resourceId,
      label: auditRecord.label,
      completedWeeks: weekSummaries.length,
      totalWeeks: targets.length,
      mismatchCount,
      replayFailureCount
    }
  });

  return {
    ok: true,
    code: auditRecord.code,
    resourceId,
    label: auditRecord.label,
    auditedWeekCount: weekSummaries.length,
    requestedWeekCount: targets.length,
    mismatchCount,
    replayFailureCount,
    decodedBeforeDedupCount: allDecodedCompact.length,
    decodedAfterDedupCount: deduplicatedCount,
    storedEventCount: auditRecord.storedPayload?.eventCount ?? null,
    message: mismatchCount
      ? `${mismatchCount} semaine(s) présentent une différence entre ADE et le décodage Planilim. Exporte maintenant les diagnostics.`
      : "Aucune différence n'a été détectée entre le DOM ADE et le décodage sur les semaines auditées."
  };
}

async function collectorPrepareResources(message = {}) {
  const targets = (Array.isArray(message.targets) ? message.targets : [])
    .filter(item => item?.resourceId != null)
    .filter((item, index, items) => items.findIndex(other => Number(other.resourceId) === Number(item.resourceId)) === index);
  if (!targets.length) return { ok: false, code: "COLLECTOR_QUEUE_EMPTY" };

  if (message.reset !== false) await collectorClearPreparedModels();
  const results = [];
  for (let index = 0; index < targets.length; index += 1) {
    await storeSet({
      collectorState: {
        state: "preparing_models",
        phase: "capturing_models",
        completed: index,
        total: targets.length,
        resourceId: targets[index].resourceId,
        label: targets[index].label || null,
        startedAt: nowIso()
      }
    });
    const result = await collectorCaptureModel({ target: targets[index] });
    results.push({
      ok: Boolean(result?.ok),
      code: result?.code || null,
      resourceId: targets[index].resourceId,
      label: targets[index].label || null,
      path: targets[index].path || null
    });
    if (result?.code === "AUTH_REQUIRED") break;
  }
  const successCount = results.filter(x => x.ok).length;
  await storeSet({
    collectorState: {
      state: successCount === targets.length ? "models_ready" : "models_partial",
      phase: "capturing_models",
      completed: results.length,
      total: targets.length,
      successCount,
      finishedAt: nowIso()
    }
  });
  return {
    ok: successCount === targets.length,
    code: successCount === targets.length ? "COLLECTOR_MODELS_READY" : "COLLECTOR_MODELS_PARTIAL",
    successCount,
    total: targets.length,
    results
  };
}

async function collectorSyncPreparedResources(message = {}) {
  const requestedIds = Array.isArray(message.resourceIds) ? message.resourceIds.map(Number) : [];
  const models = await collectorPreparedModels();
  const selectedModels = requestedIds.length
    ? requestedIds.map(id => models[String(id)]).filter(Boolean)
    : Object.values(models);
  if (!selectedModels.length) return { ok: false, code: "COLLECTOR_MODELS_EMPTY" };

  const snapshot = await collectorTreeSnapshot();
  if (!snapshot?.ok) return snapshot;
  const tabId = snapshot.tabId;
  const resourceConcurrency = Math.max(1, Math.min(4, Number(message.resourceConcurrency) || COLLECTOR_RESOURCE_CONCURRENCY_DEFAULT));
  const weekConcurrency = Math.max(1, Math.min(8, Number(message.weekConcurrency) || COLLECTOR_WEEK_CONCURRENCY_DEFAULT));
  let cursor = 0;
  let completed = 0;
  let authRequired = false;
  const results = new Array(selectedModels.length);

  await storeSet({
    collectorState: {
      state: "downloading",
      phase: "parallel_download",
      completed: 0,
      total: selectedModels.length,
      resourceConcurrency,
      weekConcurrency,
      startedAt: nowIso()
    }
  });

  async function worker(workerIndex) {
    while (true) {
      if (authRequired) return;
      const index = cursor++;
      if (index >= selectedModels.length) return;
      const model = selectedModels[index];
      await storeSet({
        collectorState: {
          state: "downloading",
          phase: "parallel_download",
          completed,
          total: selectedModels.length,
          activeWorker: workerIndex + 1,
          resourceId: model.resourceId,
          label: model.label || null,
          resourceConcurrency,
          weekConcurrency,
          startedAt: nowIso()
        }
      });
      const result = await collectorSyncPreparedModel(tabId, model, { weekConcurrency, allowVisualFallback: false });
      results[index] = result;
      completed += 1;
      if (result?.code === "AUTH_REQUIRED") authRequired = true;
      await storeSet({
        collectorState: {
          state: authRequired ? "auth_required" : "downloading",
          phase: "parallel_download",
          completed,
          total: selectedModels.length,
          resourceId: model.resourceId,
          label: model.label || null,
          resourceConcurrency,
          weekConcurrency,
          updatedAt: nowIso()
        }
      });
    }
  }

  await Promise.all(Array.from({ length: Math.min(resourceConcurrency, selectedModels.length) }, (_, index) => worker(index)));

  // Aucun second passage visuel : une semaine vide reste simplement vide.
  const compact = results.filter(Boolean).map(result => ({
    ok: Boolean(result?.ok),
    code: result?.code || null,
    resourceId: result?.resourceId ?? null,
    label: result?.label || null,
    path: result?.path || null,
    eventCount: Number(result?.eventCount || 0),
    weekCount: Number(result?.weekCount || 0),
    failedWeekCount: Number(result?.failedWeekCount || 0)
  }));
  const successCount = compact.filter(x => x.ok).length;
  await storeSet({
    collectorState: {
      state: authRequired ? "auth_required" : (successCount === compact.length ? "ready" : "partial"),
      phase: "parallel_download",
      completed: compact.length,
      total: selectedModels.length,
      successCount,
      finishedAt: nowIso(),
      resourceConcurrency,
      weekConcurrency
    }
  });
  return {
    ok: !authRequired && successCount === compact.length,
    code: authRequired ? "AUTH_REQUIRED" : (successCount === compact.length ? "COLLECTOR_PREPARED_SYNCED" : "COLLECTOR_PREPARED_PARTIAL"),
    successCount,
    total: selectedModels.length,
    results: compact
  };
}

async function collectorSyncFastSequential(message = {}) {
  const targets = (Array.isArray(message.targets) ? message.targets : [])
    .filter(item => item?.resourceId != null)
    .filter((item, index, items) =>
      items.findIndex(other => Number(other.resourceId) === Number(item.resourceId)) === index
    );
  if (!targets.length) return { ok: false, code: "COLLECTOR_QUEUE_EMPTY", results: [] };

  const snapshot = await collectorTreeSnapshot();
  if (!snapshot?.ok) return snapshot;
  const tabId = snapshot.tabId;
  const weekConcurrency = Math.max(1, Math.min(8, Number(message.weekConcurrency) || 8));
  const results = [];
  let authRequired = false;

  await storeSet({
    collectorState: {
      state: "syncing",
      phase: "sequential_fast",
      completed: 0,
      total: targets.length,
      weekConcurrency,
      startedAt: nowIso()
    }
  });

  for (let index = 0; index < targets.length; index += 1) {
    const target = targets[index];
    await storeSet({
      collectorState: {
        state: "syncing",
        phase: "sequential_fast",
        completed: index,
        total: targets.length,
        resourceId: target.resourceId,
        label: target.label || null,
        weekConcurrency,
        updatedAt: nowIso()
      }
    });

    let compactResult;
    try {
      const built = await collectorBuildModelForTarget(tabId, target);
      if (!built?.ok || !built.model) {
        compactResult = {
          ok: false,
          code: built?.code || "MODEL_CAPTURE_FAILED",
          resourceId: Number(target.resourceId),
          label: target.label || null,
          path: target.path || null,
          eventCount: 0,
          weekCount: 0,
          failedWeekCount: 0,
          message: built?.message || null
        };
      } else {
        const synced = await collectorSyncPreparedModel(tabId, built.model, {
          weekConcurrency,
          allowVisualFallback: false
        });
        compactResult = {
          ok: Boolean(synced?.ok),
          code: synced?.code || null,
          resourceId: synced?.resourceId ?? Number(target.resourceId),
          label: synced?.label || target.label || null,
          path: synced?.path || target.path || null,
          eventCount: Number(synced?.eventCount || 0),
          weekCount: Number(synced?.weekCount || 0),
          failedWeekCount: Number(synced?.failedWeekCount || 0),
          message: synced?.message || null
        };
        if (synced?.code === "AUTH_REQUIRED" || synced?.authRequired) authRequired = true;
      }
    } catch (error) {
      compactResult = {
        ok: false,
        code: "COLLECTOR_FAST_RESOURCE_EXCEPTION",
        resourceId: Number(target.resourceId),
        label: target.label || null,
        path: target.path || null,
        eventCount: 0,
        weekCount: 0,
        failedWeekCount: 0,
        message: String(error)
      };
    }

    results.push(compactResult);

    await storeSet({
      collectorState: {
        state: authRequired ? "auth_required" : "syncing",
        phase: "sequential_fast",
        completed: index + 1,
        total: targets.length,
        resourceId: target.resourceId,
        label: target.label || null,
        weekConcurrency,
        updatedAt: nowIso()
      }
    });

    if (authRequired) break;
  }

  const successCount = results.filter(item => item?.ok).length;
  await storeSet({
    collectorState: {
      state: authRequired ? "auth_required" : (successCount === results.length ? "ready" : "partial"),
      phase: "sequential_fast",
      completed: results.length,
      total: targets.length,
      successCount,
      weekConcurrency,
      finishedAt: nowIso()
    }
  });

  return {
    ok: !authRequired && successCount === results.length,
    code: authRequired ? "AUTH_REQUIRED" : (successCount === results.length ? "COLLECTOR_FAST_SYNCED" : "COLLECTOR_FAST_PARTIAL"),
    successCount,
    total: targets.length,
    results
  };
}

async function collectorSyncResource(message = {}) {
  const target = message.target || message.resource || message;
  const snapshot = await collectorTreeSnapshot();
  if (!snapshot.ok) return snapshot;

  const resource = target?.resourceId != null || target?.path || target?.label
    ? target
    : snapshot.selected;
  if (!resource?.resourceId) {
    return {
      ok: false,
      code: "COLLECTOR_RESOURCE_MISSING",
      message: "Aucun emploi du temps ADE identifiable n'est sélectionné."
    };
  }

  await collectorEnsureAdeInteractive(snapshot.tabId);

  await storeSet({
    collectorState: {
      state: "selecting",
      startedAt: nowIso(),
      resourceId: resource.resourceId,
      label: resource.label || null,
      path: resource.path || null
    }
  });

  const selection = await collectorSelectResource(snapshot.tabId, resource);
  if (!selection.ok) {
    await storeSet({
      collectorState: {
        state: "failed",
        finishedAt: nowIso(),
        code: selection.code,
        resourceId: resource.resourceId
      }
    });
    return selection;
  }

  const ready = await collectorWaitForResourceSelection(
    snapshot.tabId,
    resource.resourceId
  );
  if (!ready.ok) {
    await storeSet({
      collectorState: {
        state: "failed",
        finishedAt: nowIso(),
        code: ready.code,
        resourceId: resource.resourceId,
        label: resource.label || null,
        path: resource.path || null
      }
    });
    return ready;
  }

  const selectedResource = {
    ...resource,
    ...(selection.resource || {}),
    // Le snapshot virtualisé visible après le clic peut ne contenir que les
    // derniers parents. On conserve donc le chemin complet découvert avant.
    label: resource.label || selection.resource?.label || null,
    path: resource.path || selection.resource?.path || null
  };
  const preview = ready.preview || await v3ScrapePlanningPreview(snapshot.tabId);
  const selectedVisibleWeek = weekResultFromScrapedPreview(
    preview,
    "WEEK_SCRAPED_FROM_SELECTED_RESOURCE"
  );

  await chrome.storage.local.remove(["academicSyncCache", "academicSyncStatus"]);
  await storeSet({
    v3SetupState: {
      state: "detected",
      detectedAt: nowIso(),
      tabId: snapshot.tabId,
      resourceId: selectedResource.resourceId,
      planningLabel: selectedResource.label || preview?.planningLabel || null,
      planningPath: selectedResource.path || null,
      week: preview?.week || null,
      previewEventCount: Array.isArray(preview?.events) ? preview.events.length : 0,
      message: "Formation détectée. Synchronisation automatique en cours."
    },
    collectorState: {
      state: "syncing",
      startedAt: nowIso(),
      resourceId: selectedResource.resourceId,
      label: selectedResource.label || null,
      path: selectedResource.path || null
    }
  });

  await collectorEnsureAdeInteractive(snapshot.tabId);
  let sync = await v3StableFullSync({ notifyUser: false, preserveTab: true, weekConcurrency: 4, delayMs: 35 });

  if (!sync?.ok) {
    await storeSet({
      collectorState: {
        state: sync?.code === "AUTH_REQUIRED" ? "auth_required" : "failed",
        finishedAt: nowIso(),
        code: sync?.code || "COLLECTOR_SYNC_FAILED",
        resourceId: selectedResource.resourceId,
        label: selectedResource.label || null,
        path: selectedResource.path || null
      }
    });
    return { ...sync, resource: selectedResource };
  }

  await collectorMergeWeekOverrides(
    selectedVisibleWeek ? [selectedVisibleWeek] : []
  );

  await storeSet({
    collectorState: {
      state: "finalizing",
      phase: "building_payload",
      startedAt: nowIso(),
      resourceId: selectedResource.resourceId,
      label: selectedResource.label || null,
      path: selectedResource.path || null
    }
  });

  let payloadResult = await academicYearPlanilimPayload();


  if (!payloadResult?.ok || !payloadResult?.payload) {
    await storeSet({
      collectorState: {
        state: "failed",
        phase: "building_payload",
        finishedAt: nowIso(),
        code: payloadResult?.code || "COLLECTOR_PAYLOAD_MISSING",
        resourceId: selectedResource.resourceId,
        label: selectedResource.label || null,
        path: selectedResource.path || null
      }
    });
    return payloadResult;
  }

  const payload = {
    ...payloadResult.payload,
    resource: {
      id: selectedResource.resourceId,
      label: selectedResource.label || payloadResult.payload.resource?.label || null,
      path: selectedResource.path || payloadResult.payload.resource?.path || null
    }
  };
  const data = await storeGet(["collectorResources"]);
  const resources = data.collectorResources || {};
  resources[String(selectedResource.resourceId)] = {
    resourceId: selectedResource.resourceId,
    label: selectedResource.label || null,
    path: selectedResource.path || null,
    academicYear: payload.academicYear || null,
    eventCount: payload.eventCount || payload.events?.length || 0,
    weekCount: payload.weekCount || 0,
    updatedAt: nowIso(),
    payload
  };

  await storeSet({
    collectorResources: resources,
    collectorState: {
      state: "ready",
      finishedAt: nowIso(),
      resourceId: selectedResource.resourceId,
      label: selectedResource.label || null,
      path: selectedResource.path || null,
      eventCount: payload.eventCount || payload.events?.length || 0,
      weekCount: payload.weekCount || 0
    }
  });

  return {
    ok: true,
    code: "COLLECTOR_RESOURCE_SYNCED",
    resource: selectedResource,
    sync,
    payload
  };
}

async function collectorSyncResources(message = {}) {
  const requested = Array.isArray(message.targets) ? message.targets : [];
  const targets = requested
    .filter((item) => item?.resourceId != null)
    .filter((item, index, items) =>
      items.findIndex((other) => Number(other.resourceId) === Number(item.resourceId)) === index
    );
  if (!targets.length) {
    return {
      ok: false,
      code: "COLLECTOR_QUEUE_EMPTY",
      message: "Choisissez au moins une formation à synchroniser."
    };
  }

  const initial = await collectorTreeSnapshot();
  if (!initial.ok) return initial;
  const original = initial.selected || null;
  const results = [];

  for (let index = 0; index < targets.length; index += 1) {
    await storeSet({
      collectorState: {
        state: "syncing_queue",
        startedAt: nowIso(),
        completed: index,
        total: targets.length,
        resourceId: targets[index].resourceId,
        label: targets[index].label || null
      }
    });
    const result = await collectorSyncResource({ target: targets[index] });
    results.push({
      ok: Boolean(result?.ok),
      code: result?.code || null,
      resourceId: targets[index].resourceId,
      label: targets[index].label || null
    });
    if (result?.code === "AUTH_REQUIRED") break;
  }

  if (original?.resourceId) {
    await collectorSelectResource(initial.tabId, original).catch(() => {});
  }

  const successCount = results.filter((item) => item.ok).length;
  const finalState = {
    state: successCount === targets.length ? "ready" : "partial",
    finishedAt: nowIso(),
    completed: results.length,
    total: targets.length,
    successCount
  };
  await storeSet({ collectorState: finalState });

  return {
    ok: successCount === targets.length,
    code: successCount === targets.length
      ? "COLLECTOR_QUEUE_SYNCED"
      : "COLLECTOR_QUEUE_PARTIAL",
    successCount,
    total: targets.length,
    results
  };
}

async function collectorPayloads() {
  const data = await storeGet(["collectorResources", "collectorState"]);
  return {
    ok: true,
    code: "COLLECTOR_PAYLOADS_READY",
    state: data.collectorState || null,
    resources: Object.values(data.collectorResources || {})
  };
}

async function waitTab(tabId, timeoutMs = 25000) {
  const started = Date.now();

  while (Date.now() - started < timeoutMs) {
    const tab = await chrome.tabs.get(tabId);

    if (tab.status === "complete") return tab;

    await sleep(250);
  }

  throw new Error("ADE a mis trop de temps à charger.");
}

async function openFreshAde() {
  const tab = await chrome.tabs.create({
    url: ADE_URL,
    active: false
  });

  await waitTab(tab.id);
  await sleep(3000);

  return tab;
}

async function scrapeVisibleWeek(tabId) {
  async function collectFrameResults() {
    let frames = [];

    try {
      frames =
        await chrome.webNavigation.getAllFrames({
          tabId
        }) || [];
    } catch {}

    if (!frames.length) {
      frames = [
        {
          frameId: 0,
          url: ""
        }
      ];
    }

    const results = [];

    for (const frame of frames) {
      try {
        const result =
          await chrome.tabs.sendMessage(
            tabId,
            {
              type: "PLANILIM_SCRAPE_ADE"
            },
            {
              frameId: frame.frameId
            }
          );

        if (!result) continue;

        results.push({
          ...result,
          frameId:
            frame.frameId,
          frameUrl:
            frame.url || result?.diagnostics?.href || ""
        });
      } catch {}
    }

    return results;
  }

  function score(result) {
    const eventCount =
      Number(
        result?.events?.length ||
        result?.diagnostics?.eventCount ||
        0
      );

    const dayHeaderCount =
      Number(
        result?.diagnostics?.dayHeaderCount ||
        0
      );

    let value =
      eventCount * 1000 +
      dayHeaderCount * 10;

    if (result?.ok) {
      value += 100000;
    }

    const href =
      String(
        result?.frameUrl ||
        result?.diagnostics?.href ||
        ""
      );

    if (
      href.includes(
        "/direct/myplanning.jsp"
      )
    ) {
      value += 500;
    }

    if (
      href.includes(
        ".cache.html"
      )
    ) {
      value -= 500;
    }

    return value;
  }

  let results =
    await collectFrameResults();

  if (!results.length) {
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId,
          allFrames: true
        },
        files: ["ade-tree.js", "ade-content.js"]
      });

      await sleep(300);

      results =
        await collectFrameResults();
    } catch {}
  }

  if (!results.length) {
    return {
      ok: false,
      code: "SCRAPER_UNAVAILABLE",
      events: [],
      diagnostics: {
        frameCount: 0
      }
    };
  }

  results.sort(
    (a, b) =>
      score(b) - score(a)
  );

  const best = results[0];

  return {
    ...best,
    diagnostics: {
      ...(best?.diagnostics || {}),
      selectedFrameId:
        best?.frameId ?? null,
      selectedFrameUrl:
        best?.frameUrl || null,
      candidateFrames:
        results.map((result) => ({
          frameId:
            result?.frameId ?? null,
          href:
            result?.frameUrl ||
            result?.diagnostics?.href ||
            null,
          ok:
            Boolean(result?.ok),
          dayHeaderCount:
            Number(
              result?.diagnostics?.dayHeaderCount ||
              0
            ),
          eventCount:
            Number(
              result?.events?.length ||
              result?.diagnostics?.eventCount ||
              0
            ),
          score:
            score(result)
        }))
    }
  };
}

function requestTemplateFromCapture(capture) {
  return {
    method: String(capture?.method || "POST"),
    url: String(capture?.url || ""),
    headers: {
      "content-type": String(
        capture?.headers?.["content-type"] ||
          "text/x-gwt-rpc; charset=UTF-8"
      ),
      "x-gwt-module-base": String(
        capture?.headers?.["x-gwt-module-base"] ||
          ""
      ),
      "x-gwt-permutation": String(
        capture?.headers?.["x-gwt-permutation"] ||
          ""
      )
    },
    body: String(capture?.body || "")
  };
}

async function replayInPage(tabId, template) {
  const results = await chrome.scripting.executeScript({
    target: {
      tabId,
      frameIds: [0]
    },
    world: "MAIN",
    func: (request) =>
      new Promise((resolve) => {
        try {
          const xhr = new XMLHttpRequest();

          xhr.open(
            request.method || "POST",
            request.url,
            true
          );

          xhr.withCredentials = true;
          xhr.timeout = Number(request.timeoutMs || 10000);

          for (
            const [name, value]
            of Object.entries(request.headers || {})
          ) {
            if (!value) continue;

            try {
              xhr.setRequestHeader(name, value);
            } catch {}
          }

          xhr.onloadend = () => {
            let responseText = "";

            try {
              responseText =
                typeof xhr.responseText === "string"
                  ? xhr.responseText
                  : "";
            } catch {}

            resolve({
              ok:
                xhr.status >= 200 &&
                xhr.status < 300,
              httpStatus: Number(xhr.status || 0),
              responseURL: String(xhr.responseURL || ""),
              responseText
            });
          };

          const fail = (reason) => {
            resolve({
              ok: false,
              httpStatus: Number(xhr.status || 0),
              responseURL: String(xhr.responseURL || ""),
              responseText: "",
              error: reason
            });
          };

          xhr.onerror = () => fail("XHR_ERROR");
          xhr.ontimeout = () => fail("XHR_TIMEOUT");
          xhr.onabort = () => fail("XHR_ABORTED");

          xhr.send(String(request.body || ""));
        } catch (error) {
          resolve({
            ok: false,
            httpStatus: 0,
            responseURL: "",
            responseText: "",
            error: String(error)
          });
        }
      }),
    args: [template]
  });

  return results?.[0]?.result || {
    ok: false,
    httpStatus: 0,
    responseText: "",
    error: "Aucun résultat de script."
  };
}


chrome.webNavigation.onCompleted.addListener(
  (details) => {
    if (details.frameId !== 0) return;
    if (!String(details.url || "").includes("planning.unilim.fr/direct/myplanning.jsp")) return;

    storeGet(["v3SetupState"])
      .then((data) => {
        const setup = data.v3SetupState;
        if (!["waiting_for_ade", "waiting_for_login"].includes(setup?.state)) return;
        if (Number.isInteger(setup?.tabId) && setup.tabId !== details.tabId) return;

        setTimeout(() => {
          tryDetectV3Setup().catch(() => {});
        }, 700);
        setTimeout(() => {
          tryDetectV3Setup().catch(() => {});
        }, 1800);
      })
      .catch(() => {});
  }
);

chrome.tabs.onRemoved.addListener((tabId) => {
  v3MarkSelectedTabClosed(tabId).catch(() => {});
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const body = decodeRequestBody(details.requestBody);

    if (!body) return;

    const entry =
      compactRequestEntry(
        details,
        body
      );

    appendWeekTraceRequest(
      entry
    ).catch(() => {});

    appendV3PassiveRequest(
      entry
    ).catch(() => {});
  },
  TRACE_FILTER,
  ["requestBody"]
);

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const body = decodeRequestBody(details.requestBody);

    if (
      !body ||
      !body.includes("method10getTimetable")
    ) {
      return;
    }

    pendingRequests.set(
      details.requestId,
      {
        capturedAt: Date.now(),
        tabId: details.tabId,
        frameId: details.frameId,
        method: String(details.method || "POST"),
        url: String(details.url || ""),
        body,
        resourceId: extractResourceId(body),
        headers: {}
      }
    );
  },
  RPC_FILTER,
  ["requestBody"]
);

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const capture = pendingRequests.get(details.requestId);
    if (!capture) return;

    capture.headers = pickSafeHeaders(details.requestHeaders);
    capture.capturedAt = Date.now();

    pendingRequests.delete(details.requestId);

    if (capture.tabId != null && capture.resourceId != null) {
      const key = `${Number(capture.tabId)}:${Number(capture.resourceId)}`;
      collectorRecentTimetableCaptures.set(key, { ...capture });
      if (collectorRecentTimetableCaptures.size > 400) {
        const cutoff = Date.now() - 10 * 60 * 1000;
        for (const [entryKey, entry] of collectorRecentTimetableCaptures) {
          if (Number(entry?.capturedAt || 0) < cutoff) collectorRecentTimetableCaptures.delete(entryKey);
        }
      }
    }

    appendCaptureHistory(capture).catch(() => {});

    storeGet(["v3SetupState"])
      .then((data) => {
        const state =
          data.v3SetupState?.state;

        if (
          state === "waiting_for_ade" ||
          state === "bootstrapping" ||
          state === "waiting_for_login"
        ) {
          setTimeout(
            () => {
              tryDetectV3Setup()
                .catch(() => {});
            },
            1200
          );
        }
      })
      .catch(() => {});
  },
  RPC_FILTER,
  [
    "requestHeaders",
    "extraHeaders"
  ]
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    pendingRequests.delete(details.requestId);
  },
  RPC_FILTER
);

async function saveProfile() {
  const tab =
    await bestAdeTab();

  if (!tab) {
    return {
      ok: false,
      code: "ADE_NOT_OPEN",
      message:
        "Ouvre ADE avant de revalider le profil RPC."
    };
  }

  const data =
    await storeGet([
      "latestTimetableRequest",
      "savedProfile",
      "cachedCurrentWeek"
    ]);

  const existingProfile =
    data.savedProfile || null;

  const latest =
    data.latestTimetableRequest || null;

  let capture =
    latest;

  let captureSource =
    "fresh-network-capture";

  if (capture) {
    const ageMs =
      Date.now() -
      Number(
        capture.capturedAt || 0
      );

    if (
      ageMs > 5 * 60 * 1000 &&
      existingProfile?.rpcTemplate
    ) {
      capture = null;
    } else if (
      ageMs > 5 * 60 * 1000
    ) {
      return {
        ok: false,
        code: "GETTIMETABLE_CAPTURE_TOO_OLD",
        message:
          "Le dernier getTimetable capturé a plus de 5 minutes. Change une fois de semaine puis réessaie.",
        capturedAt:
          latest.capturedAt
      };
    }
  }

  if (
    !capture &&
    existingProfile?.rpcTemplate
  ) {
    captureSource =
      "existing-profile";

    capture = {
      capturedAt:
        Date.now(),
      method:
        existingProfile.rpcTemplate.method,
      url:
        existingProfile.rpcTemplate.url,
      body:
        existingProfile.rpcTemplate.body,
      headers:
        existingProfile.rpcTemplate.headers || {},
      resourceId:
        existingProfile.resourceId ?? null
    };
  }

  if (!capture) {
    return {
      ok: false,
      code: "GETTIMETABLE_NOT_CAPTURED",
      message:
        "Aucun profil RPC ni getTimetable récent n'est disponible. Recharge ADE puis change une fois de semaine."
    };
  }

  const scrape =
    await scrapeVisibleWeek(
      tab.id
    );

  const scrapeReadable =
    Boolean(
      scrape?.ok &&
      scrape?.events?.length
    );

  const sampleEvents =
    scrapeReadable
      ? scrape.events
      : (
          existingProfile?.sampleEvents ||
          data.cachedCurrentWeek?.events ||
          []
        );

  const sampleWeek =
    scrapeReadable
      ? scrape.week
      : (
          existingProfile?.sampleWeek ||
          data.cachedCurrentWeek?.week ||
          null
        );

  const template =
    requestTemplateFromCapture(
      capture
    );

  const replay =
    await replayInPage(
      tab.id,
      template
    );

  const validation =
    replaySummary(
      replay,
      sampleEvents
    );

  if (!validation.ok) {
    return {
      ok: false,
      code: "CAPTURE_REPLAY_NOT_VALID",
      message:
        "Le getTimetable existe, mais son rejeu serveur n'a pas été validé.",
      captureSource,
      scrapeReadable,
      scrapeDiagnostics:
        scrape?.diagnostics || null,
      replay:
        validation
    };
  }

  const resourceId =
    capture.resourceId ??
    existingProfile?.resourceId ??
    extractResourceId(
      capture.body
    ) ??
    null;

  const profile = {
    savedAt:
      nowIso(),
    mode:
      "webrequest-gwt-replay",
    resourceId,
    rpcTemplate:
      template,
    sampleWeek,
    sampleEvents,
    autoSyncEnabled:
      true
  };

  const valuesToStore = {
    savedProfile:
      profile,
    lastSuccessfulSyncAt:
      nowIso(),
    lastImmediateReplay: {
      testedAt:
        nowIso(),
      summary:
        validation,
      responseText:
        String(
          replay.responseText || ""
        )
    }
  };

  if (scrapeReadable) {
    valuesToStore.cachedCurrentWeek = {
      syncedAt:
        nowIso(),
      week:
        scrape.week,
      events:
        scrape.events
    };
  }

  await storeSet(
    valuesToStore
  );

  await chrome.alarms.create(
    ALARM_NAME,
    {
      periodInMinutes:
        AUTO_SYNC_MINUTES
    }
  );

  return {
    ok: true,
    code: scrapeReadable
      ? "PROFILE_SAVED"
      : "PROFILE_SAVED_RPC_ONLY",
    message: scrapeReadable
      ? "Profil RPC enregistré et rejeu immédiat validé. Le planning visible a aussi été lu correctement."
      : "Profil RPC enregistré et rejeu serveur validé. La lecture visuelle ADE était indisponible, mais elle n'est plus bloquante.",
    captureSource,
    scrapeReadable,
    profile: {
      mode:
        profile.mode,
      resourceId:
        profile.resourceId,
      sampleWeek:
        profile.sampleWeek,
      sampleEventCount:
        profile.sampleEvents.length,
      requestBodyLength:
        profile.rpcTemplate.body.length
    },
    scrapeDiagnostics:
      scrape?.diagnostics || null,
    replayValidation:
      validation
  };
}
async function autonomousTest() {
  const data = await storeGet(["savedProfile"]);
  const profile = data.savedProfile;

  const startedAt = nowIso();

  await storeSet({
    lastAutonomyTest: {
      state: "running",
      startedAt,
      finishedAt: null,
      ok: null,
      code: "RUNNING",
      message:
        "Ouverture d'une page ADE fraîche puis rejeu direct de getTimetable."
    }
  });

  if (
    !profile?.rpcTemplate ||
    profile.mode !== "webrequest-gwt-replay"
  ) {
    const result = {
      state: "finished",
      startedAt,
      finishedAt: nowIso(),
      ok: false,
      code: "NO_V16_PROFILE",
      message:
        "Refais l'enregistrement avec la v1.6 avant de lancer le test autonome."
    };

    await storeSet({ lastAutonomyTest: result });
    return result;
  }

  let testTab = null;

  try {
    testTab = await openFreshAde();

    const replay = await replayInPage(
      testTab.id,
      profile.rpcTemplate
    );

    const summary = replaySummary(
      replay,
      profile.sampleEvents || []
    );

    const ok = replayAccepted(profile, summary);

    const result = {
      state: "finished",
      startedAt,
      finishedAt: nowIso(),
      ok,
      code: ok
        ? "AUTONOMY_OK"
        : "AUTONOMOUS_REPLAY_FAILED",
      message: ok
        ? "Page ADE fraîche validée : getTimetable a été rejoué sans clic, sans recherche et sans ouverture de dossier."
        : "La page ADE fraîche s'est ouverte, mais le rejeu getTimetable n'a pas été confirmé.",
      method: "fresh-tab-gwt-replay",
      resourceId: profile.resourceId,
      replay: summary
    };

    await storeSet({
      lastAutonomyTest: result,
      lastAutonomyRawResponse: String(replay.responseText || ""),
      lastSuccessfulSyncAt: ok
        ? nowIso()
        : data.lastSuccessfulSyncAt || null,
      lastReplayDiagnostics: summary
    });

    return result;
  } catch (error) {
    const result = {
      state: "finished",
      startedAt,
      finishedAt: nowIso(),
      ok: false,
      code: "AUTONOMY_EXCEPTION",
      message: String(error),
      method: "fresh-tab-gwt-replay"
    };

    await storeSet({
      lastAutonomyTest: result
    });

    return result;
  } finally {
    if (testTab?.id) {
      try {
        await chrome.tabs.remove(testTab.id);
      } catch {}
    }
  }
}

async function syncNow() {
  const data = await storeGet(["savedProfile"]);
  const profile = data.savedProfile;

  if (!profile?.rpcTemplate) {
    return {
      ok: false,
      code: "NO_REPLAY_PROFILE",
      message:
        "Aucun profil RPC n'est enregistré."
    };
  }

  let testTab = null;

  try {
    testTab = await openFreshAde();

    const replay = await replayInPage(
      testTab.id,
      profile.rpcTemplate
    );

    const summary = replaySummary(
      replay,
      profile.sampleEvents || []
    );

    const ok = replayAccepted(profile, summary);

    const result = {
      testedAt: nowIso(),
      ok,
      code: ok
        ? "SYNC_OK"
        : "SYNC_REPLAY_FAILED",
      message: ok
        ? "getTimetable a été rejoué avec succès dans une page ADE fraîche."
        : "Le rejeu getTimetable n'a pas été confirmé.",
      method: "fresh-tab-gwt-replay",
      replay: summary
    };

    await storeSet({
      lastSyncResult: result,
      lastSyncRawResponse: String(replay.responseText || ""),
      lastSuccessfulSyncAt: ok
        ? nowIso()
        : data.lastSuccessfulSyncAt || null
    });

    return result;
  } finally {
    if (testTab?.id) {
      try {
        await chrome.tabs.remove(testTab.id);
      } catch {}
    }
  }
}

async function diagnostics() {
  const data = await storeGet([
    "savedProfile",
    "timetableRequestHistory",
    "latestTimetableRequest",
    "lastAutonomyTest",
    "lastAutonomyRawResponse",
    "lastImmediateReplay",
    "lastSyncResult",
    "lastSyncRawResponse"
  ]);

  const history = Array.isArray(data.timetableRequestHistory)
    ? data.timetableRequestHistory
    : [];

  const lastTwo =
    history.length >= 2
      ? history.slice(-2)
      : [];

  const rawResponse =
    String(
      data.lastAutonomyRawResponse ||
      data.lastSyncRawResponse ||
      data.lastImmediateReplay?.responseText ||
      ""
    );

  return {
    ok: true,
    generatedAt: nowIso(),
    profile: data.savedProfile
      ? {
          mode: data.savedProfile.mode,
          resourceId: data.savedProfile.resourceId,
          sampleWeek: data.savedProfile.sampleWeek,
          sampleEventCount:
            data.savedProfile.sampleEvents?.length || 0,
          requestBodyLength:
            String(data.savedProfile.rpcTemplate?.body || "").length
        }
      : null,
    requestHistory: {
      count: history.length,
      recent: history.slice(-6).map((item) => ({
        capturedAt: item.capturedAt,
        resourceId: item.resourceId,
        bodyLength: String(item.body || "").length,
        tokenCount: String(item.body || "").split("|").length
      })),
      lastTwoDiff:
        lastTwo.length === 2
          ? compareRequestBodies(lastTwo[0], lastTwo[1])
          : null
    },
    lastAutonomyTest: data.lastAutonomyTest || null,
    lastSyncResult: data.lastSyncResult || null,
    gwtResponse: {
      analysis: analyzeGwtResponse(rawResponse),
      rawResponse
    }
  };
}


function planningLabelFromProfile(profile) {
  if (!profile) return null;
  if (profile.planningLabel) return profile.planningLabel;
  const resourceId = profile.resourceId ?? null;
  const week = profile.sampleWeek || null;
  const bits = [];
  if (resourceId != null) bits.push(`Planning #${resourceId}`);
  if (week?.firstDate) bits.push(`semaine du ${week.firstDate}`);
  return bits.join(" · ") || null;
}

async function notifyManualSyncSuccess(result) {
  try {
    if (!result?.ok || !chrome.notifications?.create) return;
    const data = await storeGet(["academicSyncCache"]);
    const count = Array.isArray(data.academicSyncCache?.events)
      ? data.academicSyncCache.events.length
      : null;
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icon128.png",
      title: "Synchronisation terminée",
      message: count != null
        ? `${count} cours ont été synchronisés. Vous pouvez fermer ADE.`
        : "Votre emploi du temps a été synchronisé. Vous pouvez fermer ADE.",
      priority: 1
    });
  } catch {}
}

async function status() {
  const data = await storeGet([
    "savedProfile",
    "latestTimetableRequest",
    "lastSuccessfulSyncAt",
    "lastAutonomyTest",
    "timetableRequestHistory",
    "weekTraceActive",
    "weekTraces",
    "predictedNextWeek",
    "lastPredictedWeekValidation",
    "weekBatchStatus",
    "generatedWeekBatch",
    "lastRealWeekCalibration",
    "fullSequencePrediction",
    "lastFullSequenceValidation",
    "decodedPredictedWeek",
    "lastSquareEventDecoderValidation",
    "decodedBatchStatus",
    "decodedWeekBatch",
    "academicSyncStatus",
    "academicSyncCache",
    "v3SetupState",
    "v3RuntimeBase",
    "v3SyncState",
    "v3PassiveEntries",
    "collectorState",
    "collectorResources",
    COLLECTOR_DIAGNOSTICS_KEY
  ]);

  const latest = data.latestTimetableRequest;
  const history = Array.isArray(data.timetableRequestHistory)
    ? data.timetableRequestHistory
    : [];
  const openAdeTabs = await adeTabs();
  const selectedTabId = Number.isInteger(data.v3SetupState?.tabId)
    ? data.v3SetupState.tabId
    : null;
  const selectedAdeOpen = selectedTabId === null
    ? null
    : Boolean(await chrome.tabs.get(selectedTabId).catch(() => null));

  const diagnosticLog = data[COLLECTOR_DIAGNOSTICS_KEY] || null;

  return {
    ok: true,
    version: chrome.runtime.getManifest().version,
    adeOpen: openAdeTabs.length > 0,
    selectedAdeOpen,
    diagnostics: {
      count: Array.isArray(diagnosticLog?.entries) ? diagnosticLog.entries.length : 0,
      hasSuccessReference: Boolean(diagnosticLog?.successReference),
      updatedAt: diagnosticLog?.updatedAt || null
    },
    storage: {
      unlimitedStorage: Array.isArray(chrome.runtime.getManifest().permissions)
        ? chrome.runtime.getManifest().permissions.includes("unlimitedStorage")
        : false
    },
    collector: {
      state: data.collectorState || null,
      resourceCount: Object.keys(data.collectorResources || {}).length,
      resources: Object.values(data.collectorResources || {}).map((item) => ({
        resourceId: item.resourceId,
        label: item.label || null,
        path: item.path || null,
        academicYear: item.academicYear || null,
        eventCount: item.eventCount || 0,
        weekCount: item.weekCount || 0,
        updatedAt: item.updatedAt || null
      }))
    },
    networkCapture: latest
      ? {
          capturedAt: latest.capturedAt,
          resourceId: latest.resourceId,
          bodyLength: String(latest.body || "").length,
          headers: latest.headers || {}
        }
      : null,
    requestHistoryCount: history.length,
    weekTraceActive: Boolean(data.weekTraceActive),
    savedWeekTraceCount: Array.isArray(data.weekTraces)
      ? data.weekTraces.length
      : 0,
    predictedNextWeek: data.predictedNextWeek
      ? {
          ok: data.predictedNextWeek.ok,
          generatedAt: data.predictedNextWeek.generatedAt,
          sourceWeek: data.predictedNextWeek.sourceWeek,
          predictedWeek: data.predictedNextWeek.predictedWeek,
          detectedParameter: data.predictedNextWeek.detectedParameter
        }
      : null,
    lastPredictedWeekValidation:
      data.lastPredictedWeekValidation || null,
    weekBatchStatus:
      data.weekBatchStatus || null,
    generatedWeekBatchSummary:
      data.generatedWeekBatch
        ? {
            generatedAt:
              data.generatedWeekBatch.generatedAt,
            requestedWeeks:
              data.generatedWeekBatch.requestedWeeks,
            successCount:
              data.generatedWeekBatch.successCount
          }
        : null,
    lastRealWeekCalibration:
      data.lastRealWeekCalibration || null,
    fullSequencePrediction:
      data.fullSequencePrediction
        ? {
            generatedAt:
              data.fullSequencePrediction.generatedAt,
            ok:
              data.fullSequencePrediction.ok,
            targetWeek:
              data.fullSequencePrediction.targetWeek,
            timetable:
              data.fullSequencePrediction.timetable
          }
        : null,
    lastFullSequenceValidation:
      data.lastFullSequenceValidation || null,
    decodedPredictedWeek:
      data.decodedPredictedWeek
        ? {
            ok:
              data.decodedPredictedWeek.ok,
            generatedAt:
              data.decodedPredictedWeek.generatedAt,
            week:
              data.decodedPredictedWeek.week,
            eventCount:
              Array.isArray(
                data.decodedPredictedWeek.events
              )
                ? data.decodedPredictedWeek.events.length
                : 0
          }
        : null,
    lastSquareEventDecoderValidation:
      data.lastSquareEventDecoderValidation || null,
    decodedBatchStatus:
      data.decodedBatchStatus || null,
    decodedWeekBatchSummary:
      data.decodedWeekBatch
        ? {
            generatedAt:
              data.decodedWeekBatch.generatedAt,
            requestedWeeks:
              data.decodedWeekBatch.requestedWeeks,
            successCount:
              data.decodedWeekBatch.successCount,
            totalEventCount:
              data.decodedWeekBatch.totalEventCount,
            distinctResponseCount:
              data.decodedWeekBatch.distinctResponseCount
          }
        : null,
    academicSyncStatus:
      data.academicSyncStatus || null,
    v3: {
      configured:
        Boolean(
          data.savedProfile?.rpcTemplate &&
          Array.isArray(
            data.weekTraces
          ) &&
          data.weekTraces.length >= 2
        ),
      setupState:
        data.v3SetupState || null,
      bootstrapAttempts:
        data.v3SetupState?.bootstrapAttempts || null,
      lastBootstrapCode:
        data.v3SetupState?.lastBootstrapCode || null,
      syncState:
        data.v3SyncState || null,
      passive: {
        entryCount:
          Array.isArray(
            data.v3PassiveEntries
          )
            ? data.v3PassiveEntries.length
            : 0,
        observedOperations:
          [
            ...new Set(
              (
                Array.isArray(
                  data.v3PassiveEntries
                )
                  ? data.v3PassiveEntries
                  : []
              ).map(
                (entry) =>
                  operationKey(entry)
              )
            )
          ]
      },
      runtimeBase:
        data.v3RuntimeBase
          ? {
              capturedAt:
                data.v3RuntimeBase.capturedAt,
              resourceId:
                data.v3RuntimeBase.resourceId,
              week:
                data.v3RuntimeBase.week,
              weekValue:
                data.v3RuntimeBase.weekValue
            }
          : null
    },
    collector: {
      state: data.collectorState || null,
      resourceCount: Object.keys(data.collectorResources || {}).length,
      resources: Object.values(data.collectorResources || {}).map((item) => ({
        resourceId: item?.resourceId ?? null,
        label: item?.label || null,
        path: item?.path || null,
        academicYear: item?.academicYear || null,
        eventCount: item?.eventCount || 0,
        weekCount: item?.weekCount || 0,
        updatedAt: item?.updatedAt || null
      }))
    },
    academicSyncCacheSummary:
      data.academicSyncCache
        ? {
            academicYear:
              data.academicSyncCache.academicYear || null,
            startDate:
              data.academicSyncCache.startDate || null,
            endDate:
              data.academicSyncCache.endDate || null,
            baseWeek:
              data.academicSyncCache.baseWeek || null,
            completedWeekCount:
              Array.isArray(data.academicSyncCache.weeks)
                ? data.academicSyncCache.weeks.length
                : 0,
            weekCount:
              Array.isArray(data.academicSyncCache.weeks)
                ? data.academicSyncCache.weeks.length
                : 0,
            eventCount:
              Array.isArray(data.academicSyncCache.events)
                ? data.academicSyncCache.events.length
                : 0,
            authRequired:
              Boolean(data.academicSyncCache.authRequired),
            updatedAt:
              data.academicSyncCache.updatedAt || null
          }
        : null,
    profile: data.savedProfile
      ? {
          savedAt: data.savedProfile.savedAt,
          mode: data.savedProfile.mode || "legacy",
          resourceId: data.savedProfile.resourceId ?? null,
          sampleWeek: data.savedProfile.sampleWeek || null,
          sampleEventCount:
            data.savedProfile.sampleEvents?.length || 0,
          requestCaptured:
            Boolean(data.savedProfile.rpcTemplate?.body),
          planningLabel:
            data.savedProfile.planningLabel ||
            planningLabelFromProfile(data.savedProfile),
          planningPath:
            data.savedProfile.planningPath || null
        }
      : null,
    lastAutonomyTest: data.lastAutonomyTest || null,
    lastSuccessfulSyncAt:
      data.lastSuccessfulSyncAt || null
  };
}

async function clearProfile() {
  await chrome.storage.local.clear();
  await chrome.alarms.clear(ALARM_NAME);

  return {
    ok: true,
    message:
      "Configuration locale et diagnostics effacés."
  };
}


async function siteTabs() {
  return await chrome.tabs.query({
    url: ["https://tremble-e.github.io/Site/*"]
  });
}

async function injectSiteBridgeIntoExistingPages() {
  const tabs = await siteTabs();

  await Promise.all(
    tabs
      .filter((tab) => Number.isInteger(tab.id))
      .map(async (tab) => {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["site-bridge.js"]
          });
        } catch {}
      })
  );
}

async function ensureAcademicRefreshAlarm() {
  const alarm =
    await chrome.alarms.get(
      ALARM_NAME
    );

  if (
    !alarm ||
    alarm.periodInMinutes !==
      AUTO_SYNC_MINUTES
  ) {
    await chrome.alarms.create(
      ALARM_NAME,
      {
        periodInMinutes:
          AUTO_SYNC_MINUTES
      }
    );
  }
}

chrome.runtime.onInstalled.addListener(
  () => {
    ensureAcademicRefreshAlarm()
      .catch(() => {});

    injectSiteBridgeIntoExistingPages()
      .catch(() => {});
  }
);

chrome.runtime.onStartup.addListener(
  () => {
    ensureAcademicRefreshAlarm()
      .catch(() => {});
  }
);

ensureAcademicRefreshAlarm()
  .catch(() => {});

chrome.alarms.onAlarm.addListener(
  (alarm) => {
    if (alarm.name !== ALARM_NAME) return;

    v3StableSmartSync().catch(() => {});
  }
);

chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!message) return;

    const actions = {
      PLANILIM_STATUS: status,
      PLANILIM_SAVE_PROFILE: saveProfile,
      PLANILIM_AUTONOMOUS_TEST: autonomousTest,
      PLANILIM_SYNC_NOW: syncNow,
      PLANILIM_DIAGNOSTICS: diagnostics,
      PLANILIM_DEBUG_DIAGNOSTICS_EXPORT: collectorDiagnosticsExport,
      PLANILIM_DEBUG_DIAGNOSTICS_CLEAR: collectorDiagnosticsClear,
      PLANILIM_DEBUG_AUDIT_CURRENT_EDT: collectorEventAuditCurrentEdt,
      PLANILIM_WEEK_TRACE_START: startWeekTrace,
      PLANILIM_WEEK_TRACE_STOP: stopWeekTrace,
      PLANILIM_WEEK_TRACE_DIAGNOSTICS: weekTraceDiagnostics,
      PLANILIM_GWT_SEMANTIC_ANALYSIS: semanticWeekAnalysis,
      PLANILIM_TEST_NEXT_WEEK: testPredictedNextWeek,
      PLANILIM_VALIDATE_PREDICTED_WEEK: validatePredictedWeekAgainstVisible,
      PLANILIM_GENERATE_NEXT_WEEKS: generateNextWeeks,
      PLANILIM_GENERATED_WEEKS_SUMMARY: generatedWeeksSummary,
      PLANILIM_BATCH_FINGERPRINTS: batchFingerprintReport,
      PLANILIM_CALIBRATE_REAL_WEEK: calibrateLatestRealWeek,
      PLANILIM_FULL_SEQUENCE_PREDICT: predictNextWeekWithFullSequence,
      PLANILIM_FULL_SEQUENCE_VALIDATE: validateFullSequenceAgainstRealTrace,
      PLANILIM_DECODE_SQUARE_EVENTS: decodePredictedSquareEvents,
      PLANILIM_VALIDATE_SQUARE_EVENTS: validateDecodedWeekAgainstVisible,
      PLANILIM_GENERATE_DECODED_WEEKS: generateAndDecodeNextWeeks,
      PLANILIM_DECODED_BATCH_SUMMARY: decodedWeekBatchSummary,
      PLANILIM_DECODED_BATCH_DATA: decodedWeekBatchData,
      PLANILIM_SYNC_ACADEMIC_FORWARD: syncAcademicPeriodForward,
      PLANILIM_ACADEMIC_SYNC_SUMMARY: academicSyncSummary,
      PLANILIM_ACADEMIC_PLANILIM_PAYLOAD: academicPlanilimPayload,
      PLANILIM_SYNC_FULL_ACADEMIC_YEAR: () => v3StableFullSync({ notifyUser: true }),
      PLANILIM_SMART_ACADEMIC_REFRESH: v3StableSmartSync,
      PLANILIM_ACADEMIC_YEAR_CACHE_SUMMARY: academicYearCacheSummary,
      PLANILIM_ACADEMIC_YEAR_PAYLOAD: academicYearPlanilimPayload,
      PLANILIM_V3_CONNECT: v3Connect,
      PLANILIM_V3_TRY_CONFIGURE: tryFinalizeV3Setup,
      PLANILIM_V3_STABLE_FULL_SYNC: () => v3StableFullSync({ notifyUser: true }),
      PLANILIM_V3_STABLE_SMART_SYNC: v3StableSmartSync,
      PLANILIM_V3_RESET_CONNECTION: v3ResetConnection,
      PLANILIM_COLLECTOR_TREE_SNAPSHOT: collectorTreeSnapshot,
      PLANILIM_COLLECTOR_EXPAND_AND_SCAN: collectorExpandAndScan,
      PLANILIM_COLLECTOR_TOGGLE_BRANCH: collectorToggleBranch,
      PLANILIM_COLLECTOR_PIPELINE_RESET: collectorPipelineReset,
      PLANILIM_COLLECTOR_PIPELINE_STEP: collectorPipelineStep,
      PLANILIM_COLLECTOR_PREPARE_RESOURCE: collectorCaptureModel,
      PLANILIM_COLLECTOR_PREPARE_RESOURCES: collectorPrepareResources,
      PLANILIM_COLLECTOR_SYNC_PREPARED: collectorSyncPreparedResources,
      PLANILIM_COLLECTOR_SYNC_FAST_SEQUENTIAL: collectorSyncFastSequential,
      PLANILIM_COLLECTOR_CLEAR_PREPARED: (message) => collectorClearPreparedModels(message?.resourceIds),
      PLANILIM_COLLECTOR_SYNC_RESOURCE: collectorSyncResource,
      PLANILIM_COLLECTOR_SYNC_RESOURCES: collectorSyncResources,
      PLANILIM_COLLECTOR_PAYLOADS: collectorPayloads,
      PLANILIM_CLEAR_PROFILE: clearProfile
    };

    const action = actions[message.type];
    if (!action) return;

    action(message)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({
          ok: false,
          code: "BACKGROUND_EXCEPTION",
          message: String(error)
        })
      );

    return true;
  }
);
