'use strict';

const $ = id => document.getElementById(id);
const SITE_URL = 'https://tremble-e.github.io/Site/#planning';
let currentStatus = null;
let busy = false;

function send(type) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type }, response => {
      const error = chrome.runtime.lastError;
      resolve(error
        ? { ok: false, code: 'POPUP_RUNTIME_ERROR', message: error.message }
        : response);
    });
  });
}

function formatSyncDate(value) {
  if (!value) return 'Jamais';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function planningInfo(status) {
  if (status?.profile?.planningLabel) return status.profile.planningLabel;
  const id = status?.profile?.resourceId ?? status?.v3?.setupState?.resourceId ?? null;
  return id != null ? `Planning ADE #${id}` : 'Planning ADE';
}

function getUiState(status) {
  const configured = Boolean(status?.v3?.configured || status?.profile?.requestCaptured);
  const setup = status?.v3?.setupState || null;
  const sync = status?.v3?.syncState || status?.academicSyncStatus || null;
  const cache = status?.academicSyncCacheSummary || null;
  const syncState = sync?.state || '';
  const setupState = setup?.state || '';
  const running = ['bootstrapping', 'syncing_initial_year'].includes(setupState) ||
    ['syncing', 'preparing_fresh_base', 'running'].includes(syncState);

  if (running) {
    return {
      kind: 'busy',
      title: 'Synchronisation en cours',
      message: 'Planilim récupère votre année universitaire. Gardez ADE ouvert jusqu’à la fin.',
      button: 'Synchronisation…',
      disabled: true
    };
  }

  if (syncState === 'auth_required' || status?.academicSyncStatus?.state === 'auth_required') {
    return {
      kind: 'auth',
      title: 'Reconnexion nécessaire',
      message: 'Votre session universitaire a expiré. Reconnectez-vous à ADE, puis Planilim redétectera votre planning.',
      button: 'Se reconnecter à ADE',
      disabled: false
    };
  }

  if (['waiting_for_ade', 'waiting_for_login', 'needs_week_change'].includes(setupState)) {
    return {
      kind: 'waiting',
      title: 'En attente du planning ADE',
      message: 'Dans l’onglet ADE, connectez-vous si nécessaire puis affichez le planning que vous voulez synchroniser. La détection est automatique.',
      button: 'En attente de l’affichage du planning…',
      disabled: true
    };
  }

  if (setupState === 'detected' || (configured && !cache?.updatedAt && !cache?.eventCount)) {
    return {
      kind: 'detected',
      title: 'Planning détecté',
      message: `${planningInfo(status)} est prêt. Vérifiez que c’est bien le planning souhaité, puis lancez la synchronisation.`,
      button: 'Synchroniser mon emploi du temps',
      disabled: false
    };
  }

  if (configured && cache?.updatedAt) {
    return {
      kind: 'ready',
      title: 'Emploi du temps synchronisé',
      message: `${cache?.eventCount ?? 0} cours sont disponibles dans Planilim. Vous pouvez fermer ADE.`,
      button: 'Synchroniser à nouveau',
      disabled: false
    };
  }

  if (configured) {
    return {
      kind: 'detected',
      title: 'Planning détecté',
      message: `${planningInfo(status)} est prêt. Lancez la synchronisation pour récupérer l’année universitaire.`,
      button: 'Synchroniser mon emploi du temps',
      disabled: false
    };
  }

  return {
    kind: 'start',
    title: 'Synchroniser votre planning ADE',
    message: 'Planilim va ouvrir ADE. Connectez-vous puis affichez simplement le planning souhaité.',
    button: 'Synchroniser mon emploi du temps',
    disabled: false
  };
}

function render(status) {
  currentStatus = status || {};
  const ui = getUiState(currentStatus);
  const cache = currentStatus?.academicSyncCacheSummary || null;

  const dot = $('dot');
  dot.className = 'dot';
  if (ui.kind === 'ready' || ui.kind === 'detected') dot.classList.add('ok');
  if (ui.kind === 'auth') dot.classList.add('bad');
  if (ui.kind === 'busy') dot.classList.add('busy');

  $('title').textContent = ui.title;
  $('message').textContent = ui.message;
  $('mainButton').textContent = ui.button;
  $('mainButton').disabled = busy || ui.disabled;

  $('summary').hidden = !cache;
  $('events').textContent = cache?.eventCount ?? 0;
  $('lastSync').textContent = formatSyncDate(cache?.updatedAt || currentStatus?.lastSuccessfulSyncAt);
}

async function refresh() {
  const status = await send('PLANILIM_STATUS');
  render(status);
}

async function runPrimaryAction() {
  const ui = getUiState(currentStatus || {});
  if (ui.disabled || busy) return;

  busy = true;
  render(currentStatus || {});

  if (ui.kind === 'detected' || ui.kind === 'ready') {
    await send('PLANILIM_V3_STABLE_FULL_SYNC');
  } else {
    await send('PLANILIM_V3_CONNECT');
  }

  busy = false;
  await refresh();
}

$('mainButton').addEventListener('click', runPrimaryAction);
$('siteButton').addEventListener('click', () => chrome.tabs.create({ url: SITE_URL }));

refresh();
setInterval(refresh, 900);
