# Planilim ADE Bridge 3.2.0

Extension Chromium pour synchroniser le planning ADE de l'Université de Limoges avec Planilim.

## Utilisation

1. Ouvrir l'extension et cliquer sur **Connecter mon planning ADE**.
2. Se connecter à UNILIM si nécessaire et afficher le planning souhaité.
3. L'extension initialise automatiquement ADE et synchronise l'année universitaire.

Une fois configurée, le bouton principal devient **Synchroniser maintenant**. Si la session universitaire expire, l'extension demande simplement une reconnexion.

## Données d'authentification

L'extension utilise la session ADE déjà ouverte dans le navigateur. Elle ne demande pas la permission `cookies` et n'enregistre pas les identifiants ou mots de passe UNILIM.

## Site autorisé

Le pont avec le site est limité à :

`https://tremble-e.github.io/Site/`

## Détection par le site

Lors de l’installation, l’extension injecte automatiquement le pont Planilim dans les fenêtres du site déjà ouvertes, y compris la PWA déjà ouverte sur ordinateur lorsque Brave l’expose comme onglet. Le site effectue aussi ses propres vérifications périodiques.
