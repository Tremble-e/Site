## v4.14.0 — pool adaptatif 4 → 6 workers

- Le collecteur démarre toujours sur la base fiable de **4 workers**.
- Après 12 EDT stables, un 5e worker est ouvert automatiquement ; après 36 résultats stables, un 6e peut être ajouté.
- Les workers supplémentaires sont créés **un par un** pour respecter le comportement de sécurité observé sur ADE.
- Une fenêtre glissante surveille les erreurs de sélection et les EDT partiels. Si la qualité se dégrade, les workers ajoutés terminent leur EDT courant puis sont fermés et le collecteur revient automatiquement à 4 workers.
- Si un worker de base est perdu, l'extension tente d'en recréer un avant de chercher à accélérer.
- Les workers 5/6 sont systématiquement fermés avant la phase de réparation : les trous et retries finaux restent à **4 workers maximum**.
- La prise de focus automatique toutes les **4 minutes** est conservée.
- La règle de sécurité reste inchangée : un EDT incomplet ne remplace jamais un ancien EDT 44/44.

## v4.13.0 — retour au moteur 4 workers + réparation finale

- Le passage principal revient à **4 workers ADE** simultanés, la configuration qui avait donné les résultats les plus stables.
- Les retries ciblés du moteur fiable restent actifs afin de réduire les trous à une ou deux semaines quand ADE rate ponctuellement une réponse.
- À la fin du passage principal, une phase dédiée à **4 workers** reprend uniquement les EDT encore incomplets et redemande les semaines manquantes, jusqu’à 3 tours.
- La prise de focus automatique des fenêtres workers est conservée toutes les **4 minutes** ; chaque fenêtre est re-maximisée puis le focus revient à la fenêtre utilisée auparavant.
- La limite globale de workers est forcée à 4, même si une ancienne version du site en demande davantage.
- Un EDT incomplet ne remplace jamais une version complète déjà stockée.

## v4.12.3 — stabilisation légère avant réparation finale

- Le passage principal reste à 15 workers.
- Après les 44 semaines, les EDT incomplets récupèrent immédiatement leurs trous avec les deux passes rapides qui donnaient auparavant seulement quelques semaines manquantes : retry direct puis voisin/retour.
- Pour ne pas reproduire le blocage de la 4.12.1, seulement 4 workers peuvent effectuer cette stabilisation en même temps ; les autres affichent `stabilizing_wait`.
- Le fallback `reliable-single-week` n'est pas lancé pendant la phase 15-workers. Il reste réservé à la phase finale de réparation avec 4 workers.
- La phase finale conserve donc les 4 workers et ne redemande que les semaines encore absentes.
- La prise de focus automatique toutes les 4 minutes est utilisée dans la v4.13.0.
- Aucun EDT incomplet n'écrase un EDT complet déjà stocké.

## v4.12.2 — correction du blocage à 44/44

- La prise de focus automatique toutes les minutes est **conservée**.
- Le passage principal à 15 workers ne lance plus les retries de semaines juste après 44/44.
- Un EDT incomplet rend immédiatement la main au scheduler et garde ses semaines valides en mémoire.
- Les semaines manquantes sont réparées ensuite par la phase dédiée à 4 workers.
- Cela évite que les 15 workers entrent simultanément dans les retries et restent visuellement bloqués à 44/44.


## v4.12.1 — réveil automatique des workers sur un autre bureau

- Toutes les minutes pendant une synchronisation active, l’extension donne brièvement le focus à chaque fenêtre worker, une par une.
- Chaque worker est rem maximisé avant son pulse pour éviter le throttling agressif des fenêtres minimisées.
- Après le cycle, le focus est rendu à la fenêtre qui était active avant le réveil.
- L’extension ne cible pas un numéro de bureau Windows (l’API Chrome ne l’expose pas) : elle réveille les fenêtres workers là où l’utilisateur les a placées. Si elles sont sur le bureau 2, Windows bascule brièvement dessus puis revient à la fenêtre précédente.
- Le pulse est inactif pendant la lecture de l’arbre et le bootstrap ; il ne tourne que lorsque les workers travaillent réellement.

# Planilim Collector v4.14.0

Cette version corrige la cause identifiée par le diagnostic 4.5.7 : l’identification d’une requête `method10getTimetable` dépendait d’une back-reference GWT précise (`-8`). Les ressources sont désormais extraites depuis la structure réelle de `PlanningSelection`, et les semaines sérialisées sous forme de back-reference (`-3` à `-9`) sont décodées puis réécrites sous forme d’`Integer` explicite. Les outils de diagnostic sont conservés.













## v4.12.0 — réparation des trous avec 4 workers

- Le passage principal reste à **15 workers** pour conserver le débit maximum.
- Un EDT partiel (par exemple 42/44 ou 43/44) conserve en mémoire toutes ses semaines déjà valides.
- Après le passage principal, une phase dédiée utilise **4 workers seulement** et redemande **uniquement les semaines encore manquantes**.
- Jusqu’à 3 tours de réparation sont effectués, avec les retries `direct`, `neighbour-back` et `reliable-single-week` déjà éprouvés.
- Dès qu’un EDT atteint 44/44 pendant cette phase, il est validé, stocké puis publié normalement ; son échec disparaît des compteurs du site.
- Un EDT encore incomplet après la réparation n’est jamais écrasé dans Supabase : l’ancien EDT complet reste conservé.
- Les erreurs de sélection classiques restent traitées séparément par les retries de ressource et la quarantaine des workers défectueux.

## v4.11.2 — démarrage séquentiel + quarantaine des workers

- Les workers ADE sont désormais ouverts **un par un**, avec une pause entre deux ouvertures, afin d'éviter la protection / saturation observée lors de nombreuses connexions simultanées.
- Les workers ratés au bootstrap sont recréés lors de plusieurs passes au lieu de faire échouer immédiatement tout le pool.
- Un `COLLECTOR_RESOURCE_NOT_READY` ne permet plus au worker de prendre aussitôt un nouvel EDT : le même EDT est retenté, puis la page ADE du worker est rechargée.
- Si un worker échoue très rapidement plusieurs fois sur la même sélection, il est déclaré `COLLECTOR_WORKER_UNHEALTHY`, fermé et retiré du pool. Sa cible est remise dans la file pour un worker sain.
- Les fenêtres restent maximisées pendant toute la collecte.
- L'export diagnostic n'affiche plus comme erreurs finales les échecs transitoires qui ont ensuite été récupérés.

## v4.11.1 — workers maximisés et superposés

- Les 15 fenêtres ADE ne sont plus découpées en grille : chacune reçoit toute la surface disponible puis est maximisée.
- Toutes les fenêtres workers sont ouvertes aux mêmes coordonnées et se superposent volontairement les unes aux autres.
- Elles restent non minimisées pour conserver un grand viewport ADE/ExtJS et éviter les `COLLECTOR_RESOURCE_NOT_READY` provoqués par les petites fenêtres.
- Le nombre de workers, les retries automatiques, l'isolation par `tabId + resourceId` et la règle 44/44 sont inchangés.

## v4.11.0 — 15 workers + récupération automatique des erreurs

- 15 workers ADE simultanés par défaut (jusqu’à 20).
- Ouverture des workers par groupes de 5 pour réduire fortement le temps de bootstrap sans saturer Brave/ADE.
- Les fenêtres sont automatiquement disposées en grille et sont restaurées si elles ont été minimisées.
- Un worker qui ne démarre pas est retenté jusqu’à 3 fois ; si quelques workers restent indisponibles, la synchronisation continue avec ceux qui sont prêts au lieu d’annuler tout le run.
- Les EDT en échec sont retentés automatiquement deux fois en fin de run. Le premier retry force une recherche fraîche par chemin/resourceId ; le second recharge la page ADE du worker avant de réessayer.
- Les compteurs restent basés sur les 216 EDT uniques : un retry ne gonfle jamais le nombre d’EDT terminés.
- Les diagnostics exportent désormais la liste compacte de tous les résultats en échec, avec worker, resourceId, chemin, tentative et code d’erreur.
- La règle de sécurité 44/44 et la conservation de l’ancien EDT en cas d’échec restent inchangées.

## v4.10.0 — 4 workers continus + suivi asynchrone

La synchronisation complète n'est plus liée à une requête longue du site. Le site démarre un run, reçoit immédiatement un `runId`, puis interroge l'état environ une fois par seconde. Le coordinateur lit toujours l'arbre FST seul ; une fois les cibles figées, **4 workers ADE** sont ouverts par défaut (architecture configurable de 2 à 6). Chaque worker prend immédiatement l'EDT suivant dès qu'il termine, sans attendre les autres.

La file est attribuée par index atomique en mémoire : un `resourceId` n'est jamais distribué à deux workers. Chaque résultat reste validé 44/44 avant stockage et les captures RPC restent isolées par `tabId + resourceId`. Le suivi expose aussi la progression de chaque worker (`semaine courante / 44`) et les résultats sont publiés progressivement côté Planilim.


## v4.9.0 — coordinateur dédié puis workers

Architecture entièrement séparée en deux phases. La page ADE déjà ouverte devient uniquement le **coordinateur** : elle parcourt l’arbre FST complet sans sélectionner ni synchroniser aucun EDT et construit une file immuable de `resourceId`. Tant que cette lecture n’est pas terminée, aucune page worker n’est ouverte.

Une fois le catalogue terminé, l’extension ouvre **N pages ADE workers indépendantes** (2 par défaut, architecture prête jusqu’à 6). Le coordinateur n’appartient jamais au pool. Chaque lot prend une tranche unique de la file, donc deux workers ne peuvent pas recevoir le même `resourceId`. Chaque worker conserve ensuite le moteur fiable 4.7.4/4.7.x : sélection fraîche par chemin + `resourceId`, semaines séquentielles, retries ciblés et publication uniquement en `44/44`.

Cette séparation évite qu’une page soit à la fois en train de virtualiser/parcourir l’arbre et de changer de planning pour récupérer 44 semaines. Les fenêtres workers sont créées seulement après la découverte complète et sont fermées automatiquement à la fin ; la page coordinatrice reste ouverte.

## v4.8.2 — démarrage robuste des 2 workers

Corrige l’arrêt juste après l’ouverture des deux fenêtres ADE observé en 4.8.0. Le document principal pouvait être déclaré `complete` alors que l’iframe DirectPlanning / l’arbre GWT n’était pas encore monté. Chaque worker attend désormais explicitement que l’arbre ADE contienne des lignes avant de démarrer. Le worker 0 réutilise la page ADE déjà ouverte et la déplace dans sa propre fenêtre ; un seul second onglet ADE est créé. Le coordinateur retente aussi l’initialisation de l’arbre si ADE finit de monter légèrement plus tard.

## v4.8.0 — double worker ADE isolé

La synchronisation complète utilise désormais deux workers simultanés. Chaque worker possède sa propre fenêtre ADE et son propre onglet actif, tandis qu’un coordinateur unique parcourt l’arbre et attribue chaque `resourceId` une seule fois. Les captures natives restent isolées par `tabId + resourceId + generation token`. Les écritures `collectorResources`, historiques RPC et diagnostics sont sérialisées pour empêcher qu’un worker écrase le résultat de l’autre. Les fenêtres workers sont fermées automatiquement en fin de collecte.

Le premier plan n’est pas requis : les fenêtres workers peuvent rester non focalisées. L’important est que chaque onglet ADE soit l’onglet actif de sa propre fenêtre, ce qui évite que les deux workers se disputent l’état actif d’une même fenêtre.


## v4.7.4 — correction de la régression d’ouverture de l’arbre ADE

- restaure l’ouverture/parcours des branches de l’arbre ExtJS virtualisé ;
- utilise à nouveau le `nodeId` exact pour les branches tant qu’il est encore valide dans le DOM ;
- conserve la validation stricte du `resourceId` avant de sélectionner un EDT terminal ;
- ne rejette plus une branche uniquement parce que son chemin reconstruit est temporairement incomplet pendant la virtualisation ;
- conserve la plage académique verrouillée, les retries hebdomadaires ciblés et la publication uniquement en 44/44.

## v4.7.3 — sélection fraîche des derniers EDT récalcitrants

- Le `resourceId` devient l'identité prioritaire de la ligne ADE : un `nodeId` provenant d'un ancien rendu ExtJS ne peut plus faire cliquer une autre formation.
- Après une mauvaise sélection, la ligne DOM est abandonnée. Le collecteur repart du chemin complet, rescrolle l'arbre virtualisé et retrouve une nouvelle instance avant de recliquer.
- Juste avant chaque clic, le `resourceId` réellement porté par la ligne DOM est vérifié. Une ligne recyclée est rejetée sans être cliquée.
- Jusqu'à 3 recherches fraîches sont réalisées uniquement sur les EDT concernés. Les EDT normaux ne paient pas ce surcoût.
- Les diagnostics exposent désormais les tentatives de recherche DOM et les éventuels `resourceId` sélectionnés à tort.
- Le moteur natif, la plage académique verrouillée, les retries ciblés par semaine et la règle stricte `44/44` restent inchangés.

## v4.7.2 — année académique verrouillée + sélection de ressource confirmée

- La plage des 44 semaines est maintenant figée une seule fois au début du run à partir de l’année académique courante, puis réutilisée pour tous les EDT. Le collecteur ne peut donc plus dériver vers 2027-2028 simplement parce qu’ADE est resté affiché en fin d’année après l’EDT précédent.
- Après un changement d’EDT, aucun `method10getTimetable` n’est accepté tant que son `resourceId` n’est pas exactement celui de la cible. Les RPC encore émises par l’EDT précédent sont ignorées.
- Si le bon `resourceId` ne produit pas immédiatement son modèle, la ressource est resélectionnée jusqu’à deux fois et une navigation de semaine n’est utilisée que lorsque la sélection de la bonne ressource a été confirmée.
- Les diagnostics exposent `academicRangeStart`, `academicRangeEnd`, `expectedResourceId`, `observedWrongResourceIds` et `selectionRetryCount`.
- Les retries ciblés 4.7.1 et la règle de publication stricte `44/44` sont conservés.

## v4.7.1 — retries ciblés sans refaire les 44 semaines

La première passe reste le mode natif turbo validé sur les EDT corrects. Lorsqu'une ou plusieurs semaines ne livrent pas leur réponse `method10getTimetable`, l'extension conserve toutes les semaines déjà réussies et ne retravaille que les dates en échec.

Trois niveaux sont appliqués : une nouvelle sélection directe de la semaine, puis un aller-retour par une semaine voisine pour forcer un nouveau XHR, puis en dernier recours le mécanisme fiable 4.6.6 (capture de la requête native + replay) uniquement pour la semaine restante. Une réponse native est maintenant associée à un jeton de génération unique lié à la ressource et à la date cible, ce qui empêche une réponse arrivée en retard d'être attribuée à la semaine suivante.

Un payload n'est toujours publié qu'en `44/44`. Les diagnostics indiquent `retryPasses`, `recoveredWeekCount` et `remainingFailedWeeks`, avec `COLLECTOR_NATIVE_TURBO_RECOVERED` quand les retries ont sauvé un EDT.

## v4.7.0 — mode natif turbo pour les 216 EDT

La collecte complète n'effectue plus deux requêtes par semaine. L'extension injecte un intercepteur léger dans la page ADE, laisse ADE effectuer son vrai `method10getTimetable`, puis récupère directement **la réponse native que GWT utilise pour afficher la semaine**. Cette réponse est décodée sans replay supplémentaire et sans attendre le rendu des blocs DOM.

La source reste donc exactement la même que dans le mode fiable validé à 123 cours sur `L3 Maths > Semestre 5`, mais le coût par semaine passe de « navigation + capture + replay + attente DOM » à « navigation + réponse ADE native ». Les 44 semaines restent contrôlées une par une et un payload n'est publié que si elles sont toutes décodées. Si l'intercepteur natif manque exceptionnellement une réponse, seule cette semaine retombe sur le mécanisme fiable 4.6.6.

Le mode fiable du popup est conservé comme outil de vérification manuel. Les synchronisations complètes et les relances d'échecs utilisent désormais `collectionMode: native-response-turbo`.

## v4.6.6 — requête native par semaine + faux mismatch DOM corrigé

La collecte fiable capture désormais la vraie requête `method10getTimetable` émise par ADE après chaque changement de semaine et rejoue exactement ce body. Le DOM ADE devient une validation secondaire : s'il est encore vide pendant le rendu GXT, la semaine n'est plus rejetée à tort ; une divergence non vide et stable reste bloquante. Le popup laisse jusqu'à 4 minutes aux opérations fiables/audit afin de ne plus afficher le faux `POPUP_RUNTIME_TIMEOUT` au bout de 15 secondes.


## v4.6.5 — collecte visuelle séquentielle fiable

Le diagnostic v4.6.3 a établi qu’ADE conserve un état de semaine côté serveur : une collecte rapide pouvait répéter la même semaine (par exemple 13 cours × 44 semaines) tout en renvoyant HTTP 200. La collecte normale utilise désormais le même principe que l’audit fiable : ADE est réellement positionné sur chaque semaine, le DOM confirme la date, puis `method10getTimetable` est rejoué et comparé à l’affichage avant stockage. Une divergence invalide la semaine et empêche toute publication partielle.

Le popup ajoute **Synchroniser l’EDT affiché (mode fiable)** pour tester une seule formation sans relancer les 216 EDT. Le payload stocké est marqué `collectionMode: visual-sequential-verified`.

## v4.6.3 — capture littérale fiabilisée

- Corrige le dernier cas `COLLECTOR_LITERAL_TEMPLATE_NOT_CAPTURED` observé sur `L1 Chimie - Tremplin > AN`.
- Après le changement de semaine destiné à obtenir un `getTimetable` littéral, le collecteur attend désormais explicitement une requête du bon `resourceId`, encodée en `Integer` littéral et portant la valeur de semaine attendue.
- Un ancien body GWT encore encodé en back-reference ne peut plus être pris par erreur comme nouveau modèle simplement parce qu’il a été capturé quelques millisecondes avant le body littéral.
- Le collecteur vérifie le cache mémoire, `latestTimetableRequest` et l’historique récent avant de déclarer l’échec, sans ralentir les EDT déjà compatibles.
- Les protections anti-quota et l’audit de bout en bout de la v4.6.2 sont conservés.

## v4.6.2 — stockage étendu et protection anti-quota

- Ajout de la permission Chromium/Brave `unlimitedStorage` : les 216 payloads complets ne sont plus limités par le quota standard de `chrome.storage.local`.
- Si un profil est déjà proche de la limite au moment de la mise à jour, le collecteur compacte automatiquement les anciens diagnostics volumineux puis retente l’écriture.
- Les diagnostics d’audit conservent les résumés et les différences utiles, mais tronquent les duplications de grosses réponses GWT afin de ne plus concurrencer les payloads des EDT.
- Le démarrage d’une synchronisation complète compacte les anciens diagnostics, sans supprimer les emplois du temps déjà récupérés.

## Diagnostic

1. Ouvre le popup de l'extension.
2. Clique sur **Effacer les diagnostics** avant un test propre.
3. Lance la synchronisation ou **Relancer les échecs** depuis Planilim.
4. Quand le test est terminé, rouvre le popup et clique sur **Exporter les diagnostics**.
5. Envoie le fichier `planilim-diagnostic-....json`.

L'export n'inclut pas les cookies ni les en-têtes `Authorization`. Il contient les corps GWT et réponses ADE nécessaires pour comprendre les cas restants.

---

# Collecteur administrateur 4.5.6

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.


## 4.5.3
- Parcours unique conservé, mais plus aucune synchronisation en parallèle avec la sélection de l’EDT suivant.
- Un EDT reste sélectionné pendant toute la récupération de ses 44 semaines.
- Passage de confirmation supplémentaire sur l’arbre virtualisé avant de déclarer la découverte terminée.


## v4.5.3
Le parcours unique de l’arbre est conservé, mais la récupération annuelle revient au moteur stable validé (bootstrap à deux traces réelles + génération GWT). Le modèle RPC simplifié introduit en 4.5.x n’est plus utilisé par le pipeline administrateur. Jusqu’à 4 semaines sont synchronisées en parallèle pour un seul EDT à la fois.


## v4.5.5
- La sélection d'un EDT est retentée automatiquement si ExtJS perd le premier clic pendant un rerendu.
- Les semaines RPC en échec sont rejouées automatiquement en séquence complète et de façon séquentielle, uniquement après le passage rapide.
- La semaine réellement visible dans ADE est fusionnée avec la semaine RPC avant publication afin de récupérer les cours visibles que le décodeur GWT aurait partiellement normalisés.
- Les corrections de parcours de la v4.5.4 sont conservées.


## v4.5.6
- Si ADE ne confirme pas immédiatement la sélection d'un EDT, la ressource est resélectionnée jusqu'à deux fois avant d'être déclarée en échec.
- Le moteur stable rejoue jusqu'à quatre fois uniquement les semaines encore en échec, avec temporisation croissante.
- Le moteur rapide utilisé par « Relancer les échecs » effectue désormais trois passes ciblées sur les seules semaines ratées au lieu de refaire dépendre tout l'EDT d'un unique passage.
- Les résultats partiels remontent maintenant le nombre de semaines en échec et un résumé des codes techniques afin de distinguer un problème réseau d'un problème de décodage.


## v4.5.9 — replay GWT vérifié

- Les modèles `method10getTimetable` utilisant une back-reference GWT ne sont plus mutés localement.
- ADE est déplacé directement sur une semaine produisant un `Integer` littéral, puis ce body natif sert de modèle annuel.
- Une collecte partielle n'écrase plus jamais le dernier payload complet.
- Un EDT n'est marqué réussi que si toutes les semaines demandées ont été décodées avec succès.
- En cas d'échec de replay, le diagnostic compare automatiquement le body natif et le body reconstruit.


## v4.6.1 — garde de cohérence et audit de bout en bout

La synchronisation rapide conserve plusieurs requêtes `getTimetable` en parallèle, mais vérifie désormais jusqu’à huit semaines sentinelles en les rejouant séquentiellement. Si un seul événement diffère, le résultat parallèle est abandonné et l’EDT est entièrement retéléchargé séquentiellement avant publication. Le payload stocké indique alors `collectionMode: sequential-fallback`.

L’audit de l’EDT affiché compare maintenant aussi le payload déjà stocké avec le décodage séquentiel (`decodedNotStored` / `storedNotDecoded`) et sélectionne les onglets de semaine par date exacte, y compris au passage décembre → janvier.

## Diagnostic des cours manquants — v4.6.0

Cette version ajoute un audit ciblé d'un emploi du temps. Ouvrez ADE, sélectionnez l'EDT concerné, puis ouvrez le popup de l'extension et cliquez sur **Auditer l’EDT affiché dans ADE**. L'extension parcourt l'année semaine par semaine, compare les événements visibles dans ADE avec ceux décodés depuis `method10getTimetable`, et enregistre uniquement les semaines divergentes avec les événements bruts utiles. Une fois l'audit terminé, utilisez **Exporter les diagnostics** et transmettez le JSON généré.


## Export diagnostic robuste (4.6.5)

L’export des diagnostics est désormais déclenché directement par le service worker via l’API Downloads afin d’éviter les blocages du popup lors du transfert de gros JSON. Les erreurs `COLLECTOR_VISIBLE_RPC_MISMATCH` enregistrent maintenant la semaine, les événements visibles ADE, les événements décodés et leurs différences.
