(function (root, factory) {
  "use strict";
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.PlanilimGwtResponse = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const JSON_ESCAPES = new Set(['"', "\\", "/", "b", "f", "n", "r", "t"]);

  function normalizeJavascriptStringEscapes(source) {
    let output = "";
    let inString = false;
    for (let index = 0; index < source.length; index += 1) {
      const char = source[index];
      if (char === '"') {
        inString = !inString;
        output += char;
        continue;
      }
      if (!inString) {
        output += char;
        continue;
      }
      if (char.charCodeAt(0) < 0x20) {
        output += `\\u${char.charCodeAt(0).toString(16).padStart(4, "0")}`;
        continue;
      }
      if (char !== "\\" || index + 1 >= source.length) {
        output += char;
        continue;
      }

      const next = source[index + 1];
      if (JSON_ESCAPES.has(next)) {
        output += char + next;
        index += 1;
        continue;
      }
      if (next === "u" && /^[0-9a-f]{4}$/i.test(source.slice(index + 2, index + 6))) {
        output += source.slice(index, index + 6);
        index += 5;
        continue;
      }
      if (next === "x" && /^[0-9a-f]{2}$/i.test(source.slice(index + 2, index + 4))) {
        output += `\\u00${source.slice(index + 2, index + 4)}`;
        index += 3;
        continue;
      }
      if (next === "v") {
        output += "\\u000b";
        index += 1;
        continue;
      }
      if (next === "0" && !/\d/.test(source[index + 2] || "")) {
        output += "\\u0000";
        index += 1;
        continue;
      }

      output += next;
      index += 1;
    }
    return output;
  }

  function parseGwtJsonPayload(source) {
    try {
      return JSON.parse(source);
    } catch (firstError) {
      const normalized = normalizeJavascriptStringEscapes(source);
      if (normalized === source) throw firstError;
      return JSON.parse(normalized);
    }
  }

  return { normalizeJavascriptStringEscapes, parseGwtJsonPayload };
});
