# Collecteur administrateur 4.5.6

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.


## 4.5.3
- Parcours unique conservé, mais plus aucune synchronisation en parallèle avec la sélection de l’EDT suivant.
- Un EDT reste sélectionné pendant toute la récupération de ses 44 semaines.
- Passage de confirmation supplémentaire sur l’arbre virtualisé avant de déclarer la découverte terminée.


## v4.5.3
Le parcours unique de l’arbre est conservé, mais la récupération annuelle revient au moteur stable validé (bootstrap à deux traces réelles + génération GWT). Le modèle RPC simplifié introduit en 4.5.x n’est plus utilisé par le pipeline administrateur. Jusqu’à 4 semaines sont synchronisées en parallèle pour un seul EDT à la fois.


## v4.5.5
- La sélection d'un EDT est retentée automatiquement si ExtJS perd le premier clic pendant un rerendu.
- Les semaines RPC en échec sont rejouées automatiquement en séquence complète et de façon séquentielle, uniquement après le passage rapide.
- La semaine réellement visible dans ADE est fusionnée avec la semaine RPC avant publication afin de récupérer les cours visibles que le décodeur GWT aurait partiellement normalisés.
- Les corrections de parcours de la v4.5.4 sont conservées.


## v4.5.6
- Si ADE ne confirme pas immédiatement la sélection d'un EDT, la ressource est resélectionnée jusqu'à deux fois avant d'être déclarée en échec.
- Le moteur stable rejoue jusqu'à quatre fois uniquement les semaines encore en échec, avec temporisation croissante.
- Le moteur rapide utilisé par « Relancer les échecs » effectue désormais trois passes ciblées sur les seules semaines ratées au lieu de refaire dépendre tout l'EDT d'un unique passage.
- Les résultats partiels remontent maintenant le nombre de semaines en échec et un résumé des codes techniques afin de distinguer un problème réseau d'un problème de décodage.
