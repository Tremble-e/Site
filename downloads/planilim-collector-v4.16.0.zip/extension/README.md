## v4.16.0 — filières + salles, moteur workers stabilisé

Cette version étend le collecteur aux emplois du temps de salles sans modifier le moteur hebdomadaire stabilisé des workers.

- Synchronisation des filières : `Groupes Etudiants > Faculté des Sciences et Techniques`.
- Synchronisation des salles : `Salles > LIMOGES > LIMOGES La Borie FST`.
- Les feuilles de salles sont détectées sous les bâtiments ; les salles directement rattachées au site sont également acceptées.
- Les 4 workers conservent le bootstrap séquentiel, le grand viewport initial, le placement unique en 2×2, les délais, les retries, la réparation finale et la validation complète des semaines de la v4.15.6.
- La lecture du catalogue conserve le chemin de frame rapide déjà validé, avec réinjection des scripts uniquement en secours.
- Les libellés visibles ont été reformulés de façon neutre pour un usage partagé de l'extension.

Le choix du type de synchronisation et la relance séparée des échecs sont pilotés depuis le panneau Administration du site Planilim.
