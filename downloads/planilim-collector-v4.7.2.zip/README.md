# Planilim Collector v4.7.2

Cette version corrige la cause identifiée par le diagnostic 4.5.7 : l’identification d’une requête `method10getTimetable` dépendait d’une back-reference GWT précise (`-8`). Les ressources sont désormais extraites depuis la structure réelle de `PlanningSelection`, et les semaines sérialisées sous forme de back-reference (`-3` à `-9`) sont décodées puis réécrites sous forme d’`Integer` explicite. Les outils de diagnostic sont conservés.






## v4.7.2 — année académique verrouillée + sélection de ressource confirmée

- La plage des 44 semaines est maintenant figée une seule fois au début du run à partir de l’année académique courante, puis réutilisée pour tous les EDT. Le collecteur ne peut donc plus dériver vers 2027-2028 simplement parce qu’ADE est resté affiché en fin d’année après l’EDT précédent.
- Après un changement d’EDT, aucun `method10getTimetable` n’est accepté tant que son `resourceId` n’est pas exactement celui de la cible. Les RPC encore émises par l’EDT précédent sont ignorées.
- Si le bon `resourceId` ne produit pas immédiatement son modèle, la ressource est resélectionnée jusqu’à deux fois et une navigation de semaine n’est utilisée que lorsque la sélection de la bonne ressource a été confirmée.
- Les diagnostics exposent `academicRangeStart`, `academicRangeEnd`, `expectedResourceId`, `observedWrongResourceIds` et `selectionRetryCount`.
- Les retries ciblés 4.7.1 et la règle de publication stricte `44/44` sont conservés.

## v4.7.1 — retries ciblés sans refaire les 44 semaines

La première passe reste le mode natif turbo validé sur les EDT corrects. Lorsqu'une ou plusieurs semaines ne livrent pas leur réponse `method10getTimetable`, l'extension conserve toutes les semaines déjà réussies et ne retravaille que les dates en échec.

Trois niveaux sont appliqués : une nouvelle sélection directe de la semaine, puis un aller-retour par une semaine voisine pour forcer un nouveau XHR, puis en dernier recours le mécanisme fiable 4.6.6 (capture de la requête native + replay) uniquement pour la semaine restante. Une réponse native est maintenant associée à un jeton de génération unique lié à la ressource et à la date cible, ce qui empêche une réponse arrivée en retard d'être attribuée à la semaine suivante.

Un payload n'est toujours publié qu'en `44/44`. Les diagnostics indiquent `retryPasses`, `recoveredWeekCount` et `remainingFailedWeeks`, avec `COLLECTOR_NATIVE_TURBO_RECOVERED` quand les retries ont sauvé un EDT.

## v4.7.0 — mode natif turbo pour les 216 EDT

La collecte complète n'effectue plus deux requêtes par semaine. L'extension injecte un intercepteur léger dans la page ADE, laisse ADE effectuer son vrai `method10getTimetable`, puis récupère directement **la réponse native que GWT utilise pour afficher la semaine**. Cette réponse est décodée sans replay supplémentaire et sans attendre le rendu des blocs DOM.

La source reste donc exactement la même que dans le mode fiable validé à 123 cours sur `L3 Maths > Semestre 5`, mais le coût par semaine passe de « navigation + capture + replay + attente DOM » à « navigation + réponse ADE native ». Les 44 semaines restent contrôlées une par une et un payload n'est publié que si elles sont toutes décodées. Si l'intercepteur natif manque exceptionnellement une réponse, seule cette semaine retombe sur le mécanisme fiable 4.6.6.

Le mode fiable du popup est conservé comme outil de vérification manuel. Les synchronisations complètes et les relances d'échecs utilisent désormais `collectionMode: native-response-turbo`.

## v4.6.6 — requête native par semaine + faux mismatch DOM corrigé

La collecte fiable capture désormais la vraie requête `method10getTimetable` émise par ADE après chaque changement de semaine et rejoue exactement ce body. Le DOM ADE devient une validation secondaire : s'il est encore vide pendant le rendu GXT, la semaine n'est plus rejetée à tort ; une divergence non vide et stable reste bloquante. Le popup laisse jusqu'à 4 minutes aux opérations fiables/audit afin de ne plus afficher le faux `POPUP_RUNTIME_TIMEOUT` au bout de 15 secondes.


## v4.6.5 — collecte visuelle séquentielle fiable

Le diagnostic v4.6.3 a établi qu’ADE conserve un état de semaine côté serveur : une collecte rapide pouvait répéter la même semaine (par exemple 13 cours × 44 semaines) tout en renvoyant HTTP 200. La collecte normale utilise désormais le même principe que l’audit fiable : ADE est réellement positionné sur chaque semaine, le DOM confirme la date, puis `method10getTimetable` est rejoué et comparé à l’affichage avant stockage. Une divergence invalide la semaine et empêche toute publication partielle.

Le popup ajoute **Synchroniser l’EDT affiché (mode fiable)** pour tester une seule formation sans relancer les 216 EDT. Le payload stocké est marqué `collectionMode: visual-sequential-verified`.

## v4.6.3 — capture littérale fiabilisée

- Corrige le dernier cas `COLLECTOR_LITERAL_TEMPLATE_NOT_CAPTURED` observé sur `L1 Chimie - Tremplin > AN`.
- Après le changement de semaine destiné à obtenir un `getTimetable` littéral, le collecteur attend désormais explicitement une requête du bon `resourceId`, encodée en `Integer` littéral et portant la valeur de semaine attendue.
- Un ancien body GWT encore encodé en back-reference ne peut plus être pris par erreur comme nouveau modèle simplement parce qu’il a été capturé quelques millisecondes avant le body littéral.
- Le collecteur vérifie le cache mémoire, `latestTimetableRequest` et l’historique récent avant de déclarer l’échec, sans ralentir les EDT déjà compatibles.
- Les protections anti-quota et l’audit de bout en bout de la v4.6.2 sont conservés.

## v4.6.2 — stockage étendu et protection anti-quota

- Ajout de la permission Chromium/Brave `unlimitedStorage` : les 216 payloads complets ne sont plus limités par le quota standard de `chrome.storage.local`.
- Si un profil est déjà proche de la limite au moment de la mise à jour, le collecteur compacte automatiquement les anciens diagnostics volumineux puis retente l’écriture.
- Les diagnostics d’audit conservent les résumés et les différences utiles, mais tronquent les duplications de grosses réponses GWT afin de ne plus concurrencer les payloads des EDT.
- Le démarrage d’une synchronisation complète compacte les anciens diagnostics, sans supprimer les emplois du temps déjà récupérés.

## Diagnostic

1. Ouvre le popup de l'extension.
2. Clique sur **Effacer les diagnostics** avant un test propre.
3. Lance la synchronisation ou **Relancer les échecs** depuis Planilim.
4. Quand le test est terminé, rouvre le popup et clique sur **Exporter les diagnostics**.
5. Envoie le fichier `planilim-diagnostic-....json`.

L'export n'inclut pas les cookies ni les en-têtes `Authorization`. Il contient les corps GWT et réponses ADE nécessaires pour comprendre les cas restants.

---

# Collecteur administrateur 4.5.6

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.


## 4.5.3
- Parcours unique conservé, mais plus aucune synchronisation en parallèle avec la sélection de l’EDT suivant.
- Un EDT reste sélectionné pendant toute la récupération de ses 44 semaines.
- Passage de confirmation supplémentaire sur l’arbre virtualisé avant de déclarer la découverte terminée.


## v4.5.3
Le parcours unique de l’arbre est conservé, mais la récupération annuelle revient au moteur stable validé (bootstrap à deux traces réelles + génération GWT). Le modèle RPC simplifié introduit en 4.5.x n’est plus utilisé par le pipeline administrateur. Jusqu’à 4 semaines sont synchronisées en parallèle pour un seul EDT à la fois.


## v4.5.5
- La sélection d'un EDT est retentée automatiquement si ExtJS perd le premier clic pendant un rerendu.
- Les semaines RPC en échec sont rejouées automatiquement en séquence complète et de façon séquentielle, uniquement après le passage rapide.
- La semaine réellement visible dans ADE est fusionnée avec la semaine RPC avant publication afin de récupérer les cours visibles que le décodeur GWT aurait partiellement normalisés.
- Les corrections de parcours de la v4.5.4 sont conservées.


## v4.5.6
- Si ADE ne confirme pas immédiatement la sélection d'un EDT, la ressource est resélectionnée jusqu'à deux fois avant d'être déclarée en échec.
- Le moteur stable rejoue jusqu'à quatre fois uniquement les semaines encore en échec, avec temporisation croissante.
- Le moteur rapide utilisé par « Relancer les échecs » effectue désormais trois passes ciblées sur les seules semaines ratées au lieu de refaire dépendre tout l'EDT d'un unique passage.
- Les résultats partiels remontent maintenant le nombre de semaines en échec et un résumé des codes techniques afin de distinguer un problème réseau d'un problème de décodage.


## v4.5.9 — replay GWT vérifié

- Les modèles `method10getTimetable` utilisant une back-reference GWT ne sont plus mutés localement.
- ADE est déplacé directement sur une semaine produisant un `Integer` littéral, puis ce body natif sert de modèle annuel.
- Une collecte partielle n'écrase plus jamais le dernier payload complet.
- Un EDT n'est marqué réussi que si toutes les semaines demandées ont été décodées avec succès.
- En cas d'échec de replay, le diagnostic compare automatiquement le body natif et le body reconstruit.


## v4.6.1 — garde de cohérence et audit de bout en bout

La synchronisation rapide conserve plusieurs requêtes `getTimetable` en parallèle, mais vérifie désormais jusqu’à huit semaines sentinelles en les rejouant séquentiellement. Si un seul événement diffère, le résultat parallèle est abandonné et l’EDT est entièrement retéléchargé séquentiellement avant publication. Le payload stocké indique alors `collectionMode: sequential-fallback`.

L’audit de l’EDT affiché compare maintenant aussi le payload déjà stocké avec le décodage séquentiel (`decodedNotStored` / `storedNotDecoded`) et sélectionne les onglets de semaine par date exacte, y compris au passage décembre → janvier.

## Diagnostic des cours manquants — v4.6.0

Cette version ajoute un audit ciblé d'un emploi du temps. Ouvrez ADE, sélectionnez l'EDT concerné, puis ouvrez le popup de l'extension et cliquez sur **Auditer l’EDT affiché dans ADE**. L'extension parcourt l'année semaine par semaine, compare les événements visibles dans ADE avec ceux décodés depuis `method10getTimetable`, et enregistre uniquement les semaines divergentes avec les événements bruts utiles. Une fois l'audit terminé, utilisez **Exporter les diagnostics** et transmettez le JSON généré.


## Export diagnostic robuste (4.6.5)

L’export des diagnostics est désormais déclenché directement par le service worker via l’API Downloads afin d’éviter les blocages du popup lors du transfert de gros JSON. Les erreurs `COLLECTOR_VISIBLE_RPC_MISMATCH` enregistrent maintenant la semaine, les événements visibles ADE, les événements décodés et leurs différences.
