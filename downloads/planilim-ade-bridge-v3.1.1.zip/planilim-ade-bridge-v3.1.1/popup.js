'use strict';

const $ = id => document.getElementById(id);
const SITE_URL = 'https://tremble-e.github.io/Site/#planning';
let currentStatus = null;
let busy = false;

function send(type) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type }, response => {
      const error = chrome.runtime.lastError;
      resolve(error
        ? { ok: false, code: 'POPUP_RUNTIME_ERROR', message: error.message }
        : response);
    });
  });
}

function formatSyncDate(value) {
  if (!value) return 'Jamais';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getUiState(status) {
  const configured = Boolean(status?.v3?.configured || status?.profile?.requestCaptured);
  const setup = status?.v3?.setupState || null;
  const sync = status?.v3?.syncState || status?.academicSyncStatus || null;
  const cache = status?.academicSyncCacheSummary || null;
  const syncState = sync?.state || '';
  const setupState = setup?.state || '';

  if (['bootstrapping', 'syncing_initial_year'].includes(setupState) ||
      ['syncing', 'preparing_fresh_base', 'running'].includes(syncState)) {
    return {
      kind: 'busy',
      title: 'Synchronisation en cours',
      message: 'ADE est synchronisé automatiquement. Vous pouvez fermer cette fenêtre.',
      button: 'Synchronisation…'
    };
  }

  if (syncState === 'auth_required' || status?.academicSyncStatus?.state === 'auth_required') {
    return {
      kind: 'auth',
      title: 'Reconnexion nécessaire',
      message: 'Votre session universitaire a expiré. Reconnectez-vous à ADE pour reprendre la synchronisation.',
      button: 'Se reconnecter à ADE'
    };
  }

  if (['waiting_for_ade', 'waiting_for_login'].includes(setupState)) {
    return {
      kind: 'connect',
      title: 'Connexion à ADE en attente',
      message: 'Terminez la connexion UNILIM dans l’onglet ADE. La détection reprendra automatiquement.',
      button: 'Ouvrir ADE'
    };
  }

  if (configured) {
    return {
      kind: 'sync',
      title: 'Planning connecté',
      message: cache?.eventCount
        ? `${cache.eventCount} cours sont disponibles dans Planilim.`
        : 'ADE est connecté. Lancez la première synchronisation.',
      button: 'Synchroniser maintenant'
    };
  }

  return {
    kind: 'connect',
    title: 'Planning non connecté',
    message: 'Connectez une fois votre planning ADE, puis Planilim pourra le mettre à jour automatiquement.',
    button: 'Connecter mon planning ADE'
  };
}

function render(status) {
  currentStatus = status || {};
  const ui = getUiState(currentStatus);
  const cache = currentStatus?.academicSyncCacheSummary || null;

  $('dot').className = `dot${ui.kind === 'sync' ? ' ok' : ui.kind === 'auth' ? ' bad' : ''}`;
  $('title').textContent = ui.title;
  $('message').textContent = ui.message;
  $('mainButton').textContent = ui.button;
  $('mainButton').disabled = busy || ui.kind === 'busy';

  $('summary').hidden = !cache;
  $('events').textContent = cache?.eventCount ?? 0;
  $('lastSync').textContent = formatSyncDate(cache?.updatedAt || currentStatus?.lastSuccessfulSyncAt);
}

async function refresh() {
  const status = await send('PLANILIM_STATUS');
  render(status);
}

async function runPrimaryAction() {
  const ui = getUiState(currentStatus || {});
  if (ui.kind === 'busy') return;

  busy = true;
  render(currentStatus || {});

  if (ui.kind === 'sync') {
    await send('PLANILIM_V3_STABLE_FULL_SYNC');
  } else {
    await send('PLANILIM_V3_CONNECT');
  }

  busy = false;
  await refresh();
}

$('mainButton').addEventListener('click', runPrimaryAction);
$('siteButton').addEventListener('click', () => chrome.tabs.create({ url: SITE_URL }));

refresh();
setInterval(refresh, 1800);
