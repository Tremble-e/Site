# Collecteur administrateur Planilim 4.2.2

Extension réservée à l’administrateur de Planilim, prévue pour Brave sous Windows.

## Utilisation

1. Se connecter à son compte administrateur sur Planilim.
2. Cliquer sur **Récupérer et synchroniser les EDT**.
3. Se connecter à ADE si Brave le demande, puis revenir sur Planilim.
4. Garder ADE ouvert pendant la collecte.

Le collecteur parcourt uniquement **Groupes Etudiants > Faculté des Sciences et Techniques**, restaure automatiquement les filières déjà enregistrées, récupère leurs 44 semaines universitaires et publie chaque planning terminé. Les étudiants n’installent jamais cette extension et ne voient aucune mention de celle-ci.

## Confidentialité

L’extension utilise uniquement la session ADE ouverte dans Brave. Elle ne demande pas l’accès direct aux cookies et n’enregistre ni identifiant ni mot de passe UNILIM. Aucun cookie ou ticket CAS n’est transmis à Planilim.

Le pont avec le site est limité à `https://tremble-e.github.io/Site/`.

## Version 4.2.2

- exploration limitée au seul sous-arbre `Faculté des Sciences et Techniques` ;
- les facultés voisines ne sont plus ouvertes ni proposées à la synchronisation ;
- tous les paramètres de périmètre sont désormais transmis du site jusqu’à ADE.

## Version 4.2.1

- balayage accéléré du grand arbre virtualisé d'ADE ;
- délai de sécurité renforcé lorsque le catalogue contient beaucoup de formations ;
- périmètre strict `Groupes Etudiants` et récupération annuelle conservés.

## Version 4.2.0

- synchronisation administrateur en un seul parcours ;
- exploration limitée à **Groupes Etudiants** ;
- restauration automatique du chemin ADE d’une filière ;
- correction du clic sur les vraies commandes de semaine ADE ;
- prise en charge des chaînes JavaScript renvoyées par GWT ;
- validation réelle réussie sur Brave : 44 semaines sur 44, 669 cours, aucune semaine en erreur pour la ressource test.
