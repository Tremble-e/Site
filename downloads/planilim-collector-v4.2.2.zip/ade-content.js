(() => {
  if (globalThis.__MON_EDT_SCRAPER_V420__) return;
  globalThis.__MON_EDT_SCRAPER_V420__ = true;

  const DATE_RE =
    /\b(?:lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)?\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\b/i;

  const TIME_RANGE_RE =
    /\b(\d{1,2})\s*(?:h|:)\s*(\d{2})\s*[-–—]\s*(\d{1,2})\s*(?:h|:)\s*(\d{2})\b/i;

  const HALF_HOUR_LINE_RE = /^\d{1,2}h\d{2}-?$/i;

  function clean(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();
  }

  function multiline(el) {
    return String(el?.innerText || el?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/\r/g, "")
      .split("\n")
      .map(clean)
      .filter(Boolean)
      .join("\n");
  }

  function linesOf(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/\r/g, "")
      .split("\n")
      .map(clean)
      .filter(Boolean);
  }

  function visible(el) {
    if (!(el instanceof Element)) return false;

    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();

    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      style.opacity !== "0" &&
      rect.width > 1 &&
      rect.height > 1
    );
  }

  function isoDate(match) {
    return `${match[3]}-${String(match[2]).padStart(2, "0")}-${String(
      match[1]
    ).padStart(2, "0")}`;
  }

  function findDayHeaders() {
    const candidates = [];

    for (const el of document.querySelectorAll("div, span, td, th")) {
      if (!visible(el)) continue;

      const text = clean(multiline(el).replace(/\n+/g, " "));
      if (!text || text.length > 100) continue;

      const match = text.match(DATE_RE);
      if (!match) continue;

      const rect = el.getBoundingClientRect();

      candidates.push({
        date: isoDate(match),
        label: text,
        x: rect.left + rect.width / 2,
        width: rect.width
      });
    }

    const byDate = new Map();

    for (const item of candidates) {
      const old = byDate.get(item.date);

      if (!old || item.width > old.width) {
        byDate.set(item.date, item);
      }
    }

    return [...byDate.values()].sort((a, b) => a.x - b.x);
  }

  function normalizeTime(h, m) {
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  }

  function nearestDay(headers, rect) {
    if (!headers.length) return null;

    const center = rect.left + rect.width / 2;
    let best = headers[0];
    let distance = Math.abs(best.x - center);

    for (const header of headers.slice(1)) {
      const current = Math.abs(header.x - center);

      if (current < distance) {
        best = header;
        distance = current;
      }
    }

    return best;
  }

  function isTimeScale(raw, rect) {
    const lines = linesOf(raw);
    const clocks = lines.filter((line) => HALF_HOUR_LINE_RE.test(line));

    return (
      clocks.length >= 8 ||
      (rect.width < 80 && rect.height > 250) ||
      (lines.length >= 12 && clocks.length / lines.length > 0.6)
    );
  }

  function isLeafWithTime(el) {
    const raw = multiline(el);

    if (!TIME_RANGE_RE.test(raw)) return false;

    for (const child of el.children) {
      if (TIME_RANGE_RE.test(multiline(child))) return false;
    }

    return true;
  }

  function dedupe(values) {
    const seen = new Set();
    const out = [];

    for (const value of values) {
      const text = clean(value);
      const key = text.toLocaleLowerCase("fr");

      if (!text || seen.has(key)) continue;

      seen.add(key);
      out.push(text);
    }

    return out;
  }

  function inferFields(details) {
    const groupLine =
      details.find((line) => /^(CM|TD|TP|TDP|CTD)\b.*\bGR\d+/i.test(line)) ||
      null;

    const building =
      details.find((line) => /^BATIMENT\b/i.test(line)) || null;

    const room =
      details.find((line) =>
        /^(?:[A-Z]\s*\d+(?:\.\d+)?|AMP(?:HI)?\b.*|SALLE\b.*)/i.test(line)
      ) || null;

    const teacherCandidates = details.filter((line) => {
      if (line === groupLine || line === building || line === room) return false;
      if (/^(CM|TD|TP|TDP|CTD)\b/i.test(line)) return false;

      return /[A-Za-zÀ-ÿ]{2,}\s+[A-Za-zÀ-ÿ]{2,}/.test(line);
    });

    return {
      groupLine,
      room,
      building,
      teacherCandidates
    };
  }

  function parseEvent(el, headers) {
    if (!visible(el)) return null;

    const rect = el.getBoundingClientRect();
    const rawText = multiline(el);

    if (isTimeScale(rawText, rect)) return null;

    const time = rawText.match(TIME_RANGE_RE);
    if (!time) return null;

    const day = nearestDay(headers, rect);
    if (!day) return null;

    const logical = dedupe(
      linesOf(rawText).filter(
        (line) => !TIME_RANGE_RE.test(line) && !DATE_RE.test(line)
      )
    );

    const title = logical.shift() || "Cours";
    const details = logical;
    const inferred = inferFields(details);

    return {
      date: day.date,
      dayLabel: day.label,
      startTime: normalizeTime(time[1], time[2]),
      endTime: normalizeTime(time[3], time[4]),
      title,
      details,
      ...inferred,
      rawText,
      source: "ADE"
    };
  }

  function uniqueEvents(events) {
    const seen = new Set();
    const out = [];

    for (const event of events) {
      const key = [
        event.date,
        event.startTime,
        event.endTime,
        event.title,
        event.details.join("¦")
      ].join("|");

      if (seen.has(key)) continue;

      seen.add(key);
      out.push(event);
    }

    return out;
  }

  function planningTreeSnapshot() {
    const tree = globalThis.PlanilimAdeTree;
    if (!tree?.snapshotDocument) {
      return {
        ok: false,
        code: "ADE_TREE_HELPER_MISSING",
        rowCount: 0,
        selected: null,
        rows: []
      };
    }
    return tree.snapshotDocument(document);
  }

  async function scanPlanningTree() {
    const tree = globalThis.PlanilimAdeTree;
    const scroller = [...document.querySelectorAll(".x-grid3-scroller")]
      .find((element) => element.querySelector(".x-tree3-node"));
    if (!tree?.rawRowsFromDocument || !scroller) return planningTreeSnapshot();

    const originalTop = scroller.scrollTop;
    // La grille ExtJS virtualise l'arbre. Le gestionnaire de scroll remplace
    // ses lignes de façon synchrone, puis finalise le rendu dans la même
    // boucle d'événements. Un pas presque égal à la hauteur visible couvre
    // toutes les lignes sans les très nombreux recouvrements de l'ancien
    // balayage. Le court délai reste suffisant pour les machines plus lentes.
    const step = Math.max(320, Math.floor(scroller.clientHeight * 0.94));
    const byResource = new Map();

    try {
      for (let top = 0; top <= scroller.scrollHeight; top += step) {
        scroller.scrollTop = Math.min(top, scroller.scrollHeight);
        scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
        await new Promise((resolve) => setTimeout(resolve, 30));
        for (const raw of tree.rawRowsFromDocument(document)) {
          const key = raw.resourceId == null ? raw.nodeId : String(raw.resourceId);
          if (!byResource.has(key)) byResource.set(key, raw);
          else if (raw.selected) byResource.set(key, raw);
        }
      }
    } finally {
      scroller.scrollTop = originalTop;
      scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
      await new Promise((resolve) => setTimeout(resolve, 40));
    }

    const rows = tree.normalizeRows([...byResource.values()]);
    const liveSelected = planningTreeSnapshot().selected;
    const selected = liveSelected || rows.find((row) => row.selected) || null;
    return {
      ok: rows.length > 0,
      code: rows.length > 0 ? "ADE_TREE_SCAN_READY" : "ADE_TREE_NOT_FOUND",
      rowCount: rows.length,
      selected,
      rows
    };
  }

  function selectedPlanningResource() {
    return planningTreeSnapshot().selected || null;
  }

  function selectedPlanningLabel() {
    const selected = selectedPlanningResource();
    if (selected?.label) return selected.label;

    const selectors = [
      ".x-tree3-node-selected .x-tree3-node-text",
      ".x-tree3-node-selected .x-tree3-node-text span",
      ".x-tree3-node-selected",
      ".x-tree-node-selected",
      ".x-grid3-row-selected .x-grid3-cell-inner",
      ".x-view-selected",
      "[aria-selected='true']"
    ];

    const candidates = [];

    for (const selector of selectors) {
      for (const el of document.querySelectorAll(selector)) {
        if (!visible(el)) continue;
        const text = clean(String(el.innerText || el.textContent || "").replace(/\n+/g, " "));
        if (!text || text.length > 90) continue;
        if (/^S\d{1,2}\s+du\s+/i.test(text)) continue;
        if (DATE_RE.test(text)) continue;
        if (TIME_RANGE_RE.test(text)) continue;
        candidates.push(text);
      }
    }

    const unique = dedupe(candidates);
    if (!unique.length) return null;

    // Les libellés de ressource courts (ex. « L3 Maths ») sont préférés
    // aux conteneurs qui concatènent plusieurs éléments de l'arbre.
    unique.sort((a, b) => {
      const aScore = (/^L\d\b/i.test(a) ? 100 : 0) - a.length;
      const bScore = (/^L\d\b/i.test(b) ? 100 : 0) - b.length;
      return bScore - aScore;
    });

    return unique[0] || null;
  }

  function dispatchPlanningClick(element, clickCount = 1) {
    if (!element) return;
    const view = element.ownerDocument?.defaultView || window;
    const common = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view,
      detail: clickCount,
      button: 0,
      buttons: 1
    };

    try {
      element.dispatchEvent(new PointerEvent("pointerdown", common));
    } catch {}
    element.dispatchEvent(new MouseEvent("mousedown", common));
    try {
      element.dispatchEvent(new PointerEvent("pointerup", { ...common, buttons: 0 }));
    } catch {}
    element.dispatchEvent(new MouseEvent("mouseup", { ...common, buttons: 0 }));
    element.dispatchEvent(new MouseEvent("click", { ...common, buttons: 0 }));
    if (clickCount >= 2) {
      element.dispatchEvent(new MouseEvent("dblclick", { ...common, buttons: 0, detail: 2 }));
    }
  }

  function domRowForResource(resource) {
    const targetNodeId = String(resource?.nodeId || "");
    if (targetNodeId) {
      const byNode = [...document.querySelectorAll(".x-grid3-row")].find((row) =>
        row.querySelector(".x-tree3-node[id^='Direct Planning Tree_']")?.id === targetNodeId
      );
      if (byNode) return byNode;
    }

    const targetId = Number(resource?.resourceId);
    if (!Number.isFinite(targetId)) return null;

    return [...document.querySelectorAll(".x-grid3-row")].find((row) => {
      const node = row.querySelector(
        ".x-tree3-node[id^='Direct Planning Tree_']"
      );
      return globalThis.PlanilimAdeTree?.parseResourceId(node?.id) === targetId;
    }) || null;
  }

  function planningScroller() {
    return [...document.querySelectorAll(".x-grid3-scroller")]
      .find((element) => element.querySelector(".x-tree3-node")) || null;
  }

  async function revealPlanningPath(target) {
    const parts = String(target?.path || "")
      .split(">")
      .map(clean)
      .filter(Boolean);
    const scroller = planningScroller();
    if (!scroller || parts.length < 2) return { resource: null, row: null };

    const samePath = (row, depth) => {
      const rowParts = Array.isArray(row?.pathParts) ? row.pathParts.map(clean) : [];
      return Number(row?.level) === depth + 1 &&
        rowParts.length >= depth + 1 &&
        parts.slice(0, depth + 1).every((part, index) => rowParts[index] === part);
    };

    const findPart = async (depth) => {
      const step = Math.max(280, Math.floor(scroller.clientHeight * 0.88));
      for (let top = 0; top <= scroller.scrollHeight; top += step) {
        scroller.scrollTop = Math.min(top, scroller.scrollHeight);
        scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
        await new Promise((resolve) => setTimeout(resolve, 40));
        const snapshot = planningTreeSnapshot();
        const resource = snapshot.rows.find((row) => samePath(row, depth));
        const domRow = resource ? domRowForResource(resource) : null;
        if (resource && domRow) return { resource, row: domRow };
      }
      return { resource: null, row: null };
    };

    let current = { resource: null, row: null };
    for (let depth = 0; depth < parts.length; depth += 1) {
      current = await findPart(depth);
      if (!current.resource || !current.row) return { resource: null, row: null };
      if (depth >= parts.length - 1) return current;
      if (current.resource.expanded === true) continue;

      const clickTarget = current.row.querySelector(".x-tree3-node-text") || current.row;
      try { current.row.scrollIntoView({ block: "nearest" }); } catch {}
      dispatchPlanningClick(clickTarget, 2);
      await new Promise((resolve) => setTimeout(resolve, 650));
    }

    return current;
  }

  async function revealPlanningResource(target) {
    let snapshot = planningTreeSnapshot();
    let resource = globalThis.PlanilimAdeTree?.findRow(snapshot.rows, target);
    let row = resource ? domRowForResource(resource) : null;
    if (resource && row) return { resource, row };

    if (target?.path) {
      const revealed = await revealPlanningPath(target);
      if (revealed.resource && revealed.row) return revealed;
    }

    const scroller = planningScroller();
    if (!scroller) return { resource: null, row: null };
    const step = Math.max(300, Math.floor(scroller.clientHeight * 0.9));

    for (let top = 0; top <= scroller.scrollHeight; top += step) {
      scroller.scrollTop = Math.min(top, scroller.scrollHeight);
      scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
      await new Promise((resolve) => setTimeout(resolve, 40));
      snapshot = planningTreeSnapshot();
      resource = globalThis.PlanilimAdeTree?.findRow(snapshot.rows, target);
      row = resource ? domRowForResource(resource) : null;
      if (resource && row) return { resource, row };
    }

    return { resource: null, row: null };
  }

  async function waitForSelectedResource(resourceId, timeoutMs = 6500) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const selected = selectedPlanningResource();
      if (selected?.resourceId === resourceId) return selected;
      await new Promise((resolve) => setTimeout(resolve, 120));
    }
    return null;
  }

  async function selectPlanningResource(target) {
    const revealed = await revealPlanningResource(target);
    const resource = revealed.resource;
    if (!resource) {
      return {
        ok: false,
        code: "ADE_RESOURCE_NOT_VISIBLE",
        target: target || null,
        tree: planningTreeSnapshot()
      };
    }

    if (resource.selected) {
      return { ok: true, code: "ADE_RESOURCE_ALREADY_SELECTED", resource };
    }

    const row = revealed.row;
    const clickTarget = row?.querySelector(".x-tree3-node-text") || row;
    if (!clickTarget) {
      return { ok: false, code: "ADE_RESOURCE_ROW_MISSING", resource };
    }

    try { row.scrollIntoView({ block: "nearest" }); } catch {}
    dispatchPlanningClick(clickTarget, 1);

    const selected = await waitForSelectedResource(resource.resourceId);
    return selected
      ? { ok: true, code: "ADE_RESOURCE_SELECTED", resource: selected }
      : { ok: false, code: "ADE_RESOURCE_SELECTION_TIMEOUT", resource };
  }

  async function togglePlanningBranch(target) {
    const revealed = await revealPlanningResource(target);
    const resource = revealed.resource;
    if (!resource) return { ok: false, code: "ADE_RESOURCE_NOT_VISIBLE", target };

    const row = revealed.row;
    const clickTarget = row?.querySelector(".x-tree3-node-text") || row;
    if (!clickTarget) return { ok: false, code: "ADE_RESOURCE_ROW_MISSING", resource };

    const wasExpanded = resource.expanded === true;
    try { row.scrollIntoView({ block: "nearest" }); } catch {}
    dispatchPlanningClick(clickTarget, 2);
    await new Promise((resolve) => setTimeout(resolve, 500));

    const nextResource = globalThis.PlanilimAdeTree?.findRow(
      planningTreeSnapshot().rows,
      target
    );
    const expanded = nextResource?.expanded === true;
    return {
      ok: wasExpanded !== expanded || expanded,
      code: expanded ? "ADE_BRANCH_EXPANDED" : "ADE_BRANCH_NOT_EXPANDED",
      resource: nextResource || resource,
      expanded
    };
  }

  async function expandAllPlanningBranches(options = {}) {
    const maxBranches = Math.max(1, Math.min(300, Number(options.maxBranches) || 200));
    const maxDurationMs = Math.max(5000, Math.min(60000, Number(options.maxDurationMs) || 45000));
    const maxDepth = Math.max(2, Math.min(8, Number(options.maxDepth) || 5));
    const scopeRoot = String(options.scopeRoot || "Groupes Etudiants").trim();
    const scopePath = String(options.scopePath || scopeRoot).trim();
    const rowTouchesScope = (row) => tree.pathTouchesScope(
      row.pathParts || row.path,
      scopePath
    );
    const startedAt = Date.now();
    let expandedCount = 0;
    const failedBranches = new Set();
    const branchKey = (row) => String(
      row?.nodeId || row?.resourceId || row?.path || row?.label || ""
    );
    let lastSnapshot = await scanPlanningTree();

    while (expandedCount < maxBranches && Date.now() - startedAt < maxDurationMs) {
      const branch = lastSnapshot.rows.find((row) =>
        row.expanded === false &&
        !failedBranches.has(branchKey(row)) &&
        Number(row.level) < maxDepth &&
        rowTouchesScope(row)
      );
      if (!branch) break;

      const result = await togglePlanningBranch(branch);
      if (!result?.expanded) {
        // Une branche qui ne s'ouvre pas est traitée comme un planning final
        // pour éviter de boucler indéfiniment sur un serveur ADE lent.
        failedBranches.add(branchKey(branch));
      } else {
        expandedCount += 1;
      }
      lastSnapshot = await scanPlanningTree();
    }

    const pendingBranchCount = lastSnapshot.rows.filter((row) =>
      row.expanded === false &&
      !failedBranches.has(branchKey(row)) &&
      Number(row.level) < maxDepth &&
      rowTouchesScope(row)
    ).length;
    const timeBudgetReached = Date.now() - startedAt >= maxDurationMs;

    return {
      ...lastSnapshot,
      ok: true,
      code: "ADE_TREE_EXPANDED_AND_SCANNED",
      expandedCount,
      failedBranchCount: failedBranches.size,
      scopeRoot,
      scopePath,
      maxDepth,
      pendingBranchCount,
      timeBudgetReached,
      truncated: pendingBranchCount > 0 || expandedCount >= maxBranches || timeBudgetReached
    };
  }

  function scrapeCurrentWeek() {
    const headers = findDayHeaders();
    const events = [];

    for (const el of document.querySelectorAll("div, td, span")) {
      if (!isLeafWithTime(el)) continue;

      const event = parseEvent(el, headers);

      if (event) events.push(event);
    }

    const cleanEvents = uniqueEvents(events).sort((a, b) =>
      `${a.date}T${a.startTime}`.localeCompare(`${b.date}T${b.startTime}`)
    );

    const planningResource = selectedPlanningResource();

    return {
      ok: headers.length >= 5,
      code: headers.length >= 5 ? "SCRAPE_OK" : "WEEK_HEADERS_NOT_FOUND",
      source: "university-planning",
      planningLabel: planningResource?.label || selectedPlanningLabel(),
      resourceId: planningResource?.resourceId ?? null,
      planningResource,
      week:
        headers.length >= 5
          ? {
              firstDate: headers[0].date,
              lastDate: headers[headers.length - 1].date
            }
          : null,
      events: cleanEvents,
      diagnostics: {
        href: location.href,
        dayHeaderCount: headers.length,
        eventCount: cleanEvents.length
      }
    };
  }


  function isoWeekNumber(isoDateValue) {
    const date = new Date(`${isoDateValue}T12:00:00Z`);
    if (Number.isNaN(date.getTime())) return null;

    const target = new Date(date.valueOf());
    const dayNr = (date.getUTCDay() + 6) % 7;

    target.setUTCDate(
      target.getUTCDate() -
      dayNr +
      3
    );

    const firstThursday =
      new Date(
        Date.UTC(
          target.getUTCFullYear(),
          0,
          4
        )
      );

    const firstDayNr =
      (
        firstThursday.getUTCDay() +
        6
      ) % 7;

    firstThursday.setUTCDate(
      firstThursday.getUTCDate() -
      firstDayNr +
      3
    );

    return (
      1 +
      Math.round(
        (
          target -
          firstThursday
        ) /
        604800000
      )
    );
  }

  function weekTabCandidates() {
    const values = [];

    for (
      const el
      of document.querySelectorAll(
        "button, a, td, div, span"
      )
    ) {
      if (!visible(el)) continue;

      const text =
        clean(
          String(
            el.innerText ||
            el.textContent ||
            ""
          )
            .replace(/\n+/g, " ")
        );

      const match =
        text.match(
          /^S(\d{1,2})\s+du\s+/i
        );

      if (
        !match ||
        text.length > 100
      ) {
        continue;
      }

      // Évite de retenir un grand conteneur qui contient déjà
      // plusieurs onglets de semaine.
      let childHasWeek = false;

      for (
        const child
        of el.children || []
      ) {
        const childText =
          clean(
            String(
              child.innerText ||
              child.textContent ||
              ""
            )
              .replace(/\n+/g, " ")
          );

        if (
          /^S\d{1,2}\s+du\s+/i.test(
            childText
          )
        ) {
          childHasWeek = true;
          break;
        }
      }

      if (childHasWeek) {
        continue;
      }

      const rect =
        el.getBoundingClientRect();

      values.push({
        el,
        text,
        active: Boolean(el.closest(".x-btn-pressed")),
        weekNumber:
          Number(match[1]),
        x:
          rect.left,
        width:
          rect.width
      });
    }

    const deduped =
      new Map();

    for (const item of values) {
      const key =
        `${item.weekNumber}|${item.text}`;

      const existing =
        deduped.get(key);

      if (
        !existing ||
        (item.el.matches("button, a, [role='button']") &&
          !existing.el.matches("button, a, [role='button']")) ||
        item.width < existing.width
      ) {
        deduped.set(
          key,
          item
        );
      }
    }

    return [
      ...deduped.values()
    ].sort(
      (a, b) =>
        a.x - b.x
    );
  }

  function clickLikeUser(el) {
    if (!(el instanceof Element)) {
      return false;
    }

    const target =
      (
        el.matches("button, a, [role='button']")
          ? el
          : el.querySelector("button, a, [role='button']")
      ) ||
      el.closest("button, a, [role='button'], td, div, span") ||
      el;

    try {
      target.scrollIntoView({
        block:
          "nearest",
        inline:
          "nearest"
      });
    } catch {}

    for (
      const type
      of [
        "pointerdown",
        "mousedown",
        "pointerup",
        "mouseup",
        "click"
      ]
    ) {
      try {
        target.dispatchEvent(
          new MouseEvent(
            type,
            {
              bubbles: true,
              cancelable: true,
              view: window,
              button: 0
            }
          )
        );
      } catch {}
    }

    try {
      if (
        typeof target.click ===
        "function"
      ) {
        target.click();
      }
    } catch {}

    return true;
  }

  function kickWeekNavigation() {
    const scraped =
      scrapeCurrentWeek();

    const candidates =
      weekTabCandidates();

    const activeWeek = candidates.find((item) => item.active)?.weekNumber ?? null;
    const currentWeek =
      scraped?.week?.firstDate
        ? isoWeekNumber(
            scraped.week.firstDate
          )
        : activeWeek;

    if (!candidates.length) {
      return {
        ok: false,
        code:
          "V3_WEEK_TABS_NOT_FOUND",
        diagnostics: {
          href:
            location.href,
          currentWeek,
          candidateCount: 0
        }
      };
    }

    let target = null;

    if (
      Number.isInteger(
        currentWeek
      )
    ) {
      target =
        candidates.find(
          (item) =>
            item.weekNumber ===
            currentWeek + 1
        ) ||
        candidates.find(
          (item) =>
            item.weekNumber !==
            currentWeek
        ) ||
        null;
    }

    if (!target) {
      target =
        candidates.length >= 2
          ? candidates[1]
          : candidates[0];
    }

    if (
      Number.isInteger(
        currentWeek
      ) &&
      target.weekNumber ===
        currentWeek &&
      candidates.length > 1
    ) {
      target =
        candidates.find(
          (item) =>
            item.weekNumber !==
            currentWeek
        ) || target;
    }

    const clicked =
      clickLikeUser(
        target.el
      );

    return {
      ok:
        Boolean(clicked),
      code:
        clicked
          ? "V3_WEEK_KICKED"
          : "V3_WEEK_KICK_FAILED",
      fromWeekNumber:
        currentWeek,
      targetWeekNumber:
        target.weekNumber,
      targetLabel:
        target.text,
      diagnostics: {
        href:
          location.href,
        candidateCount:
          candidates.length,
        candidates:
          candidates
            .slice(0, 14)
            .map(
              (item) => ({
                weekNumber:
                  item.weekNumber,
                text:
                  item.text
              })
            )
      }
    };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) return;

    if (message.type === "PLANILIM_PING") {
      sendResponse({
        ok: true,
        href: location.href
      });
      return;
    }

    if (message.type === "PLANILIM_SCRAPE_ADE" || message.type === "MON_EDT_V4_SCRAPE_PREVIEW") {
      sendResponse(scrapeCurrentWeek());
      return;
    }

    if (message.type === "MON_EDT_V4_KICK_WEEK") {
      sendResponse(kickWeekNavigation());
      return;
    }

      if (message.type === "PLANILIM_ADE_TREE_SNAPSHOT") {
        sendResponse(planningTreeSnapshot());
        return;
      }

    if (message.type === "PLANILIM_ADE_TREE_SCAN") {
      scanPlanningTree()
        .then(sendResponse)
        .catch((error) => sendResponse({
          ok: false,
          code: "ADE_TREE_SCAN_FAILED",
          message: String(error)
        }));
      return true;
    }

    if (message.type === "PLANILIM_ADE_EXPAND_AND_SCAN") {
      expandAllPlanningBranches(message.options || {})
        .then(sendResponse)
        .catch((error) => sendResponse({
          ok: false,
          code: "ADE_TREE_EXPANSION_FAILED",
          message: String(error)
        }));
      return true;
    }

    if (message.type === "PLANILIM_ADE_SELECT_RESOURCE") {
      selectPlanningResource(message.target || message)
        .then(sendResponse)
        .catch((error) => sendResponse({
          ok: false,
          code: "ADE_RESOURCE_SELECTION_FAILED",
          message: String(error)
        }));
      return true;
    }

    if (message.type === "PLANILIM_ADE_TOGGLE_BRANCH") {
      togglePlanningBranch(message.target || message)
        .then(sendResponse)
        .catch((error) => sendResponse({
          ok: false,
          code: "ADE_BRANCH_TOGGLE_FAILED",
          message: String(error)
        }));
      return true;
    }
  });
})();
