# Planilim Collector v4.5.9

Cette version corrige la cause identifiée par le diagnostic 4.5.7 : l’identification d’une requête `method10getTimetable` dépendait d’une back-reference GWT précise (`-8`). Les ressources sont désormais extraites depuis la structure réelle de `PlanningSelection`, et les semaines sérialisées sous forme de back-reference (`-3` à `-9`) sont décodées puis réécrites sous forme d’`Integer` explicite. Les outils de diagnostic sont conservés.

## Diagnostic

1. Ouvre le popup de l'extension.
2. Clique sur **Effacer les diagnostics** avant un test propre.
3. Lance la synchronisation ou **Relancer les échecs** depuis Planilim.
4. Quand le test est terminé, rouvre le popup et clique sur **Exporter les diagnostics**.
5. Envoie le fichier `planilim-diagnostic-....json`.

L'export n'inclut pas les cookies ni les en-têtes `Authorization`. Il contient les corps GWT et réponses ADE nécessaires pour comprendre les cas restants.

---

# Collecteur administrateur 4.5.6

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.


## 4.5.3
- Parcours unique conservé, mais plus aucune synchronisation en parallèle avec la sélection de l’EDT suivant.
- Un EDT reste sélectionné pendant toute la récupération de ses 44 semaines.
- Passage de confirmation supplémentaire sur l’arbre virtualisé avant de déclarer la découverte terminée.


## v4.5.3
Le parcours unique de l’arbre est conservé, mais la récupération annuelle revient au moteur stable validé (bootstrap à deux traces réelles + génération GWT). Le modèle RPC simplifié introduit en 4.5.x n’est plus utilisé par le pipeline administrateur. Jusqu’à 4 semaines sont synchronisées en parallèle pour un seul EDT à la fois.


## v4.5.5
- La sélection d'un EDT est retentée automatiquement si ExtJS perd le premier clic pendant un rerendu.
- Les semaines RPC en échec sont rejouées automatiquement en séquence complète et de façon séquentielle, uniquement après le passage rapide.
- La semaine réellement visible dans ADE est fusionnée avec la semaine RPC avant publication afin de récupérer les cours visibles que le décodeur GWT aurait partiellement normalisés.
- Les corrections de parcours de la v4.5.4 sont conservées.


## v4.5.6
- Si ADE ne confirme pas immédiatement la sélection d'un EDT, la ressource est resélectionnée jusqu'à deux fois avant d'être déclarée en échec.
- Le moteur stable rejoue jusqu'à quatre fois uniquement les semaines encore en échec, avec temporisation croissante.
- Le moteur rapide utilisé par « Relancer les échecs » effectue désormais trois passes ciblées sur les seules semaines ratées au lieu de refaire dépendre tout l'EDT d'un unique passage.
- Les résultats partiels remontent maintenant le nombre de semaines en échec et un résumé des codes techniques afin de distinguer un problème réseau d'un problème de décodage.


## v4.5.9 — replay GWT vérifié

- Les modèles `method10getTimetable` utilisant une back-reference GWT ne sont plus mutés localement.
- ADE est déplacé directement sur une semaine produisant un `Integer` littéral, puis ce body natif sert de modèle annuel.
- Une collecte partielle n'écrase plus jamais le dernier payload complet.
- Un EDT n'est marqué réussi que si toutes les semaines demandées ont été décodées avec succès.
- En cas d'échec de replay, le diagnostic compare automatiquement le body natif et le body reconstruit.
