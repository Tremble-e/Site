'use strict';

const SITE_URL = 'https://tremble-e.github.io/Site/#planning';
const $ = id => document.getElementById(id);

function send(type, payload = {}) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type, ...payload }, response => {
      const error = chrome.runtime.lastError;
      resolve(error
        ? { ok: false, code: 'POPUP_RUNTIME_ERROR', message: error.message }
        : response || {});
    });
  });
}

function formatSyncDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function uiState(status) {
  const syncState = status?.v3?.syncState?.state || status?.academicSyncStatus?.state || '';
  const resources = Array.isArray(status?.collector?.resources) ? status.collector.resources : [];
  const running = ['syncing', 'preparing_fresh_base', 'running', 'syncing_initial_year'].includes(syncState);

  if (running) {
    return {
      kind: 'busy',
      title: 'Synchronisation en cours',
      message: 'ADE est en cours de lecture. Garde l’onglet ouvert jusqu’à la fin.',
      hint: 'Tu peux suivre l’avancement et la publication depuis la partie Administration de Planilim.',
      resources
    };
  }

  if (syncState === 'auth_required') {
    return {
      kind: 'bad',
      title: 'Connexion ADE nécessaire',
      message: 'Ouvre Planilim et relance la synchronisation. Le collecteur ouvrira ADE pour te laisser te connecter.',
      hint: 'Les identifiants restent saisis uniquement sur la page officielle de l’Université.',
      resources
    };
  }

  return {
    kind: 'ready',
    title: resources.length ? 'Collecteur prêt à publier' : 'Collecteur prêt',
    message: 'Lance la récupération depuis le bouton réservé à l’administration de Planilim.',
    hint: 'Seule la Faculté des Sciences et Techniques est parcourue. Les étudiants ne voient jamais cette extension.',
    resources
  };
}

function render(status) {
  const ui = uiState(status || {});
  const resources = ui.resources;
  const latest = resources
    .map(resource => resource.updatedAt || resource.payload?.generatedAt || '')
    .filter(Boolean)
    .sort()
    .at(-1);

  const statusIcon = $('statusIcon');
  statusIcon.className = 'status-icon';
  if (ui.kind === 'ready') statusIcon.classList.add('ok');
  if (ui.kind === 'bad') statusIcon.classList.add('bad');
  if (ui.kind === 'busy') statusIcon.classList.add('busy');

  $('title').textContent = ui.title;
  $('message').textContent = ui.message;
  $('hint').textContent = ui.hint;
  $('mainButton').textContent = 'Ouvrir Planilim';
  $('mainButton').disabled = false;

  $('planningLabel').textContent = `${resources.length} filière${resources.length > 1 ? 's' : ''}`;
  $('planningChip').hidden = resources.length === 0;
  $('lastSync').textContent = formatSyncDate(latest);
  $('lastSyncChip').hidden = !latest;

  const diagnosticCount = Number(status?.diagnostics?.count || 0);
  const hasReference = Boolean(status?.diagnostics?.hasSuccessReference);
  $('exportDiagnostics').textContent = diagnosticCount
    ? `Exporter les diagnostics (${diagnosticCount})`
    : 'Exporter les diagnostics';
  $('exportDiagnostics').disabled = diagnosticCount === 0 && !hasReference;
  $('clearDiagnostics').disabled = diagnosticCount === 0 && !hasReference;
  $('diagStatus').textContent = diagnosticCount
    ? `${diagnosticCount} anomalie${diagnosticCount > 1 ? 's' : ''} enregistrée${diagnosticCount > 1 ? 's' : ''}${hasReference ? ' + 1 cas réussi de référence' : ''}.`
    : (hasReference ? 'Un cas réussi de référence est enregistré.' : 'Aucun diagnostic enregistré pour le moment.');
}

async function openPlanilim() {
  await chrome.tabs.create({ url: SITE_URL, active: true });
  window.close();
}

async function exportDiagnostics() {
  const button = $('exportDiagnostics');
  button.disabled = true;
  $('diagStatus').textContent = 'Préparation du fichier de diagnostic…';
  const result = await send('PLANILIM_DEBUG_DIAGNOSTICS_EXPORT');
  if (!result?.ok || !result?.data) {
    $('diagStatus').textContent = result?.message || 'Impossible de préparer les diagnostics.';
    button.disabled = false;
    return;
  }

  const blob = new Blob([JSON.stringify(result.data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = result.fileName || 'planilim-diagnostic.json';
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  $('diagStatus').textContent = 'Diagnostic exporté. Envoie-moi simplement le fichier JSON.';
  button.disabled = false;
}

async function clearDiagnostics() {
  const result = await send('PLANILIM_DEBUG_DIAGNOSTICS_CLEAR');
  if (!result?.ok) {
    $('diagStatus').textContent = result?.message || 'Impossible d’effacer les diagnostics.';
    return;
  }
  const status = await send('PLANILIM_STATUS');
  render(status);
  $('diagStatus').textContent = 'Diagnostics effacés. Tu peux relancer une synchronisation propre.';
}

$('mainButton').addEventListener('click', openPlanilim);
$('exportDiagnostics').addEventListener('click', exportDiagnostics);
$('clearDiagnostics').addEventListener('click', clearDiagnostics);
send('PLANILIM_STATUS').then(render);
