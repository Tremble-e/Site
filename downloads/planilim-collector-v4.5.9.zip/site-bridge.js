(() => {
  "use strict";

  if (globalThis.__PLANILIM_SITE_BRIDGE_V450__) {
    return;
  }

  globalThis.__PLANILIM_SITE_BRIDGE_V450__ = true;

  const SITE_ORIGIN =
    "https://tremble-e.github.io";

  const REQUEST_SOURCE =
    "planilim-site";

  const RESPONSE_SOURCE =
    "planilim-extension";

  function allowedPage() {
    return (
      window.location.origin ===
        SITE_ORIGIN &&
      window.location.pathname.startsWith(
        "/Site/"
      )
    );
  }

  if (!allowedPage()) {
    return;
  }

  function post(type, requestId, payload) {
    window.postMessage(
      {
        source:
          RESPONSE_SOURCE,
        type,
        requestId:
          requestId || null,
        payload
      },
      SITE_ORIGIN
    );
  }

  async function runtimeMessage(type, payload = {}) {
    return await chrome.runtime.sendMessage({
      type,
      ...payload
    });
  }

  async function publicStatus() {
    const status =
      await runtimeMessage(
        "PLANILIM_STATUS"
      );

    return {
      ok:
        Boolean(status?.profile),
      extensionVersion:
        chrome.runtime.getManifest().version,
      profile:
        status?.profile
          ? {
              mode:
                status.profile.mode ||
                null,
              resourceId:
                status.profile.resourceId ??
                null,
              sampleWeek:
                status.profile.sampleWeek ||
                null,
              planningLabel:
                status.profile.planningLabel ||
                null
            }
          : null,
      academicSyncStatus:
        status?.academicSyncStatus ||
        null,
      academicSyncCacheSummary:
        status?.academicSyncCacheSummary ||
        null,
      lastSuccessfulSyncAt:
        status?.lastSuccessfulSyncAt ||
        null,
      collector:
        status?.collector || null,
      v3:
        status?.v3
          ? {
              configured:
                Boolean(
                  status.v3.configured
                ),
              setupState:
                status.v3.setupState ||
                null,
              syncState:
                status.v3.syncState ||
                null
            }
          : null
    };
  }

  async function annualPayload() {
    return await runtimeMessage(
      "PLANILIM_ACADEMIC_YEAR_PAYLOAD"
    );
  }

  async function smartRefresh() {
    const sync =
      await runtimeMessage(
        "PLANILIM_SMART_ACADEMIC_REFRESH"
      );

    if (
      sync?.code ===
      "AUTH_REQUIRED"
    ) {
      return {
        ok: false,
        code:
          "AUTH_REQUIRED",
        sync,
        payload:
          await annualPayload()
      };
    }

    return {
      ok:
        Boolean(sync?.ok),
      code:
        sync?.code ||
        "REFRESH_FINISHED",
      sync,
      payload:
        await annualPayload()
    };
  }

  async function fullSync() {
    const sync =
      await runtimeMessage(
        "PLANILIM_SYNC_FULL_ACADEMIC_YEAR"
      );

    if (
      sync?.code ===
      "AUTH_REQUIRED"
    ) {
      return {
        ok: false,
        code:
          "AUTH_REQUIRED",
        sync,
        payload:
          await annualPayload()
      };
    }

    return {
      ok:
        Boolean(sync?.ok),
      code:
        sync?.code ||
        "FULL_SYNC_FINISHED",
      sync,
      payload:
        await annualPayload()
    };
  }

  window.addEventListener(
    "message",
    async (event) => {
      if (
        event.source !== window ||
        event.origin !== SITE_ORIGIN
      ) {
        return;
      }

      const data =
        event.data || {};

      if (
        data.source !==
        REQUEST_SOURCE
      ) {
        return;
      }

      const requestId =
        String(
          data.requestId || ""
        );

      if (!requestId) {
        return;
      }

      try {
        switch (data.type) {
          case "PLANILIM_ADE_STATUS":
            post(
              "PLANILIM_ADE_STATUS_RESULT",
              requestId,
              await publicStatus()
            );
            break;

          case "PLANILIM_ADE_CONNECT":
            post(
              "PLANILIM_ADE_CONNECT_RESULT",
              requestId,
              await runtimeMessage(
                "PLANILIM_V3_CONNECT"
              )
            );
            break;

          case "PLANILIM_ADE_GET_PAYLOAD":
            post(
              "PLANILIM_ADE_PAYLOAD_RESULT",
              requestId,
              await annualPayload()
            );
            break;

          case "PLANILIM_ADE_REFRESH":
            post(
              "PLANILIM_ADE_REFRESH_RESULT",
              requestId,
              await smartRefresh()
            );
            break;

          case "PLANILIM_ADE_FULL_SYNC":
            post(
              "PLANILIM_ADE_FULL_SYNC_RESULT",
              requestId,
              await fullSync()
            );
            break;

          case "PLANILIM_COLLECTOR_TREE":
            post(
              "PLANILIM_COLLECTOR_TREE_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_TREE_SNAPSHOT")
            );
            break;

          case "PLANILIM_COLLECTOR_EXPAND_AND_SCAN":
            post(
              "PLANILIM_COLLECTOR_EXPAND_AND_SCAN_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_EXPAND_AND_SCAN", {
                maxBranches: Number(data.maxBranches) || 200,
                maxDurationMs: Number(data.maxDurationMs) || 45000,
                maxDepth: Number(data.maxDepth) || 5,
                scopeRoot: data.scopeRoot || "Groupes Etudiants",
                scopePath: data.scopePath || "Groupes Etudiants > Faculté des Sciences et Techniques"
              })
            );
            break;

          case "PLANILIM_COLLECTOR_TOGGLE_BRANCH":
            post(
              "PLANILIM_COLLECTOR_TOGGLE_BRANCH_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_TOGGLE_BRANCH", {
                target: data.target || null
              })
            );
            break;

          case "PLANILIM_COLLECTOR_PIPELINE_RESET":
            post(
              "PLANILIM_COLLECTOR_PIPELINE_RESET_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_PIPELINE_RESET", {
                scopePath: data.scopePath || "Groupes Etudiants > Faculté des Sciences et Techniques",
                maxDepth: Number(data.maxDepth) || 4
              })
            );
            break;

          case "PLANILIM_COLLECTOR_PIPELINE_STEP":
            post(
              "PLANILIM_COLLECTOR_PIPELINE_STEP_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_PIPELINE_STEP", {
                scopePath: data.scopePath || "Groupes Etudiants > Faculté des Sciences et Techniques",
                maxDepth: Number(data.maxDepth) || 4,
                maxActions: Number(data.maxActions) || 500,
                weekConcurrency: Number(data.weekConcurrency) || 8
              })
            );
            break;


          case "PLANILIM_COLLECTOR_PREPARE_RESOURCE":
            post(
              "PLANILIM_COLLECTOR_PREPARE_RESOURCE_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_PREPARE_RESOURCE", {
                target: data.target || null
              })
            );
            break;

          case "PLANILIM_COLLECTOR_PREPARE_RESOURCES":
            post(
              "PLANILIM_COLLECTOR_PREPARE_RESOURCES_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_PREPARE_RESOURCES", {
                targets: Array.isArray(data.targets) ? data.targets : [],
                reset: data.reset !== false
              })
            );
            break;


          case "PLANILIM_COLLECTOR_SYNC_FAST_SEQUENTIAL":
            post(
              "PLANILIM_COLLECTOR_SYNC_FAST_SEQUENTIAL_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_SYNC_FAST_SEQUENTIAL", {
                targets: Array.isArray(data.targets) ? data.targets : [],
                weekConcurrency: Number(data.weekConcurrency) || 8
              })
            );
            break;

          case "PLANILIM_COLLECTOR_SYNC_PREPARED":
            post(
              "PLANILIM_COLLECTOR_SYNC_PREPARED_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_SYNC_PREPARED", {
                resourceIds: Array.isArray(data.resourceIds) ? data.resourceIds : [],
                resourceConcurrency: 1,
                weekConcurrency: Number(data.weekConcurrency) || 8
              })
            );
            break;

          case "PLANILIM_COLLECTOR_CLEAR_PREPARED":
            post(
              "PLANILIM_COLLECTOR_CLEAR_PREPARED_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_CLEAR_PREPARED", {
                resourceIds: Array.isArray(data.resourceIds) ? data.resourceIds : null
              })
            );
            break;

          case "PLANILIM_COLLECTOR_SYNC_RESOURCE":
            post(
              "PLANILIM_COLLECTOR_SYNC_RESOURCE_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_SYNC_RESOURCE", {
                target: data.target || null
              })
            );
            break;

          case "PLANILIM_COLLECTOR_SYNC_RESOURCES":
            post(
              "PLANILIM_COLLECTOR_SYNC_RESOURCES_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_SYNC_RESOURCES", {
                targets: Array.isArray(data.targets) ? data.targets : []
              })
            );
            break;

          case "PLANILIM_COLLECTOR_PAYLOADS":
            post(
              "PLANILIM_COLLECTOR_PAYLOADS_RESULT",
              requestId,
              await runtimeMessage("PLANILIM_COLLECTOR_PAYLOADS")
            );
            break;

          case "PLANILIM_ADE_CLEAR":
            post(
              "PLANILIM_ADE_CLEAR_RESULT",
              requestId,
              await runtimeMessage(
                "PLANILIM_CLEAR_PROFILE"
              )
            );
            break;

          default:
            break;
        }
      } catch (error) {
        post(
          "PLANILIM_ADE_ERROR",
          requestId,
          {
            ok: false,
            code:
              "SITE_BRIDGE_EXCEPTION",
            message:
              String(
                error?.message ||
                error
              )
          }
        );
      }
    }
  );

  post(
    "PLANILIM_ADE_BRIDGE_READY",
    null,
    {
      ok: true,
      version:
        chrome.runtime.getManifest().version
    }
  );
})();
