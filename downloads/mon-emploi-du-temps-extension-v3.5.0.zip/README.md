# Mon emploi du temps — extension v3.5.0

Extension WebExtension pour synchroniser l’emploi du temps universitaire.

## Navigateurs

- Brave / Chrome / Edge / Opera / Vivaldi : Windows, macOS et Linux.
- Firefox : compatibilité WebExtension préparée dans cette version ; à valider sur un test réel avant diffusion générale.
- Safari : le code WebExtension est réutilisable, mais Safari exige un empaquetage spécifique en Safari Web Extension.

## Parcours utilisateur

1. Ouvrir l’extension et choisir l’emploi du temps.
2. Afficher le bon emploi du temps dans ADE.
3. Vérifier le planning détecté.
4. Cliquer sur « Valider et synchroniser ».
5. Attendre la fin de la synchronisation.

Si l’onglet ADE est fermé avant validation, la sélection est annulée automatiquement et l’extension propose de recommencer.
