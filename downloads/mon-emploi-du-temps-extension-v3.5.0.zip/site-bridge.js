(() => {
  "use strict";

  const ext = globalThis.browser || globalThis.chrome;

  if (globalThis.__PLANILIM_SITE_BRIDGE_V350__) {
    return;
  }

  globalThis.__PLANILIM_SITE_BRIDGE_V350__ = true;

  const SITE_ORIGIN =
    "https://tremble-e.github.io";

  const REQUEST_SOURCE =
    "planilim-site";

  const RESPONSE_SOURCE =
    "planilim-extension";

  function allowedPage() {
    return (
      window.location.origin ===
        SITE_ORIGIN &&
      window.location.pathname.startsWith(
        "/Site/"
      )
    );
  }

  if (!allowedPage()) {
    return;
  }

  function post(type, requestId, payload) {
    window.postMessage(
      {
        source:
          RESPONSE_SOURCE,
        type,
        requestId:
          requestId || null,
        payload
      },
      SITE_ORIGIN
    );
  }

  async function runtimeMessage(type) {
    return await ext.runtime.sendMessage({
      type
    });
  }

  async function publicStatus() {
    const status =
      await runtimeMessage(
        "PLANILIM_STATUS"
      );

    return {
      ok:
        Boolean(status?.profile),
      extensionVersion:
        ext.runtime.getManifest().version,
      adeOpen:
        status?.adeOpen ?? null,
      selectedAdeOpen:
        status?.selectedAdeOpen ?? null,
      profile:
        status?.profile
          ? {
              mode:
                status.profile.mode ||
                null,
              resourceId:
                status.profile.resourceId ??
                null,
              sampleWeek:
                status.profile.sampleWeek ||
                null,
              planningLabel:
                status.profile.planningLabel ||
                null
            }
          : null,
      academicSyncStatus:
        status?.academicSyncStatus ||
        null,
      academicSyncCacheSummary:
        status?.academicSyncCacheSummary ||
        null,
      lastSuccessfulSyncAt:
        status?.lastSuccessfulSyncAt ||
        null,
      v3:
        status?.v3
          ? {
              configured:
                Boolean(
                  status.v3.configured
                ),
              setupState:
                status.v3.setupState ||
                null,
              syncState:
                status.v3.syncState ||
                null
            }
          : null
    };
  }

  async function annualPayload() {
    return await runtimeMessage(
      "PLANILIM_ACADEMIC_YEAR_PAYLOAD"
    );
  }

  async function smartRefresh() {
    const sync =
      await runtimeMessage(
        "PLANILIM_SMART_ACADEMIC_REFRESH"
      );

    if (
      sync?.code ===
      "AUTH_REQUIRED"
    ) {
      return {
        ok: false,
        code:
          "AUTH_REQUIRED",
        sync,
        payload:
          await annualPayload()
      };
    }

    return {
      ok:
        Boolean(sync?.ok),
      code:
        sync?.code ||
        "REFRESH_FINISHED",
      sync,
      payload:
        await annualPayload()
    };
  }

  async function fullSync() {
    const sync =
      await runtimeMessage(
        "PLANILIM_SYNC_FULL_ACADEMIC_YEAR"
      );

    if (
      sync?.code ===
      "AUTH_REQUIRED"
    ) {
      return {
        ok: false,
        code:
          "AUTH_REQUIRED",
        sync,
        payload:
          await annualPayload()
      };
    }

    return {
      ok:
        Boolean(sync?.ok),
      code:
        sync?.code ||
        "FULL_SYNC_FINISHED",
      sync,
      payload:
        await annualPayload()
    };
  }

  window.addEventListener(
    "message",
    async (event) => {
      if (
        event.source !== window ||
        event.origin !== SITE_ORIGIN
      ) {
        return;
      }

      const data =
        event.data || {};

      if (
        data.source !==
        REQUEST_SOURCE
      ) {
        return;
      }

      const requestId =
        String(
          data.requestId || ""
        );

      if (!requestId) {
        return;
      }

      try {
        switch (data.type) {
          case "PLANILIM_ADE_STATUS":
            post(
              "PLANILIM_ADE_STATUS_RESULT",
              requestId,
              await publicStatus()
            );
            break;

          case "PLANILIM_ADE_CONNECT":
            post(
              "PLANILIM_ADE_CONNECT_RESULT",
              requestId,
              await runtimeMessage(
                "PLANILIM_V3_CONNECT"
              )
            );
            break;

          case "PLANILIM_ADE_GET_PAYLOAD":
            post(
              "PLANILIM_ADE_PAYLOAD_RESULT",
              requestId,
              await annualPayload()
            );
            break;

          case "PLANILIM_ADE_REFRESH":
            post(
              "PLANILIM_ADE_REFRESH_RESULT",
              requestId,
              await smartRefresh()
            );
            break;

          case "PLANILIM_ADE_FULL_SYNC":
            post(
              "PLANILIM_ADE_FULL_SYNC_RESULT",
              requestId,
              await fullSync()
            );
            break;

          case "PLANILIM_ADE_CLEAR":
            post(
              "PLANILIM_ADE_CLEAR_RESULT",
              requestId,
              await runtimeMessage(
                "PLANILIM_CLEAR_PROFILE"
              )
            );
            break;

          default:
            break;
        }
      } catch (error) {
        post(
          "PLANILIM_ADE_ERROR",
          requestId,
          {
            ok: false,
            code:
              "SITE_BRIDGE_EXCEPTION",
            message:
              String(
                error?.message ||
                error
              )
          }
        );
      }
    }
  );

  post(
    "PLANILIM_ADE_BRIDGE_READY",
    null,
    {
      ok: true,
      version:
        ext.runtime.getManifest().version
    }
  );
})();
