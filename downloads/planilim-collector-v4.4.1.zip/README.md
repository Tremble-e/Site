# Collecteur administrateur Planilim 4.4.1

Extension réservée à l’administrateur de Planilim, prévue pour Brave sous Windows.

## Utilisation

1. Se connecter à son compte administrateur sur Planilim.
2. Cliquer sur **Récupérer et synchroniser les EDT**.
3. Se connecter à ADE si Brave le demande, puis revenir sur Planilim.
4. Garder ADE ouvert pendant la collecte.

Le collecteur parcourt uniquement **Groupes Etudiants > Faculté des Sciences et Techniques**, restaure automatiquement les filières déjà enregistrées, récupère leurs 44 semaines universitaires et publie chaque planning terminé. Les étudiants n’installent jamais cette extension et ne voient aucune mention de celle-ci.

## Confidentialité

L’extension utilise uniquement la session ADE ouverte dans Brave. Elle ne demande pas l’accès direct aux cookies et n’enregistre ni identifiant ni mot de passe UNILIM. Aucun cookie ou ticket CAS n’est transmis à Planilim.

Le pont avec le site est limité à `https://tremble-e.github.io/Site/`.

## Version 4.2.6

- le parcours ADE est désormais strictement limité à `Groupes Etudiants > Faculté des Sciences et Techniques` ;
- les autres facultés de `Groupes Etudiants` ne sont plus ouvertes ;
- le balayage de l’arbre s’arrête dès que le sous-arbre Sciences et Techniques est terminé ;
- le site transmet explicitement le chemin complet du périmètre au collecteur.

## Version 4.2.4

- correction de l'arrêt immédiat introduit par le filtre de faculté : le lecteur d'arbre est maintenant initialisé avant son utilisation ;
- ADE passe au premier plan pendant l'ouverture des dossiers afin que Brave laisse GXT traiter les événements ;
- un test de non-régression couvre désormais l'exécution du filtre, et pas seulement sa présence dans le code.

## Version 4.2.3

- ouverture fiable des dossiers ADE par leur triangle natif ExtJS ;
- le double-clic sur le libellé n’est conservé qu’en solution de secours ;
- le parcours automatique démarre correctement depuis une arborescence repliée.

## Version 4.2.2

- exploration limitée au seul sous-arbre `Faculté des Sciences et Techniques` ;
- les facultés voisines ne sont plus ouvertes ni proposées à la synchronisation ;
- tous les paramètres de périmètre sont désormais transmis du site jusqu’à ADE.

## Version 4.2.1

- balayage accéléré du grand arbre virtualisé d'ADE ;
- délai de sécurité renforcé lorsque le catalogue contient beaucoup de formations ;
- périmètre strict `Groupes Etudiants` et récupération annuelle conservés.

## Version 4.2.0

- synchronisation administrateur en un seul parcours ;
- exploration limitée à **Groupes Etudiants** ;
- restauration automatique du chemin ADE d’une filière ;
- correction du clic sur les vraies commandes de semaine ADE ;
- prise en charge des chaînes JavaScript renvoyées par GWT ;
- validation réelle réussie sur Brave : 44 semaines sur 44, 669 cours, aucune semaine en erreur pour la ressource test.


## v4.2.6
- conserve l'onglet ADE pendant toute une collecte multi-formations ;
- attend que la formation sélectionnée soit réellement chargée avant de synchroniser ;


## Version 4.3.1

- le catalogue découvert est conservé cumulativement : les formations déjà vues ne disparaissent plus à cause de la virtualisation ExtJS ;
- une formation en erreur n'arrête plus toute la file de collecte ;
- accélération de la synchronisation annuelle : `getTimetable` est rejoué seul en priorité, avec retour automatique à la séquence complète si ADE l'exige ;
- pas de parallélisation massive par onglets : l'état GWT/session reste volontairement sérialisé pour éviter les corruptions.


### Correctifs v4.3.1
- exploration plus profonde et stabilisée de l’arbre FST dès le premier lancement ;
- l’onglet ADE reste interactif pendant les navigations réelles ;
- timeout réseau sur les RPC pour empêcher un EDT de bloquer toute la file.


## Version 4.3.1
- balayage ExtJS avec recouvrement et lecture explicite du bas de l'arbre ;
- profondeur portée à 18 niveaux pour ne plus perdre les derniers semestres de master ;
- la semaine visible lors de la sélection sert aussi de contrôle de complétude ;
- possibilité interne de forcer la séquence RPC complète lorsqu'un planning nécessite un mode plus conservateur.


### Correctif v4.3.1
- Profondeur maximale du parcours ADE remise à 5 niveaux dans la branche FST.


## Version 4.3.2

- correction de la limite de profondeur du catalogue ADE : la limite de 5 est désormais relative au dossier « Faculté des Sciences et Techniques » au lieu d'être interprétée comme un niveau absolu de l'arbre ;
- le collecteur reste donc borné, mais peut de nouveau atteindre les semestres/groupes situés plusieurs niveaux sous la faculté ;
- aucun changement au moteur de synchronisation des cours.


## Version 4.3.3

- arrêt sémantique de l’exploration sur les nœuds `Semestre N` / `AN` : les groupes CM/TD/TP sous un semestre ne sont plus parcourus ni publiés comme EDT ;
- limite de profondeur de secours ramenée à 4 niveaux relatifs sous la Faculté des Sciences et Techniques ;
- accélération du collecteur administrateur : jusqu’à 4 semaines GWT sont rejouées en parallèle dans le même onglet ADE, sans ouvrir 20 onglets concurrents ;
- la synchronisation utilisateur classique reste séquentielle pour conserver le comportement le plus prudent.


## Version 4.4.1 — pipeline en deux phases

Le collecteur administrateur ne synchronise plus l'année complète immédiatement après chaque clic dans l'arbre.

1. **Préparation** : chaque EDT est sélectionné une seule fois et son vrai modèle `method10getTimetable` est capturé.
2. **Téléchargement** : une fois tous les modèles prêts, les années complètes sont récupérées sans reparcourir l'arbre, avec 3 EDT simultanés et jusqu'à 6 semaines simultanées par EDT.
3. **Lecture uniforme de l'année** : toutes les semaines, vides ou non, sont récupérées de la même manière par RPC ; aucune semaine vide n'est considérée comme suspecte.

L'année universitaire complète reste vérifiée pour chaque EDT : aucune réduction du nombre de semaines n'est appliquée selon le semestre.
