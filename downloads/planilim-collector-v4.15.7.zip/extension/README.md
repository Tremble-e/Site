## v4.15.7 — optimisation conservatrice de la collecte

Cette version conserve les mécaniques fiables de la v4.15.6 : bootstrap séquentiel des 4 workers, placement unique 2×2, délais réseau, stabilisation ciblée, réparation finale et publication uniquement après validation complète 44/44.

Optimisations ajoutées uniquement sur le chemin normal, avec fallback automatique vers l’ancien comportement :

- mémorisation de la frame ADE utilisée pour les previews et changements de semaine ;
- plus de réinjection systématique des content scripts à chaque lecture : elle reste utilisée si aucune frame ne répond ;
- réutilisation du RPC déclenché par la sélection déjà confirmée d’un EDT avant de tenter une nouvelle sélection ;
- suppression d’une resélection supplémentaire avant le parcours des 44 semaines lorsque le worker confirme qu’il est toujours sur la bonne ressource.

Aucun timeout de récupération, délai entre semaines, niveau de concurrence, nombre de retries ou règle de validation n’a été réduit.

## v4.15.6 — bootstrap stable restauré + placement unique 2×2

Cette version repart volontairement du moteur stable de la v4.15.2 pour le cycle de vie des workers.

- La page ADE coordinatrice est activée une seule fois avant la lecture de l'arbre, afin que le rendu ExtJS/GWT se comporte comme lors d'un retour manuel sur la page.
- Les 4 workers sont de nouveau créés séquentiellement, avec les délais, retries et grand viewport utilisés par la v4.15.2.
- Le quadrillage 2×2 n'est appliqué qu'après la validation des workers. Il n'intervient donc plus dans leur bootstrap ADE.
- Le placement utilise l'écran contenant réellement la fenêtre du coordinateur.
- Après ce placement initial, aucune sécurité ne touche plus aux fenêtres : pas de pulse de focus, pas de restauration, pas de maximisation, pas de repositionnement pendant la collecte ou la réparation.
- L'ancienne alarme de focus persistante est supprimée au chargement de l'extension.

Le moteur de collecte, les retries ciblés et la réparation finale restent ceux de la branche stable v4.15.2/v4.13.
