# 4.16.2 — reprise complète et relance à 4 workers

- Le moteur asynchrone accepte désormais une liste ciblée d'EDT déjà connue, la déduplique par `resourceId` et la confie au même pool de 4 workers que la synchronisation normale.
- La relance des échecs peut donc récupérer en parallèle les vrais échecs et les EDT restés non traités après une interruption.
- Les contrôles d'identité de ressource, de complétude des semaines et la protection contre les publications partielles restent inchangés.
- L'intégration du site 2.36.28 est fournie dans le dossier `site-integration` de l'archive livrée.
