'use strict';

const SITE_URL = 'https://tremble-e.github.io/Site/#planning';
const $ = id => document.getElementById(id);

function send(type, payload = {}, timeoutMs = 15000) {
  return new Promise(resolve => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({
        ok: false,
        code: 'POPUP_RUNTIME_TIMEOUT',
        message: 'La réponse de l’extension a dépassé le délai prévu. Une nouvelle tentative peut être lancée ; si le problème persiste, recharger l’extension.'
      });
    }, timeoutMs);

    chrome.runtime.sendMessage({ type, ...payload }, response => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const error = chrome.runtime.lastError;
      resolve(error
        ? { ok: false, code: 'POPUP_RUNTIME_ERROR', message: error.message }
        : response || {});
    });
  });
}

function formatSyncDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function uiState(status) {
  const syncState = status?.v3?.syncState?.state || status?.academicSyncStatus?.state || '';
  const resources = Array.isArray(status?.collector?.resources) ? status.collector.resources : [];
  const running = ['syncing', 'preparing_fresh_base', 'running', 'syncing_initial_year'].includes(syncState);

  if (running) {
    return {
      kind: 'busy',
      title: 'Synchronisation en cours',
      message: 'ADE est en cours de lecture. L’onglet doit rester ouvert jusqu’à la fin.',
      hint: 'L’avancement et la publication sont visibles dans la partie Administration de Planilim.',
      resources
    };
  }

  if (syncState === 'auth_required') {
    return {
      kind: 'bad',
      title: 'Connexion ADE nécessaire',
      message: 'Ouvrir Planilim puis relancer la synchronisation. Le collecteur ouvrira ADE si une connexion universitaire est nécessaire.',
      hint: 'Les identifiants restent saisis uniquement sur la page officielle de l’Université.',
      resources
    };
  }

  return {
    kind: 'ready',
    title: resources.length ? 'Collecteur prêt à publier' : 'Collecteur prêt',
    message: 'La récupération se lance depuis le panneau Administration de Planilim.',
    hint: 'Le collecteur peut synchroniser les filières de la FST et les salles du site La Borie. L’extension reste réservée à la collecte.',
    resources
  };
}

function render(status) {
  const ui = uiState(status || {});
  const resources = ui.resources;
  const latest = resources
    .map(resource => resource.updatedAt || resource.payload?.generatedAt || '')
    .filter(Boolean)
    .sort()
    .at(-1);

  const statusIcon = $('statusIcon');
  statusIcon.className = 'status-icon';
  if (ui.kind === 'ready') statusIcon.classList.add('ok');
  if (ui.kind === 'bad') statusIcon.classList.add('bad');
  if (ui.kind === 'busy') statusIcon.classList.add('busy');

  $('title').textContent = ui.title;
  $('message').textContent = ui.message;
  $('hint').textContent = ui.hint;
  $('mainButton').textContent = 'Ouvrir Planilim';
  $('mainButton').disabled = false;

  $('planningLabel').textContent = `${resources.length} EDT`;
  $('planningChip').hidden = resources.length === 0;
  $('lastSync').textContent = formatSyncDate(latest);
  $('lastSyncChip').hidden = !latest;

  const diagnosticCount = Number(status?.diagnostics?.count || 0);
  const hasReference = Boolean(status?.diagnostics?.hasSuccessReference);
  $('exportDiagnostics').textContent = diagnosticCount
    ? `Exporter les diagnostics (${diagnosticCount})`
    : 'Exporter les diagnostics';
  $('exportDiagnostics').disabled = diagnosticCount === 0 && !hasReference;
  $('clearDiagnostics').disabled = diagnosticCount === 0 && !hasReference;
  $('diagStatus').textContent = diagnosticCount
    ? `${diagnosticCount} anomalie${diagnosticCount > 1 ? 's' : ''} enregistrée${diagnosticCount > 1 ? 's' : ''}${hasReference ? ' + 1 cas réussi de référence' : ''}.`
    : (hasReference ? 'Un cas réussi de référence est enregistré.' : 'Aucun diagnostic enregistré pour le moment.');
}

async function openPlanilim() {
  await chrome.tabs.create({ url: SITE_URL, active: true });
  window.close();
}


async function syncCurrentEdtAccurate() {
  const button = $('syncCurrentEdtAccurate');
  button.disabled = true;
  $('diagStatus').textContent = 'Synchronisation fiable en cours : ADE parcourt les semaines une par une…';
  const result = await send('PLANILIM_SYNC_CURRENT_EDT_ACCURATE', {}, 240000);
  $('diagStatus').textContent = result?.message || result?.code || 'Synchronisation terminée.';
  button.disabled = false;
  const status = await send('PLANILIM_STATUS');
  render(status);
  $('diagStatus').textContent = result?.message || result?.code || 'Synchronisation terminée.';
}

async function auditCurrentEdt() {
  const button = $('auditCurrentEdt');
  button.disabled = true;
  $('diagStatus').textContent = 'Audit en cours : comparaison ADE ↔ Planilim semaine par semaine… ADE doit rester ouvert.';
  const result = await send('PLANILIM_DEBUG_AUDIT_CURRENT_EDT', {}, 240000);
  if (!result?.ok) {
    $('diagStatus').textContent = result?.message || result?.code || 'Impossible d’auditer cet emploi du temps.';
    button.disabled = false;
    return;
  }
  $('diagStatus').textContent = result?.message || `Audit terminé : ${result.mismatchCount || 0} semaine(s) différente(s). Les diagnostics peuvent être exportés.`;
  button.disabled = false;
  const status = await send('PLANILIM_STATUS');
  render(status);
  $('diagStatus').textContent = result?.message || `Audit terminé : ${result.mismatchCount || 0} semaine(s) différente(s). Les diagnostics peuvent être exportés.`;
}

async function exportDiagnostics() {
  const button = $('exportDiagnostics');
  button.disabled = true;
  $('diagStatus').textContent = 'Préparation du fichier de diagnostic…';

  // 4.6.5 : le background déclenche lui-même le téléchargement. On évite ainsi
  // de transférer un gros objet JSON via runtime.sendMessage, ce qui pouvait
  // laisser le popup bloqué indéfiniment sur certains Chromium/Brave.
  const result = await send('PLANILIM_DEBUG_DIAGNOSTICS_EXPORT', {}, 25000);
  if (!result?.ok) {
    $('diagStatus').textContent = result?.message || result?.code || 'Impossible de préparer les diagnostics.';
    button.disabled = false;
    return;
  }

  if (result.directDownload) {
    $('diagStatus').textContent = 'Diagnostic téléchargé. Le fichier JSON est prêt à être partagé ou analysé.';
    button.disabled = false;
    return;
  }

  // Repli pour navigateurs ne proposant pas chrome.downloads.
  if (result?.data) {
    const blob = new Blob([JSON.stringify(result.data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = result.fileName || 'planilim-diagnostic.json';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    $('diagStatus').textContent = 'Diagnostic exporté. Le fichier JSON est prêt à être partagé ou analysé.';
  } else {
    $('diagStatus').textContent = result?.message || 'Le téléchargement du diagnostic n’a pas pu démarrer.';
  }
  button.disabled = false;
}

async function clearDiagnostics() {
  const result = await send('PLANILIM_DEBUG_DIAGNOSTICS_CLEAR');
  if (!result?.ok) {
    $('diagStatus').textContent = result?.message || 'Impossible d’effacer les diagnostics.';
    return;
  }
  const status = await send('PLANILIM_STATUS');
  render(status);
  $('diagStatus').textContent = 'Diagnostics effacés. Une nouvelle synchronisation peut être lancée.';
}

$('mainButton').addEventListener('click', openPlanilim);
$('syncCurrentEdtAccurate').addEventListener('click', syncCurrentEdtAccurate);
$('auditCurrentEdt').addEventListener('click', auditCurrentEdt);
$('exportDiagnostics').addEventListener('click', exportDiagnostics);
$('clearDiagnostics').addEventListener('click', clearDiagnostics);
send('PLANILIM_STATUS').then(render);
