# Extension PC 4.16.2

## Extension

Décompresser l'archive, puis charger ce dossier comme extension non empaquetée. Le fichier `manifest.json` se trouve directement à la racine.

La relance ciblée accepte une liste d'EDT dédupliquée et utilise le même pool de 4 workers que la synchronisation normale.

## Intégration du site

Le dossier `site-integration` contient les fichiers à remplacer sur le site :

- `planning.js`
- `index.html`
- `service-worker.js`

Copier ensuite l'archive de l'extension dans `site/downloads/planilim-collector-v4.16.2.zip`. Le cache du site passe en 2.36.28 afin que le nouveau `planning.js` soit chargé.

Cette intégration ajoute tous les EDT ciblés à la file de reprise avant leur traitement, retire uniquement les publications confirmées et conserve les vrais échecs ainsi que les EDT jamais traités.
