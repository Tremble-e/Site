# Planilim Collector v4.6.2

Cette version corrige la cause identifiée par le diagnostic 4.5.7 : l’identification d’une requête `method10getTimetable` dépendait d’une back-reference GWT précise (`-8`). Les ressources sont désormais extraites depuis la structure réelle de `PlanningSelection`, et les semaines sérialisées sous forme de back-reference (`-3` à `-9`) sont décodées puis réécrites sous forme d’`Integer` explicite. Les outils de diagnostic sont conservés.


## v4.6.2 — stockage étendu et protection anti-quota

- Ajout de la permission Chromium/Brave `unlimitedStorage` : les 216 payloads complets ne sont plus limités par le quota standard de `chrome.storage.local`.
- Si un profil est déjà proche de la limite au moment de la mise à jour, le collecteur compacte automatiquement les anciens diagnostics volumineux puis retente l’écriture.
- Les diagnostics d’audit conservent les résumés et les différences utiles, mais tronquent les duplications de grosses réponses GWT afin de ne plus concurrencer les payloads des EDT.
- Le démarrage d’une synchronisation complète compacte les anciens diagnostics, sans supprimer les emplois du temps déjà récupérés.

## Diagnostic

1. Ouvre le popup de l'extension.
2. Clique sur **Effacer les diagnostics** avant un test propre.
3. Lance la synchronisation ou **Relancer les échecs** depuis Planilim.
4. Quand le test est terminé, rouvre le popup et clique sur **Exporter les diagnostics**.
5. Envoie le fichier `planilim-diagnostic-....json`.

L'export n'inclut pas les cookies ni les en-têtes `Authorization`. Il contient les corps GWT et réponses ADE nécessaires pour comprendre les cas restants.

---

# Collecteur administrateur 4.5.6

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.


## 4.5.3
- Parcours unique conservé, mais plus aucune synchronisation en parallèle avec la sélection de l’EDT suivant.
- Un EDT reste sélectionné pendant toute la récupération de ses 44 semaines.
- Passage de confirmation supplémentaire sur l’arbre virtualisé avant de déclarer la découverte terminée.


## v4.5.3
Le parcours unique de l’arbre est conservé, mais la récupération annuelle revient au moteur stable validé (bootstrap à deux traces réelles + génération GWT). Le modèle RPC simplifié introduit en 4.5.x n’est plus utilisé par le pipeline administrateur. Jusqu’à 4 semaines sont synchronisées en parallèle pour un seul EDT à la fois.


## v4.5.5
- La sélection d'un EDT est retentée automatiquement si ExtJS perd le premier clic pendant un rerendu.
- Les semaines RPC en échec sont rejouées automatiquement en séquence complète et de façon séquentielle, uniquement après le passage rapide.
- La semaine réellement visible dans ADE est fusionnée avec la semaine RPC avant publication afin de récupérer les cours visibles que le décodeur GWT aurait partiellement normalisés.
- Les corrections de parcours de la v4.5.4 sont conservées.


## v4.5.6
- Si ADE ne confirme pas immédiatement la sélection d'un EDT, la ressource est resélectionnée jusqu'à deux fois avant d'être déclarée en échec.
- Le moteur stable rejoue jusqu'à quatre fois uniquement les semaines encore en échec, avec temporisation croissante.
- Le moteur rapide utilisé par « Relancer les échecs » effectue désormais trois passes ciblées sur les seules semaines ratées au lieu de refaire dépendre tout l'EDT d'un unique passage.
- Les résultats partiels remontent maintenant le nombre de semaines en échec et un résumé des codes techniques afin de distinguer un problème réseau d'un problème de décodage.


## v4.5.9 — replay GWT vérifié

- Les modèles `method10getTimetable` utilisant une back-reference GWT ne sont plus mutés localement.
- ADE est déplacé directement sur une semaine produisant un `Integer` littéral, puis ce body natif sert de modèle annuel.
- Une collecte partielle n'écrase plus jamais le dernier payload complet.
- Un EDT n'est marqué réussi que si toutes les semaines demandées ont été décodées avec succès.
- En cas d'échec de replay, le diagnostic compare automatiquement le body natif et le body reconstruit.


## v4.6.1 — garde de cohérence et audit de bout en bout

La synchronisation rapide conserve plusieurs requêtes `getTimetable` en parallèle, mais vérifie désormais jusqu’à huit semaines sentinelles en les rejouant séquentiellement. Si un seul événement diffère, le résultat parallèle est abandonné et l’EDT est entièrement retéléchargé séquentiellement avant publication. Le payload stocké indique alors `collectionMode: sequential-fallback`.

L’audit de l’EDT affiché compare maintenant aussi le payload déjà stocké avec le décodage séquentiel (`decodedNotStored` / `storedNotDecoded`) et sélectionne les onglets de semaine par date exacte, y compris au passage décembre → janvier.

## Diagnostic des cours manquants — v4.6.0

Cette version ajoute un audit ciblé d'un emploi du temps. Ouvrez ADE, sélectionnez l'EDT concerné, puis ouvrez le popup de l'extension et cliquez sur **Auditer l’EDT affiché dans ADE**. L'extension parcourt l'année semaine par semaine, compare les événements visibles dans ADE avec ceux décodés depuis `method10getTimetable`, et enregistre uniquement les semaines divergentes avec les événements bruts utiles. Une fois l'audit terminé, utilisez **Exporter les diagnostics** et transmettez le JSON généré.
