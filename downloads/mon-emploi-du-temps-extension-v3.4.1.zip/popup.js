'use strict';

const $ = id => document.getElementById(id);
let currentStatus = null;
let busy = false;

function send(type) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type }, response => {
      const error = chrome.runtime.lastError;
      resolve(error
        ? { ok: false, code: 'POPUP_RUNTIME_ERROR', message: error.message }
        : response);
    });
  });
}

function formatSyncDate(value) {
  if (!value) return 'Jamais';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function planningInfo(status) {
  const setup = status?.v3?.setupState || null;
  if (setup?.planningLabel) return setup.planningLabel;
  if (setup?.resourceId != null) return `Emploi du temps #${setup.resourceId}`;
  if (status?.profile?.planningLabel) return status.profile.planningLabel;
  const id = status?.profile?.resourceId ?? null;
  return id != null ? `Emploi du temps #${id}` : 'Emploi du temps détecté';
}

function getUiState(status) {
  const configured = Boolean(status?.v3?.configured || status?.profile?.requestCaptured);
  const setup = status?.v3?.setupState || null;
  const sync = status?.v3?.syncState || status?.academicSyncStatus || null;
  const cache = status?.academicSyncCacheSummary || null;
  const syncState = sync?.state || '';
  const setupState = setup?.state || '';
  const running = ['bootstrapping', 'syncing_initial_year'].includes(setupState) ||
    ['syncing', 'preparing_fresh_base', 'running'].includes(syncState);

  if (running) {
    return {
      kind: 'busy',
      title: 'Synchronisation en cours',
      message: 'Récupération de l’année universitaire en cours. Gardez la page universitaire ouverte jusqu’à la fin.',
      button: 'Synchronisation…',
      disabled: true,
      hint: 'La synchronisation peut prendre quelques instants selon le nombre de semaines à récupérer.'
    };
  }

  if (syncState === 'auth_required' || status?.academicSyncStatus?.state === 'auth_required') {
    return {
      kind: 'auth',
      title: 'Reconnexion nécessaire',
      message: 'Votre session universitaire a expiré. Reconnectez-vous puis réaffichez l’emploi du temps à synchroniser.',
      button: 'Se reconnecter',
      disabled: false,
      hint: 'Une fois reconnecté, laissez l’emploi du temps s’afficher : la détection reprend automatiquement.'
    };
  }

  if (['waiting_for_ade', 'waiting_for_login', 'needs_week_change'].includes(setupState)) {
    return {
      kind: 'waiting',
      title: 'En attente de votre emploi du temps',
      message: "Connectez-vous si nécessaire puis affichez l’emploi du temps que vous souhaitez synchroniser. Rien ne changera avant votre validation.",
      button: 'En attente de l’emploi du temps…',
      disabled: true,
      hint: 'Dès que l’emploi du temps est reconnu, vous pourrez le vérifier puis valider la synchronisation.'
    };
  }

  if (setupState === 'detected' || (configured && !cache?.updatedAt && !cache?.eventCount)) {
    return {
      kind: 'detected',
      title: 'Emploi du temps détecté',
      message: `${planningInfo(status)} est affiché. Vérifiez qu’il s’agit du bon emploi du temps avant de continuer.`,
      button: 'Valider et synchroniser',
      disabled: false,
      hint: 'Après validation seulement, l’extension pourra changer de semaine pour récupérer l’année complète.'
    };
  }

  if (configured && cache?.updatedAt) {
    return {
      kind: 'ready',
      title: 'Synchronisation terminée',
      message: 'Votre emploi du temps est à jour. Vous pouvez fermer la page universitaire ou relancer une synchronisation si besoin.',
      button: 'Synchroniser à nouveau',
      disabled: false,
      hint: 'Si vous changez de planning, affichez-le d’abord puis relancez la synchronisation.'
    };
  }

  if (configured) {
    return {
      kind: 'detected',
      title: 'Emploi du temps détecté',
      message: `${planningInfo(status)} est prêt. Vérifiez-le puis lancez la synchronisation.`,
      button: 'Valider et synchroniser',
      disabled: false,
      hint: 'L’emploi du temps détecté reste affiché ici pour éviter toute erreur avant la synchronisation.'
    };
  }

  return {
    kind: 'start',
    title: 'Choisir mon emploi du temps',
    message: "Ouvrez la page universitaire, connectez-vous si nécessaire puis affichez l’emploi du temps que vous souhaitez utiliser.",
    button: 'Choisir mon emploi du temps',
    disabled: false,
    hint: 'Étape 1 : choisir et vérifier. Étape 2 : valider puis synchroniser.'
  };
}

function render(status) {
  currentStatus = status || {};
  const ui = getUiState(currentStatus);
  const cache = currentStatus?.academicSyncCacheSummary || null;

  const statusIcon = $('statusIcon');
  statusIcon.className = 'status-icon';
  if (ui.kind === 'ready' || ui.kind === 'detected') statusIcon.classList.add('ok');
  if (ui.kind === 'auth') statusIcon.classList.add('bad');
  if (ui.kind === 'busy') statusIcon.classList.add('busy');

  $('title').textContent = ui.title;
  $('message').textContent = ui.message;
  $('hint').textContent = ui.hint || '';
  $('mainButton').textContent = ui.button;
  $('mainButton').disabled = busy || ui.disabled;

  const lastSyncValue = formatSyncDate(cache?.updatedAt || currentStatus?.lastSuccessfulSyncAt);
  $('lastSync').textContent = lastSyncValue;
  $('lastSyncChip').hidden = !cache?.updatedAt && !currentStatus?.lastSuccessfulSyncAt;

  const detectedPlanning = (ui.kind === 'detected' || ui.kind === 'ready' || ui.kind === 'busy' || isConfigured(currentStatus)) ? planningInfo(currentStatus) : '';
  $('planningLabel').textContent = detectedPlanning || '—';
  $('planningChip').hidden = !detectedPlanning;
}

async function refresh() {
  const status = await send('PLANILIM_STATUS');
  render(status);
}

async function runPrimaryAction() {
  const ui = getUiState(currentStatus || {});
  if (ui.disabled || busy) return;

  busy = true;
  render(currentStatus || {});

  if (ui.kind === 'detected' || ui.kind === 'ready') {
    await send('PLANILIM_V3_STABLE_FULL_SYNC');
  } else {
    await send('PLANILIM_V3_CONNECT');
  }

  busy = false;
  await refresh();
}

function isConfigured(status) {
  return Boolean(status?.v3?.configured || status?.profile?.requestCaptured);
}

$('mainButton').addEventListener('click', runPrimaryAction);

refresh();
setInterval(refresh, 900);
