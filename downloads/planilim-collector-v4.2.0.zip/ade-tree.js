(function (root, factory) {
  const api = factory();

  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.PlanilimAdeTree = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function clean(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();
  }

  function parseResourceId(nodeId) {
    const match = String(nodeId || "").match(/_(\d+)$/);
    return match ? Number(match[1]) : null;
  }

  function detectExpandedState(row, node) {
    for (const element of [row, node]) {
      if (!element?.getAttribute) continue;
      const value = element.getAttribute("aria-expanded");
      if (value === "true") return true;
      if (value === "false") return false;
    }

    const joint = node?.querySelector?.("[class*='joint']");
    const classes = [row?.className, node?.className, joint?.className]
      .map((value) => typeof value === "string" ? value : value?.baseVal || "")
      .join(" ");
    if (/(?:joint|node)[-_](?:minus|expanded)|\bexpanded\b/i.test(classes)) return true;
    if (/(?:joint|node)[-_](?:plus|collapsed)|\bcollapsed\b/i.test(classes)) return false;
    return null;
  }

  function normalizeRows(rawRows) {
    const stack = [];
    const rows = [];

    for (const raw of rawRows || []) {
      const label = clean(raw?.label);
      const level = Number(raw?.level);
      const resourceId = raw?.resourceId == null
        ? parseResourceId(raw?.nodeId)
        : Number(raw.resourceId);

      if (!label || !Number.isFinite(level) || level < 1) continue;

      stack.length = Math.max(0, level - 1);
      stack[level - 1] = label;

      const pathParts = stack.slice(0, level).filter(Boolean);
      rows.push({
        label,
        level,
        nodeId: String(raw?.nodeId || ""),
        resourceId: Number.isFinite(resourceId) ? resourceId : null,
        selected: raw?.selected === true || String(raw?.selected) === "true",
        expanded:
          raw?.expanded === true || String(raw?.expanded) === "true"
            ? true
            : raw?.expanded === false || String(raw?.expanded) === "false"
              ? false
              : null,
        branchToggle: raw?.branchToggle === true,
        pathParts,
        path: pathParts.join(" > ")
      });
    }

    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index];
      if (row.expanded !== null || !row.branchToggle) continue;
      row.expanded = Number(rows[index + 1]?.level) > Number(row.level);
    }

    return rows;
  }

  function rawRowsFromDocument(doc) {
    if (!doc?.querySelectorAll) return [];

    return [...doc.querySelectorAll(".x-grid3-row")]
      .map((row) => {
        const node = row.querySelector(
          ".x-tree3-node[id^='Direct Planning Tree_']"
        );
        const label = row.querySelector(".x-tree3-node-text");
        if (!node || !label) return null;
        const joint = node.querySelector(".x-tree3-node-joint");
        const jointStyle = String(joint?.getAttribute("style") || "");

        return {
          label: clean(label.textContent),
          level: row.getAttribute("aria-level"),
          selected:
            row.getAttribute("aria-selected") === "true" ||
            row.classList.contains("x-grid3-row-selected"),
          expanded: detectExpandedState(row, node),
          branchToggle: Boolean(joint && /background\s*:/i.test(jointStyle)),
          nodeId: node.id,
          resourceId: parseResourceId(node.id)
        };
      })
      .filter(Boolean);
  }

  function snapshotDocument(doc) {
    const rows = normalizeRows(rawRowsFromDocument(doc));
    const selected = rows.find((row) => row.selected) || null;

    return {
      ok: rows.length > 0,
      code: rows.length > 0 ? "ADE_TREE_READY" : "ADE_TREE_NOT_FOUND",
      rowCount: rows.length,
      selected,
      rows
    };
  }

  function findRow(rows, target) {
    const nodeId = clean(target?.nodeId);
    const resourceId = Number(target?.resourceId);
    const path = clean(target?.path);
    const label = clean(target?.label);

    if (nodeId) {
      const byNodeId = (rows || []).find((row) => row.nodeId === nodeId);
      if (byNodeId) return byNodeId;
    }

    if (Number.isFinite(resourceId)) {
      const byId = (rows || []).find((row) => row.resourceId === resourceId);
      if (byId) return byId;
    }

    if (path) {
      const byPath = (rows || []).find((row) => row.path === path);
      if (byPath) return byPath;
    }

    if (label) {
      const matches = (rows || []).filter((row) => row.label === label);
      if (matches.length === 1) return matches[0];
    }

    return null;
  }

  return {
    clean,
    parseResourceId,
    detectExpandedState,
    normalizeRows,
    rawRowsFromDocument,
    snapshotDocument,
    findRow
  };
});
