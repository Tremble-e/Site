# Collecteur administrateur 4.5.0

Cette version remplace le double parcours ADE par un pipeline continu.

## Pipeline

1. Le collecteur ouvre uniquement `Groupes Etudiants > Faculté des Sciences et Techniques`.
2. L'arbre est parcouru une seule fois.
3. Dès qu'une feuille `Semestre N` ou `AN` est rencontrée, elle est sélectionnée immédiatement et son vrai modèle `getTimetable` est capturé.
4. Pendant que l'arbre continue vers la feuille suivante, le modèle précédent télécharge son année complète par RPC.
5. Un seul EDT est téléchargé à la fois, avec jusqu'à 8 semaines simultanées.
6. Il n'y a plus de second parcours de l'arbre pour retrouver les EDT déjà découverts.

Une semaine vide est considérée comme valide. Les erreurs techniques restent relançables séparément.
